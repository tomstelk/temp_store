import os
import json
import pandas as pd
import logging
import pprint as pp

from labeler import Labeler
from LFAnalysis import LFTester
from classes import Candidate, Sentence

#from utils import align_tokens, import_lf
from itertools import groupby

import import_utils
from utils.json_utils import get_json, print_json_pretty
from build_preprocessor import pre_processor
import json

from pathlib import Path
from load_grid import load_files_grid, load_lf_grid
from print_results import print_extracted

logger = logging.getLogger(__name__)


if __name__ == '__main__':

    files_grid = load_files_grid('files_grid.json')
    lf_grid = load_lf_grid('lf_grid.json')
    base_save_path = Path('metrics')

    for path in files_grid:
        print('Processing: {}'.format(path))
        save_dir_name = os.path.basename(path).split('.')[0]
        save_dir = base_save_path/save_dir_name

        # IO
        with open(path) as f:
            gold_samples = json.load(f)

        unseen_data = [{'text': t['text'], 'labels': []} for t in gold_samples]
        some_alcohol = [t['text'] for t in unseen_data]

        # Preprocessing
        n = range(len(some_alcohol))
        make_ppt = lambda ti : Sentence(ti[0], ti[1])
        init_ppt = list(map(make_ppt,  zip(some_alcohol, n)))

        res = list(map(pre_processor, init_ppt))
        candidates = [u for s in res for u in s.split()]

        if not os.path.exists(save_dir):
            os.mkdir(save_dir)

        # Setup
        for label, lfs  in lf_grid.items():

            # Test first
            tester = LFTester(label)
            metrics = tester.evaluate(lfs, gold_samples, candidates)
            
            for k, v in metrics.items():
                for kk, vv in v.items():
                    metrics[k][kk] = float(vv)
            print_json_pretty(metrics, str(save_dir/'{}.json'.format(label)))

            if len(lfs) > 3:

                labeler = Labeler(label)
                candidates = labeler.annotate(candidates, lfs)
                sentences = labeler.annotate_sentences(res, candidates)

                with open(save_dir/'sample.txt', 'w') as f:
                    printer = lambda x: print(x, file=f)
                    print_extracted([s.to_json() for s in sentences], printer)
