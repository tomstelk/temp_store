import os
import pandas as pd
import logging
import import_utils

from snorkel.labeling import LFApplier

from analysis import make_label_matrix, compute_score, from_spacy

logger = logging.getLogger(__name__)


class LFTester:
    """ Wrapper to evaluate lfs on gold datasets 

    Assume candidates are already preprocessed if needed by LF
    Assume gold is in spacy format
    """

    def __init__(self, target_label, save_df=False):
        self.target_label = target_label
        self.save_df = False

    def evaluate(self, lfs, gold_samples, candidates, as_df=False):
        """ Take some lfs and compute metrics per LF on candidate set
        """
        results = {}
        gold_sentences = from_spacy(gold_samples)
        gold = make_label_matrix(gold_sentences, filter_labels=[self.target_label])

        for lf in lfs:
            logger.debug('Evaluating {}'.format(lf.name))
            labeler = LFApplier([lf])
            l_train = labeler.apply(candidates, progress_bar=False).reshape(-1)

            if l_train.max() < 0:
                logger.info("LF didn't produce predictions")
                results[lf.name] = {}

            else: 
                metrics = compute_score(gold, preds=l_train)
                results[lf.name] = metrics

        if as_df:
            return pd.DataFrame(results).T

        return results

    def score(self, gold_samples, sentences, as_df):
        """ Just score candidates against gold_samples
        """
        results = {}
        gold_sentences = from_spacy(gold_samples)
        gold = make_label_matrix(gold_sentences, filter_labels=[self.target_label])
        preds = make_label_matrix(sentences, filter_labels=[self.target_label])

        metrics = compute_score(gold, preds=preds)
        results[self.target_label] = metrics

        return results
