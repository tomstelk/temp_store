# -*- coding: utf-8 -*-
from classes.Candidate import Sentence
import re


class PreProcessor():
    
    def fit(self, x):
        return self
    
    def to_json(self):
        raise NotImplementedError
    
    def from_json(self):
        raise NotImplementedError
    
    def __call__(self, sentence):
        
        spans = list(self._transform(sentence))
        if spans:
            sentence.add_pre_label(pre_label=self.pre_label, 
                                   spans=spans)
        return sentence
        
    def _transform(self, X):
        raise NotImplementedError


def handle_ws(in_reg_pattern):
    return '^{0}$|^{0}(\s)|(\s){0}(\s)|(\s){0}$'.format(in_reg_pattern)


class KeywordMatchPreProcessor(PreProcessor):

    def __init__(self, 
                 pre_label,
                 match_texts):
        
        self.pre_label = pre_label
        self.match_texts = sorted(match_texts, key = lambda x:-len(x))
    
    def _check_ws(self, match):
        s0, s1 = match.span()
        
        if match[0][0].isspace():
            s0+=1
        
        if match[0][-1].isspace():
            s1-=1
        
        return (s0, s1)
        
    def _find_matches(self, subtext, text):
        reg  =  re.compile(handle_ws(subtext))
        yield from map(self._check_ws, re.finditer(reg, text))
        
    def __check_no_overlap(self, s1, s2):
        if s2[0] > s1[1] or s1[0] > s2[1]:
            return True
        else:
            return False
        
    def _check_no_overlap(self, all_spans, new_span):
        return all(self.__check_no_overlap(ai, new_span) for ai in all_spans)
    
    def _check_spans(self, all_spans, new_spans):
        
        good_spans = list()
        for ni in new_spans:
            if self._check_no_overlap(all_spans, ni):
                good_spans.append(ni)
                all_spans.append(ni)
                    
        return all_spans, good_spans
        
    def _transform(self, text):
        
        all_spans = []
        out_spans = []
        for mi in self.match_texts:
            if mi in text:
                new_spans = list(self._find_matches(mi, text))
                all_spans, good_spans = self._check_spans(all_spans, new_spans)                
                out_spans += good_spans
        return out_spans        


class RegexMatchPreProcessor(PreProcessor):

    def __init__(self, regex, pre_label):
        self.regex = regex
        self.pre_label = pre_label
    
    def _check_ws(self, match):
        s0, s1 = match.span()
        
        if match[0][0].isspace():
            s0+=1
        
        if match[0][-1].isspace():
            s1-=1
        
        return (s0, s1)
        
    def _find_matches(self, subtext, text):
        reg  =  re.compile(handle_ws(subtext))
        yield from map(self._check_ws, re.finditer(reg, text))
        
    def __check_no_overlap(self, s1, s2):
        if s2[0] > s1[1] or s1[0] > s2[1]:
            return True
        else:
            return False
        
    def _check_no_overlap(self, all_spans, new_span):
        return all(self.__check_no_overlap(ai, new_span) for ai in all_spans)
    
    def _check_spans(self, all_spans, new_spans):
        
        good_spans = list()
        for ni in new_spans:
            if self._check_no_overlap(all_spans, ni):
                good_spans.append(ni)
                all_spans.append(ni)
                    
        return all_spans, good_spans
        
    def _transform(self, text):
        
        all_spans = []

        new_spans = list(self._find_matches(self.regex, text))
        all_spans, good_spans = self._check_spans(all_spans, new_spans)                
        return good_spans
