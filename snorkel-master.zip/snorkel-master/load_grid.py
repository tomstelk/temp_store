import json 
import os
import importlib
import logging

from pathlib import Path
from collections import OrderedDict
from snorkel.labeling import labeling_function, LabelingFunction
from snorkel_utils import resources_decorate

logger = logging.getLogger(__name__)


def _make_lf(func, name, resources={}):

    if isinstance(func, LabelingFunction):
        return func
    elif not resources:
        return labeling_function(name=name)(func)
    else:
        return resources_decorate(func, **resources)


def load_lf(mod_dict):
    """ Load function defined by {file: fil, lfs: [n1, n2], resource:[r1, r2]}
    """
    logger.debug('Loading {}'.format(mod_dict['file']))
    mod = importlib.import_module(mod_dict['file'])
    lfs = []
    for lf in mod_dict['lfs']:
        func = getattr(mod, lf)
        resources = mod_dict['resources'].get(lf, {})
        lfs.append(_make_lf(func, lf, resources))
    return lfs


def load_lf_grid(path):
    """ Load lf grid definition from file path
    """
    with open(path) as f:
        grid = json.load(f)

    new_dict = OrderedDict({})
    for k, mod_dict in grid.items():
        new_dict[k] = load_lf(mod_dict)
    return new_dict


def load_files_grid(path):
    """ Load files grid
    """
    with open(path) as f:
        grid = json.load(f)
    base_dir = Path(grid['base_path'])
    return [base_dir/f for f in grid['files']]


if __name__ == '__main__':
    path = 'lf_grid.json'
    grid = load_lf_grid(path)
    fgrid = load_files_grid('files_grid.json')
