# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 19:59:40 2019

@author: user
"""

import os

THIS_DIR =os.path.dirname(os.path.realpath(__file__))
STATIC_DIR = os.path.join(THIS_DIR, 'static')


PREPROCESSORS_MODULE = 'preprocess.preprocessors'
STATIC_UTILS_MODULE = 'static.static_utils'
