# -*- coding: utf-8 -*-
import os

from importlib import import_module
from settings import PREPROCESSORS_MODULE, STATIC_UTILS_MODULE
from toolz import compose




def make_keyword_pp(klass,
                    pre_label,
                    get_text_callable):
    
    k = getattr(import_module(PREPROCESSORS_MODULE), klass)
    c = getattr(import_module(STATIC_UTILS_MODULE), get_text_callable)
    
    return k(match_texts = c(), 
             pre_label = pre_label)


def make_ws_preprocessor(base_dir):
    """ Make keyword pre_processor for every file in base_dir
    """
    files = [os.path.join(base_dir, f) for f in os.listdir(base_dir)]
    preprocessors = []
    for fil in files:
        with open(fil, 'r') as f:
            texts = [u.strip() for u in f.readlines()]
        preprocessor = AlcoholPreProcessor(texts)
        preprocessor.label = fil
        preprocessors.append(preprocessor)
    return preprocessors


preprocessor_cfg = [
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'ullage',
    'get_text_callable' : 'get_ullage',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'label',
    'get_text_callable' : 'get_label',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'cork',
    'get_text_callable' : 'get_cork',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'capsule',
    'get_text_callable' : 'get_capsule',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'colour',
    'get_text_callable' : 'get_colour',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'provenance',
    'get_text_callable' : 'get_provenance',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'box',
    'get_text_callable' : 'get_box',
    'type' : 'keyword'
    }
]

pps = list()
for ppi in preprocessor_cfg:
    if ppi['type']:
        pp = make_keyword_pp(klass = ppi['klass'],
                             pre_label = ppi['pre_label'],
                             get_text_callable = ppi['get_text_callable'],)
    pps.append(pp)

pre_processor = compose(*pps)    
