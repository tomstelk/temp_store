# Weak supervision/Snorkel

Repository to track our efforts using a Snorkel/Weak supervision approach to generate training data.
