# -*- coding: utf-8 -*-
import re
from toolz import compose



class SpacyLabelFinder():

    def __init__(self, labels):
        self.labels = labels
    
    def _sub_span(self, s1, s2):
        return s1[0]>=s2[0] and s1[1]<=s2[1]
    
    def __call__(self, span):
        for li in self.labels:
            if self._sub_span(span, (li[0], li[1])):
                return li[2]

get_span = lambda m : m.span()

def spacy_to_lf_parser(labelled_text):
    label_finder = SpacyLabelFinder(labelled_text['labels'])

    get_labels = compose(label_finder, get_span)

    text = labelled_text['text']
    tokens = list(re.finditer('[^\s]+', text))
    return {'tokens' : [ti[0] for ti in tokens],
            'text' : text,
            'labels' : list(map(get_labels, tokens))}
