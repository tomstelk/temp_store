# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 16:04:41 2019

@author: user
"""


from TestLF import TestLF
import import_utils
from utils.json_utils import get_json
import unittest
from static.static_utils import get_ullage
from lf.LFBaseClasses import LFPreLabelled
from collections import namedtuple

class TestLFPreLabelled(TestLF):

    def test_ullage_lf(self):
        
        ullage_pre_labelled = LFPreLabelled('ullage')
        dummy_pp_token = namedtuple('dummy_pp_token', ['token', 'label'])
        make_pp_token = lambda t_l : dummy_pp_token(token = t_l[0], label  = t_l[1])
                                                
        
        token_label = [('some', None),
                        ('random', 'ullage'),
                        ('words', 'not_ullage'),
                        ('some', None),
                        ('are', 'alcohol'),
                        ('labelled', 'ullage')]
        
        test_pp_tokens = list(map(make_pp_token, token_label))
        
        test_res = list(map(ullage_pre_labelled, test_pp_tokens))
        test_compare = [-1, 1, -1, -1, -1, 1]
        
        
        self.assertEqual (test_res, 
                          test_compare)



if __name__ == '__main__':
    unittest.main()