# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 16:03:38 2019

@author: user
"""
import sys
import os

parent_dir = os.path.abspath('..')
sys.path.append(parent_dir)

import unittest 

class TestPreProcessor(unittest.TestCase):
    pass

