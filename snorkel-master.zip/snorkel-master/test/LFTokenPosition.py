# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 16:04:41 2019

@author: user
"""


from TestLF import TestLF
import import_utils
import unittest
from lf.LFBaseClasses import LFTokenPosition
from classes.Candidate import Sentence


class TestLFTokenPosition(TestLF):

    
    def setUp(self):
        
        self.test_sentence = Sentence(text = 'hello I am a good boy, hello again',
                     text_id = 0)
        
    def test_lf_token_position(self):
        
        test_lf = LFTokenPosition(lower = 5, 
                                  upper = 9,
                                  _for=True)
        
        test_result = list(map(test_lf, self.test_sentence.split()))
        
        compare_result = [-1, -1, -1, -1, -1, 1, 1, 1]
        
        
        self.assertEqual (test_result, 
                          compare_result)


if __name__ == '__main__':
    unittest.main()