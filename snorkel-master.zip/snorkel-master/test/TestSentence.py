# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 16:04:41 2019

@author: user
"""


from TestPreProcessor import TestPreProcessor
import import_utils
from utils.json_utils import get_json, print_json_pretty
import unittest
from classes.Candidate import Sentence


class TestSentence(TestPreProcessor):

        
        
    def test_from_to_json(self):
        
        test_pre = get_json('./test_preproccesedtext.json')
        test_post = test_pre
        
        
        p = Sentence.from_json(test_pre)
       
        self.assertEqual(p.to_json(), test_post)
        
    def test_add_pre_label(self):
        
        j =get_json('./test_preproccesedtext.json')
        test_pre = j['text']
        test_post = j
        test_label = 'ullage'
        test_label_spans = j['pre_labels']['ullage']
        test_post = get_json('./test_preproccesedtext.json')
        
        
        p = Sentence(test_pre,text_id =0)
        p.add_pre_label(pre_label = test_label, 
                        spans = test_label_spans)
        
        
        self.assertEqual(p.to_json(), test_post)
        
        
    def test_split(self):
        
        jpre = get_json('./test_preproccesedtext_split_pre.json')
        jpost =get_json('./test_preproccesedtext_split_post.json')
        
        p = Sentence.from_json(jpre)
        res = list(p.split())
        
        self.assertEqual(jpost,[ri.to_json() for ri in res] )


    def test_candidate_sentence(self):
        
        text = 'hello I am a great sentence nice to meet you'
        s = Sentence(text, 0)
        tokens = s.split()
        
        ss0 = tokens[0].sentence
        ss4 = tokens[4].sentence
        ss_end = tokens[-1].sentence
        
        
        self.assertEqual(ss0, tokens)
        self.assertEqual(ss4, tokens)
        self.assertEqual(ss_end, tokens)
        
    def test_candidate_ngrams(self):
        
        text = 'hello I am a great sentence nice to meet you'
        s = Sentence(text, 0)
        tokens = s.split()
        
        ng1 = tokens[0].ngrams(2, -1)
        ng2 = tokens[0].ngrams(2, 0)
        ng3 = tokens[0].ngrams(3, 2)
        ng4 = tokens[8].ngrams(1, -2)
        ng5 = tokens[8].ngrams(1, 4)
        
        res1 = []
        res2 = []
        res3 = [(tokens[0], tokens[1], tokens[2]), 
                    (tokens[1], tokens[2], tokens[3])]
        res4 = [(tokens[7],), (tokens[8],)]
        res5 = [(tokens[8],), (tokens[9],)]
        
        
        self.assertEqual(ng1, res1)
        self.assertEqual(ng2, res2)
        self.assertEqual(ng3, res3)
        self.assertEqual(ng4, res4)
        self.assertEqual(ng5, res5)
        
        
        
        
        
        
if __name__ == '__main__':
    unittest.main()