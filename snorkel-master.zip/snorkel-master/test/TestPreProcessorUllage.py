# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 16:04:41 2019

@author: user
"""


from TestPreProcessor import TestPreProcessor
from preprocess.preprocessors import KeywordMatchPreProcessor
from classes.Candidate import Sentence
import import_utils
from utils.json_utils import get_json
import unittest
from static.static_utils import get_ullage


class TestPreProcessorUllage(TestPreProcessor):

    
    def setUp(self):
        self.u = KeywordMatchPreProcessor(match_texts = get_ullage(),
                                          pre_label = 'ullage')
        
    def test_ullage_label(self):
        
        to_json  = lambda ri : ri.to_json()
        
        in_text = get_json('./test_preproc_ullage_pre.json')
        test_post = get_json('./test_preproc_ullage_post.json')
        
        test_pre = list(map(Sentence.from_json, in_text ))
        
        res = list(map(self.u, test_pre))
        res_json = list(map(to_json, res))
        
        self.assertEqual (test_post, res_json)



if __name__ == '__main__':
    unittest.main()