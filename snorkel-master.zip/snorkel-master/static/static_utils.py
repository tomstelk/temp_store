# -*- coding: utf-8 -*-
import import_utils
from settings import STATIC_DIR
import os
from utils.json_utils import get_json
from itertools import product, chain
from static.expand_ullage import expand_ullage
from toolz import compose

QD_QR_DIR = os.path.join(STATIC_DIR, 'cfg_qd_qr')
KEYWORD_DIR = os.path.join(STATIC_DIR, 'keyword')


def get_synonyms(key=None):
    j = get_json(os.path.join(STATIC_DIR, 'synonyms.json'))
    
    if key:
        return j[key]
    else:
        return j
    
    
def _parse_static(j):
    for ti in j['terminals'].values():
        yield from ti
        
def parse_static(j):
    return list(_parse_static(j))


parse_ullage = compose(parse_static, expand_ullage)

def _get_intensifiers(language):
    j = get_json(os.path.join(KEYWORD_DIR, 'intensifier_{}.json'.format(language)))
    return parse_static(j)
    
def merge_qd_qr(field, 
                language, 
                inc_intensifier  = False):
    
    
    qd_file = os.path.join(QD_QR_DIR, '{}_qd_{}.json'.format(field, language))
    qd = parse_static(get_json(qd_file))
    
    qr_file = os.path.join(QD_QR_DIR, '{}_qr_{}.json'.format(field, language))
    qr = parse_static(get_json(qr_file))
    
    
    if inc_intensifier:
        intens = _get_intensifiers(language)
        intens.append(None)    
    else:
        intens = [None]
        
    intens_qr_qd = list(product(intens, qr, qd))
    
    make_str_i_qr_qd =  lambda i_qr_qd : '{} {} {}'.format(i_qr_qd[0], i_qr_qd[1], i_qr_qd[2]) \
                                if i_qr_qd[0] \
                                else '{} {}'.format(i_qr_qd[1], i_qr_qd[2])
    
    make_str_qd_i_qr =  lambda i_qr_qd : '{} {} {}'.format(i_qr_qd[2], i_qr_qd[0], i_qr_qd[1]) \
                                if i_qr_qd[0] \
                                else '{} {}'.format(i_qr_qd[2], i_qr_qd[1])
    
    #make_str_qr = lambda i_qr_qd : i_qr_qd[1]
    str_i_qr_qd = map(make_str_i_qr_qd, intens_qr_qd)
    str_qd_i_qr = map(make_str_qd_i_qr, intens_qr_qd)
    
    return list(chain.from_iterable([str_i_qr_qd, str_qd_i_qr]))
    

def get_keywords(field, 
                language,
                parser = None,
                intensified = True):
    
    if not parser:
        parser = parse_static
    
    if intensified and language:
        kw_filenames = ['{}_terms_i_{}_{}.json'.format(field, i, language) for i in range(1,4)]
    elif language:
        kw_filenames = ['{}_{}.json'.format(field, language)]
    else:
        kw_filenames = ['{}.json'.format(field)]
        
    js = [get_json(os.path.join(KEYWORD_DIR, kwi)) for kwi in kw_filenames]
    
    return list(chain.from_iterable((parser(j) for j in js)))
    
    
def get_keywords_and_qdqr(field, 
                          language, 
                          inc_intensifier = False):
    
    qd_qr = merge_qd_qr(field = field, 
                        language = language, 
                        inc_intensifier =inc_intensifier)
    
    kws = get_keywords(field = field, 
                       language = language,
                       intensified = True)
    
    return qd_qr + kws


get_ullage  = lambda : get_keywords(field = 'ullage',
                                    language = 'english', 
                                    parser = parse_ullage,
                                    intensified = False)


get_label = lambda : get_keywords_and_qdqr(field = 'label',
                                           language = 'english')


get_cork = lambda : get_keywords_and_qdqr(field = 'cork',
                                           language = 'english')


get_capsule = lambda : get_keywords_and_qdqr(field = 'capsule',
                                           language = 'english')

get_colour = lambda : get_keywords_and_qdqr(field = 'colour',
                                           language = 'english')

get_provenance = lambda : get_keywords(field = 'provenance',
                                         language = 'english',
                                         intensified = False)

get_box = lambda : get_keywords(field = 'box',
                                language = None,
                                intensified = False)
