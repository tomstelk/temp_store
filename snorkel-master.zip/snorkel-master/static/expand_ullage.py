# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""


import import_utils
from itertools import product, chain
from copy import copy
import re 

metric = ['cms', 'cm']
imperial = ['inches', 'inch', 'in']
levels = ['filling', 'fillings', 'ullage', 'levels', 'level', 'fills', 'fill']

reg_metric = re.compile('|'.join(metric))
reg_imperial = re.compile('|'.join(imperial))
reg_levels = re.compile('|'.join(levels))
reg_levels_start = re.compile('^' + '|^'.join(levels))
reg_levels_end = re.compile('$|'.join(levels) + '$')

def yield_terms(term):
    if re.findall('\d+', term):
        if re.findall(reg_imperial, term): 
            for i in imperial:
                yield re.sub(reg_imperial, i, term)

        elif re.findall(reg_metric, term): 
            for m in metric:
                yield re.sub(reg_metric, m, term)

    elif re.findall(reg_levels_start, term) or re.findall(reg_levels_end, term):
        base = re.sub(reg_levels, '', term).strip()
        for li in levels:
            yield '{} {}'.format(li, base)
            yield '{} {}'.format(base, li)

    elif len(term) > 2:
        yield term



def expand_terms(terms):
    new_terms = set(chain.from_iterable(map(yield_terms, terms)))
    return list(new_terms)


def expand_ullage(ullage):
    out = copy(ullage)
    out['terminals'] = {k : expand_terms(v) for k,v in ullage['terminals'].items()}

    return out

