# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""
'''

import import_utils

from static.alctions import get_brentwood_texts, get_brentwood_2grams, get_spectrum_2grams



b=list(get_brentwood_2grams())
s=set(get_spectrum_2grams())

b_s = sorted([bi for bi in b if bi not in s ])
'''

for bsi in b_s:
    print(bsi)
#sl_problem = list(filter(lambda ti: ' and ' in ti , sl))
