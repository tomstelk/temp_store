# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""

import import_utils
from utils.json_utils import get_json, print_json_pretty
import os
from static.static_utils import get_winesearcher_producers
from itertools import product
from preprocess.preprocessors import KeywordMatchPreProcessor
from classes.Candidate import Sentence
from lf.LFBaseClasses import LFPreProcessed
from classes.LFEvalSuite import LFEvalSuite

labelled_data_dir = os.path.abspath('../labelled_test_data')
lwj = get_json(os.path.join(labelled_data_dir, 'spacy_wine_name.json'))

p = get_winesearcher_producers()

alcohol_producer = 'alcohol_producer'
preprocess_producer = KeywordMatchPreProcessor(pre_label= alcohol_producer,
                                               match_texts = p)

sentences = map(lambda li : Sentence(li['text']), lwj)


plabel_ws_prod_sentences = list(map(preprocess_producer, sentences))



lf_alcohol_producer = LFPreProcessed(alcohol_producer)


lf_eval = LFEvalSuite(test_data = lwj,
                      pre_processor  = preprocess_producer)



res = lf_eval(lf = lf_alcohol_producer, 
              target = 'alcohol')


'''
for pi, lwi in product(p, lwj):
    
    if pi and pi in lwi['text']:
        hits.append((pi, lwi))

'''


'''
class FilterUnique():
    
    def __init__(self):
        self.seen = set()
    def __call__(self, x):
        if x in self.seen:
            return False
        else:
            self.seen.add(x)
            return True
        
        
f = FilterUnique()

unique_wine = list(filter(lambda ji : f(ji['text']), lwj))

print_json_pretty(unique_wine,os.path.join(labelled_data_dir, 'spacy_whiskey_name_uniq.json') )
'''