# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""

from classes.LFEvalSuite import LFEvalSuite




t = [{
        "labels": [
            [
                40,
                41,
                "quantity"
            ],
            [
                0,
                4,
                "year"
            ],
            [
                5,
                39,
                "alcohol"
            ]
        ],
        "text": "1994 fonseca vintage port graham taylor 3 bottles"
    },
    {
        "labels": [
            [
                0,
                4,
                "year"
            ],
            [
                5,
                41,
                "alcohol"
            ],
            [
                42,
                44,
                "quantity"
            ],
            [
                56,
                62,
                "vol_size"
            ],
            [
                63,
                66,
                "box"
            ]
        ],
        "text": "2005 silval vintage porto quinta do noval 12 bottles of 0.75 l owc"
    }]




lfeval = LFEvalSuite(t)

def year_lf(token):
    if len(token)==4 and token.isnumeric():
        return 1
    else:
        return -1
    

res = lfeval(year_lf, 'year')