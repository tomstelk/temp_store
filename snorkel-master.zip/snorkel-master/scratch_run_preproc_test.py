# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""



import import_utils
from utils.yaml_utils import get_yaml_full_load
from utils.json_utils import get_json, print_json_pretty
from classes.Candidate import Sentence
import os
from preprocess.PreProcessBuilder import PreProcessBuilder
from lf.LFBaseClasses import LFPreProcessed
from classes.LFEvalSuite import LFEvalSuite
from copy import deepcopy
cfg = [
       {'klass' : 'KeywordMatchCallableInitPreProcessor',
        'module' : 'preprocess.preprocessors',
        'name' : 'ws_sub_region',
        'pre_label' : 'alcohol',
        'kwargs' : {
                'pre_label': 'alcohol',
                'get_text_callable': None,
                'get_text_module': 'static.static_callables'
                }
        }
        ]       
       
#get_yaml_full_load('./preprocessors.yml')

labelled_data_dir = os.path.abspath('../labelled_test_data')
lwj = get_json(os.path.join(labelled_data_dir, 'spacy_wine_name.json'))

lf_alcohol_test = LFPreProcessed('alcohol')

callables = ['get_ws_region_split',
             'get_ws_region',
             'get_ws_sub_region_split',
             'get_ws_sub_region',
             'get_ws_sub_sub_region_split',
             'get_ws_sub_sub_region',
             'get_ws_sub_sub_sub_region_split',
             'get_ws_sub_sub_sub_region',
             'get_ws_producer_split',
             'get_ws_producer']


out_res = list()
for ci in callables:
    
    cfgi = deepcopy(cfg)
    cfgi[0]['kwargs']['get_text_callable'] = ci
    p = PreProcessBuilder(cfgi)
    lf_eval = LFEvalSuite(test_data = lwj,
                          pre_processor  = p)
    res = lf_eval(lf = lf_alcohol_test, 
                      target = 'alcohol')

    print('--------------------------------------------------------------------')
    print(ci)
    print(res['accuracy'])
    print()
    
    out_res.append((ci, res))


