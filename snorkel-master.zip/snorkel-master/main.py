import os
import numpy as np
import json
import re
import pandas as pd
import logging
import pudb
import pprint as pp

from labeler import Labeler

from snorkel.labeling import LFAnalysis
from snorkel.labeling import labeling_function
from snorkel.labeling import LabelModel, PandasLFApplier, LFApplier

from utils import align_tokens, import_lf
from candidate import Candidate
from itertools import groupby

import lf.whiskey.name.lf as name_lf

logger = logging.getLogger(__name__)


if __name__ == '__main__':

    with open('./data/whiskey_text_data_20191024.json') as f:
        unseen_data = [{"text": " ".join(d["description"]), "labels": [] } for d in json.load(f)]

    with open('./data/spacy_whiskey_description.json') as f:
        unseen_data = [{'text': t['text'], 'labels': []} for t in json.load(f)]

    model_args = dict(n_epochs=1000, lr=0.001, log_freq=100, seed=123)

    lfs = import_lf('lf.whiskey.abv.lf')
    labeler = Labeler('abv')
    labeled_data = labeler.annotate(unseen_data, lfs, **model_args)

    lfs = import_lf('lf.whiskey.lf')
    labeler = Labeler('vol_size')
    labeled_data = labeler.annotate(labeled_data, lfs, **model_args)

    lfs = import_lf('lf.whiskey.name.lf')
    labeler = Labeler('name')
    labeled_data = labeler.annotate(unseen_data, lfs, **model_args)

    extracted = [
        {
            'text': t['text'], 
            'labels': [
                {'label': u[2], 
                 'value': t['text'][u[0]:u[1]]} for u in t['labels']]} 
            for t in unseen_data
    ]

    with open('result.json', 'w') as f:
        json.dump(extracted, f)

    with open('final.json', 'w') as f:
        json.dump(unseen_data, f)

    pp.pprint(extracted)
