# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 14:50:05 2019

@author: 1613098
"""
#from functions.spacy_to_lf_parser import spacy_to_lf_parser
from classes.Candidate import Sentence
from toolz import compose
import random
from sklearn.metrics import precision_recall_fscore_support

class SpacyLabelFinder():

    def __init__(self, labels):
        self.labels = labels
    
    def _sub_span(self, s1, s2):
        return s1[0]>=s2[0] and s1[1]<=s2[1]
    
    def __call__(self, span):
        for li in self.labels:
            if self._sub_span(span, (li[0], li[1])):
                return li[2]

get_span = lambda m : m.span

def spacy_to_lf_parser(labelled_text, 
                       pre_processor = None):
    
    label_finder = SpacyLabelFinder(labelled_text['labels'])
    get_labels = compose(label_finder, get_span)
    
    #text_id = random.randint(1,1000000)
    
    sentence = Sentence(labelled_text['text'])#, text_id = text_id)
    
    if pre_processor:
        sentence = pre_processor(sentence)
    
    candidates = sentence.split()#list(re.finditer('[^\s]+', text))
    
    return {'candidates' : candidates,
            'sentence' : sentence,
            'labels' : list(map(get_labels, candidates))}


class LFEvalSuite():
    
    def __init__(self,
                 test_data = None,
                 pre_processor = None):
        

        if test_data:
            self.test_data = self._parse_test_data(test_data, pre_processor)
        else:
            self.test_data = None
        
    def load(self, 
             test_data,
             pre_processor = None):
        
        self.test_data = self._parse_test_data(test_data, pre_processor)
        
    def _parse_test_data(self, 
                         test_data, 
                         pre_processor = None):
        out = list()
        for ti in test_data:
            label_finder = SpacyLabelFinder(ti['labels'])
            get_labels = compose(label_finder, get_span)
            sentence = Sentence(ti['text'])
            if pre_processor:
                sentence = pre_processor(sentence)
                candidates = sentence.split()
                oi = {'candidates' : candidates,
                      'sentence' : sentence,
                      'labels' : list(map(get_labels, candidates))}
                
                out.append(oi)
                
        
        return out#list(map(spacy_to_lf_parser, test_data))        
            
    def _token_test(self, lf, token, label, target):
    
        if label == target:
            positive = 1
        else:
            positive = 0
            
        if lf(token)==1:
            hit = 1
        else:
            hit = 0
            
        return (hit, positive)
            
    def prfs(self, res):
        
        return precision_recall_fscore_support([ri[1] for ri in res],
                                               [ri[0] for ri in res],
                                               average = 'binary')
        
    def __call__(self, lf, target):
        
        res = list()
        missed = list()
        mislabelled = list()
        
        for ti in self.test_data:
            for j, tj in enumerate(ti['candidates']):
                resi = self._token_test(lf, tj, ti['labels'][j], target)
                res.append(resi)
                if resi[0]==1 and resi[1]==0:
                    mislabelled.append((tj, ti['sentence']))
                elif resi[0]==0 and resi[1]==1: 
                    missed.append((tj, ti['sentence']))
                    
        
        
        p, f, r, s = self.prfs(res)
        
        s  = sum([ri[1] for ri in res])
        accuracy  = {
                        'p' : p,
                        'r' : r,
                        'f' : f,
                        's': s
                                }
        
        return {'accuracy' : accuracy,
                'mislabelled':mislabelled,
                'missed':missed}
        
        