# -*- coding: utf-8 -*-
"""
Created on Tue Jan 28 13:46:41 2020

@author: 1613098
"""

from importlib import import_module

class LearningFunctionBuilder():
    
    def __init__(self, cfg):
        self.cfg = cfg
        self.lfs = {ti: self._build_lfs(cfg['labels'], ti) for ti in cfg['types']}
        
    def _check_type_valid(self, cfg, _type):
        if 'types' in cfg and _type not in cfg['types']:
            return False
        else:
            return True
        
    def _build_lfs(self, cfg, _type):
        
        out = dict()
        
        for li, cfgi in cfg.items():
            
            if not self._check_type_valid(cfgi, _type):
                continue
            
            if 'module' in cfgi:
                m = import_module(cfgi['module'])
            else:
                m = None
                
            out[li] = [self._build_lf(fi, m) for fi in cfgi['functions'] if self._check_type_valid(fi, _type)]
            
        return out
    
    def _build_lf(self, fcfg, m):
        
        if 'module' in fcfg:
            m = import_module(fcfg['module'])
            
        return getattr(m, fcfg['name'])
        
    def to_json(self):
        return self.cfg
    
    @classmethod
    def from_json(cls, j):
        return cls(j)
    