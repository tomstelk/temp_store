# -*- coding: utf-8 -*-
"""
Created on Mon Jan 27 17:31:42 2020

@author: 1613098
"""
from importlib import import_module
from toolz import compose


class PreProcessBuilder():
    
    
    def __init__(self,
                 preproc_cfgs):
        
        self.preproc_cfgs = preproc_cfgs
        self.names = [pi['name'] for pi in preproc_cfgs]
        self.pre_procs = list(map(self._build_preproc, preproc_cfgs))
        
    def _build_preproc(self, cfg):
        
        m = import_module(cfg['module'])
        k = getattr(m, cfg['klass'])
        
        return k(**cfg['kwargs'])
        
    @classmethod
    def from_json(cls, j):
        
        new = cls(j['preproc_cfgs'])
        ks = [getattr(import_module(pi['module']), pi['klass']) for pi in j['preproc_cfgs']]
        
        new.pre_procs = [ki.from_json(pi) for (ki, pi) in zip(ks, j['pre_procs'])]
        
        return new
        
    def to_json(self):
        
        out = {
                'preproc_cfgs' : self.preproc_cfgs,
                'names' : self.names,
                'pre_procs' : [pi.to_json() for pi in self.pre_procs]
               }
        
        return out
    
    def __call__(self, sentence):
        return compose(*self.pre_procs)(sentence)