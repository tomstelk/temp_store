# -*- coding: utf-8 -*-
import import_utils
from classes.Candidate import Sentence
import import_utils
from utils.json_utils import get_json, print_json_pretty
from build_preprocessor import pre_processor
import csv
import json

def get_some_alcohol():
    with open('./alcohol_text.csv') as f:
        some_alcohol = csv.reader(f)
        next(some_alcohol)
        for ai in some_alcohol:
            yield ai[0]
    
some_alcohol = list(get_some_alcohol())

with open('./data/spacy_whiskey_description.json') as f:
    data = json.load(f)

some_alcohol = [t['text'] for t in data]

n = range(len(some_alcohol))
make_ppt = lambda ti : Sentence(ti[0], ti[1])
init_ppt = list(map(make_ppt,  zip(some_alcohol, n)))

res = list(map(pre_processor, init_ppt))

print_json_pretty([ri.to_json() for ri in res], 
                   'spacy_whiskey_preprocessed.json')

test_label = 'ullage'

for ri in res:
    if test_label in ri._pre_labels:
        print('---------------------------------------------------------------------------------')
        print (ri)
        for tli in ri._pre_labels[test_label]:
            print()
            print('----------')
            s = tli[0]
            e = tli[1]

            print('label: "{}"'.format(ri[s:e]))
            print('context: "{}"'.format(ri[s-5:e+5]))
            print()
