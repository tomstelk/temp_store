import logging

from snorkel.labeling import LabelModel, LFApplier

from classes import Candidate
from itertools import groupby

import pudb

logger = logging.getLogger(__name__)


class Labeler(object):

    def __init__(self, label, use_label_model=True, cardinality=2, threshold=.5, progress_bar=True):
        self.label = label
        self.progress_bar = progress_bar
        self.threshold = threshold
        self.cardinality = cardinality
        self.use_label_model = use_label_model
    
    def annotate(self, candidates, lfs, **kwargs):
        """ Given lfs and candidates add and reconciliate labels

        Add label to candidate
        """
        assert len(lfs) >= 3, "Please provide at least 3 labeling functions"

        applier = LFApplier(lfs)
        L_train = applier.apply(candidates, progress_bar=True)

        label_model = LabelModel(cardinality=self.cardinality, verbose=True)
        self.label_model = label_model

        label_model.fit(L_train=L_train, **kwargs)

        y_probs = label_model.predict_proba(L_train)
        labels = 1*(y_probs > self.threshold)
        labels = labels[:, 1]
        for i in range(len(candidates)):
            # Tag annotated candidates
            candidates[i].label_ = labels[i]
            if labels[i] == 1:
                candidates[i].label = self.label

        return candidates

    def annotate_sentences(self, sentences, candidates):
        """ From annotated candidates updates sentences for final results
        """

        for sentence_id, groups in groupby(candidates, lambda x: x.text_id):
            cands = list(groups)
            filtered = filter(lambda x: x.label_ == 1, cands)
            labeled = [(c.span[0], c.span[1], self.label) for c in filtered]
            if labeled:
                labeled = self.reconciliate(labeled)
                spans = [(start, end) for start, end, _ in labeled]
                sentences[sentence_id].add_label(self.label, spans)

        return sentences

    @staticmethod
    def reconciliate(labels):
        """ Reconciliate adjacent annotations
        """
        if len(labels) == 1:
            return labels

        new_labels = []
        n = len(labels)
        left, right, label = labels[0]
        for i in range(1, n):
            l, r, _ = labels[i]
            if l == right + 1:
                right = r
            else:
                new_labels.append((left, right, label))
                left = l
                right = r
        new_labels.append((left, right, label))
        return new_labels
