import logging

from snorkel_utils import align_tokens

logger = logging.getLogger(__name__)


def _overlap(s1, s2):
    """ Is span s1 included in span s2
    """
    a, b = s1
    c, d = s2
    return c <= a and b <= d


class Candidate(object):
    """ Object wrapper to hold everything LFs needs
    """

    def __init__(self, token, span, sentence_id, 
            sentences, span_id, candidate_id, candidates, annotation=None):
        self.token = token
        self.span = span
        self.sentence_id = sentence_id
        self.sentences = sentences
        self.span_id = span_id
        self.annotation = annotation
        self.candidate_id = candidate_id
        self.candidates = candidates
    
    @property
    def text(self):
        return self.sentences[self.sentence_id]

    def ngrams(self, n=2):
        """ Generate ngrams on the fly
        Assumes whitespace tokens (i.e sentence is already tokenized)
        """
        tokens = self.text.split()
        return zip(*[tokens[i:] for i in range(n)])

    def tokens_left(self, n=2):
        ix = self.span_id
        tokens = self.text.split()
        return ' '.join(tokens[(ix-n)*(ix-n>0):ix])

    def tokens_right(self, n=2):
        ix = self.span_id
        tokens = self.text.split()
        cross = ix+1+n<len(tokens)
        return ' '.join(tokens[ix+1:(ix+1+n)*(cross)+len(tokens)*(1-cross)])

    def cand_right(self, n=2):
        ix = self.span_id
        N = len(self.text.split())
        start = ix+1
        end = ix+1+n if ix+1+n <= N else N 
        return self.candidates[start:end]

    def cand_left(self, n=2):
        ix = self.span_id
        end = ix
        start = ix-n if ix-n >= 0 else 0
        return self.candidates[start:end]

    @classmethod
    def from_iter(cls, samples):
        """ Small helper to generate list of candidates from 
        a text iterable. 
        
        Returns the candidate list and the dictionary mapping id => text
        """
        n = len(samples)
        logger.debug(f'Spliting {n} sentences into candidates')
        sentences = {i: t['text'] for i, t in enumerate(samples)}
        candidates = []

        c = 0
        for i, sent in sentences.items():
            entities = samples[i]['labels']
            for span_id, (token, span) in enumerate(zip(sent.split(), align_tokens(sent))):
                annotation = None
                for ent in entities:
                    if _overlap(span, (ent[0], ent[1])):
                        annotation = ent[2]
                cand = Candidate(token, span, i, sentences, span_id, c, candidates, annotation=annotation)
                c += 1
                candidates.append(cand)

        n_c = len(candidates)
        logger.debug(f'Generated {n_c} candidates')
        return candidates, sentences


if __name__ == '__main__':
    text = "this is a sentence"
    entities = [(0, 4, 'adv'), (7, 12, 'verb')]
    #sample = [{"text": text, "labels": entities} for i in range(10000)]
    sample = [{'text': text, 'labels': entities}]
    candidates, sentences = Candidate.from_iter(sample)
