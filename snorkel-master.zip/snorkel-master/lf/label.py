# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled, LFHardAntiPreLabelled, LFPreviousToken, LFAnd, LFNextToken
from lf.lf_generic import ABSTAIN, FOR_VOTE, AGAINST
from lf.LFBaseClasses import LFNearValues

label_pre_labelled = LFPreLabelled('label')
label_hard_anti_provenance = LFHardAntiPreLabelled('label')
