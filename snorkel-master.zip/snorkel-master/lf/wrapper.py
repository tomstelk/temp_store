import logging

from functools import wraps

logger = logging.getLogger(__name__)

FOR = 1
AGAINST = 0
ABSTAIN = -1


def labeled(f):
    """ For alcohol, we don't consider overlap
    """
    @wraps(f)
    def wrapper(candidate, *args, **kwargs):
        if candidate.label:
            return AGAINST
        return f(candidate, *args, **kwargs)
    return wrapper
