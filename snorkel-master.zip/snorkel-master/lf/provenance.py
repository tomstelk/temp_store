# -*- coding: utf-8 -*-
import re

from lf.LFBaseClasses import LFPreLabelled
from lf.lf_generic import ABSTAIN, FOR_VOTE, AGAINST


def lf_provenance_recently_removed(token):
    
    s = ' '.join(token.sentence)
    if 'recently removed' in s:
        rr_pos = re.search('recently removed', s).span()[1]
        if rr_pos<token.span[0]:
            return FOR_VOTE
        
    return ABSTAIN

lf_provenance_pre_labelled = LFPreLabelled('provenance')
