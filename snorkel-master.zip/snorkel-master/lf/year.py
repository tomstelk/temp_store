# -*- coding: utf-8 -*-
from lf.lf_generic import lf_year_generic, lf_not_year_generic
from static.static_utils import get_synonyms
from lf.LFBaseClasses import (LFNearNumeric, LFAnd, LFNearValues, 
        LFForInverse, LFTokenPosition, LFNextToken, LFForNot, LFNearPreLabelled)

#sub-functions
other_year = LFNearValues(left_range=2,
                 right_range=2,
                 values= ['bottled', 'bottling', 'distilled', 'distilling', 'harvested', 'harvesting', 'closed'],
                 _for=True)

not_other_year = LFForInverse(other_year)

not_years = LFForInverse(LFNextToken(values=['s'], num_tokens=1))

lf_year = LFAnd([lf_year_generic, not_other_year, not_years])

near_beginning = LFTokenPosition(lower=0, upper=10, _for=True)

chateau_like_words = get_synonyms('chateau') + get_synonyms('domaine') + get_synonyms('st') + ['cote']

near_chateau = LFNearValues(left_range=5,
                 right_range=5,
                 values= chateau_like_words,
                 _for=True)



vintage_like_words = get_synonyms('vintage') + get_synonyms('reserve') 
near_vintage = LFNearValues(left_range=5, 
                            right_range=5, 
                            values= vintage_like_words, 
                            _for=True)


near_numeric = LFNearNumeric(left_range=1, right_range=1, _for=True)


near_alcohol = LFNearPreLabelled(left_range = 1,
                                 right_range = 1,
                                 pre_labels = ['alcohol'],
                                 _for = True)


#Labelling functions

#lf_year_vintage: If token is year-like and near vintage-like words - vintage, reserve etc
lf_year_vintage = LFAnd([lf_year, near_vintage])

#lf_year_chateau: If token is year-like and near chateau-like words - chateau, domaine etc
lf_year_chateau = LFAnd([lf_year, near_chateau])

#lf_year_near_numeric: If token is year-like and near number
lf_year_near_numeric = LFAnd([lf_year, near_numeric])

#lf_year_beginning: If token is year-like and towards begininning of sentence
lf_year_beginning= LFAnd([lf_year, near_beginning])

#lf_year_alcohol: If token is year-like and near pre-label alcohol
lf_year_near_plabel_alcohol = LFAnd([lf_year, near_alcohol])