# -*- coding: utf-8 -*-
import datetime 

ABSTAIN = -1
FOR_VOTE = 1
AGAINST = 0


min_year = 1900
max_year = datetime.datetime.now().year

    
def lf_year_generic(token):
    if len(token) ==4 and token.isnumeric() and min_year <= int(token) <= max_year :
        return FOR_VOTE
    else:
        return ABSTAIN

    
def lf_not_year_generic(token):
    if lf_year_generic(token) == ABSTAIN:
        return AGAINST
    else:
        return ABSTAIN
