# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled
from lf.lf_generic import ABSTAIN, FOR_VOTE, AGAINST

lf_alcohol_producer = LFPreLabelled('ws_producer')
lf_alcohol_region = LFPreLabelled('ws_region')
lf_alcohol_sub_region = LFPreLabelled('ws_sub_region')
lf_alcohol_sub_sub_region =  LFPreLabelled('ws_sub_sub_region')
lf_alcohol_sub_sub_sub_region = LFPreLabelled('ws_sub_sub_sub_region')
lf_alcohol_brentwood = LFPreLabelled('brentwood')
lf_alcohol_spectrum = LFPreLabelled('spectrum')


def lf_alcohol_numeric_negative(token):
    if token.isnumeric():
        return AGAINST
    else:
        return ABSTAIN
    