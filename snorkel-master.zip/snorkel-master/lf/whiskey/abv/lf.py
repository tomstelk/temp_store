import logging
import re

from snorkel.labeling import labeling_function
from ...wrapper import labeled, FOR, AGAINST, ABSTAIN

logger = logging.getLogger(__name__)


@labeling_function()
def abv_5(candidate):
    if '%' not in candidate:
        return AGAINST
    return ABSTAIN


@labeling_function()
def abv_1(candidate):
    match = re.search(r'[0-9]{2}\%', candidate)
    if match:
        return FOR
    return ABSTAIN


@labeling_function()
def abv_3(candidate):
    if '%' in candidate and any([u in candidate._yield_right(2) for u in ['abv', 'vol']]):
        if candidate != '100%':
            return FOR
    return ABSTAIN


@labeling_function()
def abv_2(candidate):
    match = re.search(r'[0-9]{2}\.[0-9]{1}.?\%', candidate)
    if match:
        return FOR
    return ABSTAIN


@labeling_function()
def abv_4(candidate):
    match = re.search(r'[0-9]{2}\.[0-9]{1}', candidate)
    if match and '%' in candidate._yield_right(2):
        return FOR
    return ABSTAIN
