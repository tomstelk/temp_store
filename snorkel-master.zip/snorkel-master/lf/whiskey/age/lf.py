import logging
import re

from pathlib import Path
from functools import wraps
from nltk.corpus import stopwords

from snorkel.labeling import labeling_function

from ...wrapper import labeled, FOR, AGAINST, ABSTAIN

logger = logging.getLogger(__name__)

STOPWORDS = stopwords.words('english')

kw = ['years old', 'old year', 'y o']
small_kw = ['years', 'old', 'year', 'y', 'o']

@labeling_function()
def age_1(candidate):
    if not candidate.isdecimal() and candidate not in small_kw:
        return AGAINST
    return ABSTAIN

@labeling_function()
def age_2(candidate):
    if candidate.isdecimal() and re.search(r'[0-9]{1,2}', candidate):
        context = ' '.join(candidate._yield_right(2))
        if any(u in context for u in kw):
            return FOR
    return ABSTAIN

@labeling_function()
def age_3(candidate):
    is_dec = re.search(r'[0-9]{1,2}', ' '.join(candidate._yield_left(2)))
    is_year = candidate in ['years', 'year', 'y']
    is_next_old = candidate.right in ['old', 'o']
    if is_dec and is_year and is_next_old:
        return FOR
    return ABSTAIN
