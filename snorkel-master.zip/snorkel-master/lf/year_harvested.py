# -*- coding: utf-8 -*-
from lf.LFBaseClasses import  LFNearValues, LFAnd
from lf.lf_generic import  lf_year_generic, lf_not_year_generic


lf_year_harvested = LFAnd([
    lf_year_generic, 
    LFNearValues(left_range = 2, right_range = 0, values =  ['harvested', 'landed'], _for = True) 
])
  
#lf_year_bottled_prev1 = LFAnd([lf_year, LFPreviousToken(1, ['bottled', 'bottling']) ])
#lf_year_bottled_prev2 = LFAnd([lf_year, LFPreviousToken(2, ['bottled', 'bottling']) ])
#lf_year_bottled_prev3 = LFAnd([lf_year, LFPreviousToken(3, ['bottled', 'bottling']) ])
