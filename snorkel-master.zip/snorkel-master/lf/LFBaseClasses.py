# -*- coding: utf-8 -*-
from lf.lf_generic import ABSTAIN, FOR_VOTE, AGAINST
    
    
class LFTokenPosition():
    
    def __init__(self, 
                 lower, 
                 upper,
                 _for):
        
        self._lower = lower
        self._upper = upper
        
        if _for:
            self._vote = FOR_VOTE
        else:
            self._vote = AGAINST
            
    def __call__(self, token):
        """
        Returns For/Against if position of token within [lower, upper]
        """
        if token.pos <= self._upper and  token.pos >= self._lower:
            return self._vote
        else:
            return ABSTAIN
        
        
class LFNear():
    
    def __init__(self,
                 left_range,
                 right_range,
                 bool_callable,
                 _for):
        
        self._range = dict()
        self._range['left'] = left_range
        self._range['right'] = right_range
        self._bool_callable = bool_callable
        
        if _for:
            self._vote = FOR_VOTE
        else:
            self._vote = AGAINST
        
        
    def _check_other(self, token, _dir):
        i=1
        _other = token
        num_tokens = self._range[_dir]
        while i <= num_tokens:
            
            if not(_other):
                return False
            
            _other = getattr(_other, _dir)
            
            if self._bool_callable (_other):
                return True
            
            i+=1
            
        return False

    def _check_left(self, token):
        return self._check_other(token = token, _dir = 'left')
    
    def _check_right(self, token):
        return self._check_other(token = token, _dir = 'right')
        
    def __call__(self, token):
        """
        Returns for/abstain if token near satisfies bool_callable - near defined as [left_range, right_range]
        """
        if self._check_left(token):
            return self._vote
        
        if self._check_right(token):
            return self._vote
        
        return ABSTAIN
        
    
    
class LFNearNumeric(LFNear):
    
    def __init__(self,
                 left_range,
                 right_range,
                 _for):
        
        bool_callable = lambda t : t.isnumeric() if t else False
        
        return super().__init__(left_range = left_range,
                                right_range = right_range,
                                bool_callable = bool_callable,
                                _for = _for)

class LFNearPreLabelled(LFNear):
    
    def __init__(self,
                 left_range,
                 right_range,
                 pre_labels,
                 _for):
        
        if type(pre_labels)==str:
            pre_labels = set([pre_labels])
        else:
            pre_labels = set(pre_labels)
        
        bool_callable = lambda t : hasattr(t, 'pre_labels') and pre_labels.intersection(t.pre_labels)
        
        return super().__init__(left_range = left_range,
                                right_range = right_range,
                                bool_callable = bool_callable,
                                _for = _for)
        
class LFNearValues(LFNear):
    
    def __init__(self,
                 left_range,
                 right_range,
                 values,
                 _for):
        
        set_values = set(values)
        bool_callable = lambda t : t in set_values
        
        return super().__init__(left_range = left_range,
                                right_range = right_range,
                                bool_callable = bool_callable,
                                _for = _for)


class LFForInverse():
    
    def __init__(self, lf):
        self._lf = lf
    def __call__(self, token):
        """
        Returns ABSTAIN if given lf returns FOR_VOTE, else FOR_VOTE
        """
        if self._lf(token) == FOR_VOTE:
            return ABSTAIN
        else:
            return FOR_VOTE


class LFForNot():
    
    def __init__(self, lf):
        self._lf = lf
    def __call__(self, token):
        """
        Returns AGAINST if given lf returns FOR_VOTE
        """
        if self._lf(token) == FOR_VOTE:
            return AGAINST
        else:
            return ABSTAIN
    
    
class LFAnd():
    
    def __init__(self, lfs):
        self._lfs = lfs
        
    def __call__(self, token):
        """
        Returns FOR_VOTE if all lfs return FOR_VOTE
        """
        
        if all(lfi(token) ==  FOR_VOTE for lfi in self._lfs):
            return FOR_VOTE
        else:
            return ABSTAIN

class LFOr():
    
    def __init__(self, lfs):
        self._lfs = lfs
 
    def __call__(self, token):
        """
        Returns FOR_VOTE if any lfs return FOR_VOTE
        """
        if any(lfi(token) ==  FOR_VOTE for lfi in self._lfs):
            return FOR_VOTE
        else:
            return ABSTAIN


class LFPreProcessed():
    
    def __init__(self, pre_label):
        self._pre_label = pre_label

    def __call__(self, token):
        """
        Returns FOR_VOTE if token has been prelabelled as pre_label
        """         
        if hasattr(token, 'pre_labels') and self._pre_label in token.pre_labels:
            return FOR_VOTE
        return ABSTAIN


class LFLabelled():
    
    def __init__(self, label):
        self._label = label

    def __call__(self, token):
        """
        Returns FOR_VOTE if token is labelled as label
        """         
        if hasattr(token, 'label') and token.label == self._label:
            return FOR_VOTE
        return ABSTAIN



class LFContext():
    
    def __init__(self, 
                 num_tokens, 
                 values):
        
        self._num_tokens = num_tokens
        if type(values) == str:
            self._values = set([values])    
        else:
            self._values = set(values)
        
    def __call__(self, token):
        """
        Returns FOR_VOTE if context token is in values, else ABSTAIN
        Context direction is decided by attribute _dir
        """ 
        i=1
        _other = token
        while i <= self._num_tokens:
            if not(_other):
                return ABSTAIN
            _other = getattr(_other, self._dir)
            i+=1
            
        if _other in self._values:
            return FOR_VOTE
        else:
            return ABSTAIN
        
    
class LFNextToken(LFContext):
    _dir = 'right'
            
            
class LFPreviousToken(LFContext):
    _dir = 'left'
    
    
class LFTokenValue():
    def __init__(self, 
                 values):
        
        self._values = set(values)
        
    def __call__(self, token):
        """
        Returns FOR_VOTE if token is in values, else ABSTAIN        
        """ 
        
        if token in self._values:
            return FOR_VOTE
        else:
            return ABSTAIN
    
    
class LFBetween():
    
    def __init__(self, 
                 left_values,
                 right_values):
        
        self._left_values = set(left_values)
        self._right_values = set(right_values)
        
    def __call__(self, token):
        """
        Returns FOR_VOTE if token occurs between left_values and right_values,
        without right/left values occuring between, else returns ABSTAIN
        
        For example:
            left_value, token, right_value -> FOR_VOTE
            left_value, other, other, token, other, right_value -> FOR_VOTE
            left_value, other, right_value, token, other, right_value -> ABSTAIN
            left_value, other, token, other, left_value -> ABSTAIN
        """    
        l = token
        while l:
            l = l.left
            if l in self._right_values:
                return ABSTAIN
            elif l in self._left_values:
                r = token
                while r:
                    r = r.right
                    if r in self._left_values:
                        return ABSTAIN
                    elif r in self._right_values:
                        return FOR_VOTE
                
                return ABSTAIN
            
        return ABSTAIN
    
    
    
    
'''
class LFHardAntiPreLabelled():
    
    def __init__(self, label):
        self._label = label

    def __call__(self, token):
        """
        Returns AGAINST if label is not label
        """    
        if hasattr(token, 'label') and  token.label != self._label:
            return AGAINST
        return ABSTAIN
   

class LFAntiPreLabelled():
    
    def __init__(self, label):
        self._label = label

    def __call__(self, token):
        """
        Returns AGAINST if not prelabelled as label
        """       
        
        if hasattr(token, 'label') and token.label is not None and token.label != self._label:
            return AGAINST
        return ABSTAIN
'''
