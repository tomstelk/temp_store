# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled

cork_pre_labelled = LFPreLabelled('cork')
