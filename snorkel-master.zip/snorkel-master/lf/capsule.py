# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled

capsule_pre_labelled = LFPreLabelled('capsule')
