# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled

lf_capsule_pre_labelled = LFPreLabelled('capsule')
