# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled
from static.static_utils import get_synonyms
from lf.LFBaseClasses import   LFNextToken, LFTokenValue, LFBetween, LFAnd, LFNearValues

lf_box_pre_labelled = LFPreLabelled('box')

box_synonyms = get_synonyms('box')

lf_box_next_box = LFNextToken(num_tokens = 1, values = box_synonyms)

lf_box_is_box = LFTokenValue(values = box_synonyms)

lf_box_in_original = LFAnd([
    LFNearValues(left_range=3, right_range = 0, values = ['with', 'in'], _for = True),
    LFNearValues(left_range=2, right_range = 0, values = ['original'], _for = True)
])
