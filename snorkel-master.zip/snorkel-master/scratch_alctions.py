# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""
'''


import import_utils
from utils.json_utils import get_json, print_json_pretty
import os

#alctions = get_json(os.path.join('../wine_sites_20191127.json'))


    


get_name = lambda ji :ji['name']

class FilterSubstrField():
    def __init__(self, substr, field):
        self.substr = substr
        self.field = field
        
    def __call__(self, j):
        f = j.get(self.field)
        if type(f)==str and self.substr in f:
            return True
        
        return False
            

filter_spectrum = FilterSubstrField(substr='spectrumwine', field='url')



spectrum_texts = list(map(no_numbers, map(get_name, filter(filter_spectrum, alctions))))



from itertools import chain
from collections import Counter
def chain_split(iterable):
    return chain.from_iterable(map(lambda s:s.split(), iterable))
    


spectrum_words=list(chain_split(spectrum_texts))
c = Counter(spectrum_words)


cc = sorted([(k,v) for k,v in c.items() ], key = lambda ci : -ci[1])





def no_numbers(in_str):
    
    no_nums = filter(lambda si : not si.isnumeric(), in_str.split())
    return ' '.join(no_nums)

from itertools import takewhile

def before_numbers(in_str):
    
    befo_nums = takewhile(lambda si : not si.isnumeric(), in_str.split())
    return ' '.join(befo_nums)

filter_brentwood = FilterSubstrField(substr='brentwood', field='url')
brentwood_texts = list(map(before_numbers, map(get_name, filter(filter_brentwood, alctions))))


'''


filter_fitz = FilterSubstrField(substr='fitzgerald', field='url')


fitz = filter(filter_fitz, alctions)

