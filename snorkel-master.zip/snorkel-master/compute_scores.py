import os
import logging
import spacy
import json
import pprint as pp
import argparse

from pathlib import Path

from classes import Candidate, Sentence
from analysis import make_label_matrix, from_spacy

from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score

logger = logging.getLogger(__name__)


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Compute precision/recall metrics')
    parser.add_argument('gold', type=str, default='./data/spacy_whiskey_description.json',
            help='Spacy formated annotated gold dataset')
    parser.add_argument('preds', type=str, default='final.json',
            help='Preds from snorkel')
    parser.add_argument('--save', type=bool, help="Saving result json to disk")
    args = parser.parse_args()

    with open(args.gold) as f:
        gold_samples = from_spacy(json.load(f))

    with open(args.preds) as f:
        preds_sample = [Sentence.from_json(u) for u in json.load(f)]

    not_cols = ['None', 'candidate']
    gold = make_label_matrix(gold_samples, binarize=True, make_df=True)
    preds = make_label_matrix(preds_sample, binarize=True, make_df=True)

    labels_left = [c for c in preds.columns if c not in not_cols]
    labels_right = [c for c in gold.columns if c not in not_cols]
    labels = list(set(labels_right).intersection(set(labels_left)))
    n_classes = len(labels)

    preds_label = preds[labels].values
    gold_label = gold[labels].values

    # For each class
    results = {}
    precision = dict()
    recall = dict()
    average_precision = dict()
    for i in range(n_classes):
        pr, rec, _ = precision_recall_curve(gold_label[:, i], preds_label[:, i])
        precision[labels[i]] = pr[1]
        recall[labels[i]] = rec[1]
        average_precision[labels[i]] = average_precision_score(gold_label[:, i], preds_label[:, i])

    # A "micro-average": quantifying score on all classes jointly
    micro_pr, micro_rec, _ = precision_recall_curve(gold_label.ravel(),
        preds_label.ravel())
    precision["micro"] = micro_pr[1]
    recall['micro'] = micro_rec[1]
    average_precision["micro"] = average_precision_score(gold_label, preds_label,
                                                         average="micro")

    results['precision'] = {'all': precision, 'micro': average_precision}
    results['recall'] = {'all': recall}

    print('Results')
    pp.pprint(results)

    if args.save:
        print('Saving final results to disk')
        with open('results.json', 'w') as f:
            json.dump(results, f)

    print('Average precision score, micro-averaged over all classes: {0:0.2f}'
          .format(average_precision["micro"]))
