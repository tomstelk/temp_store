# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:27:14 2019

@author: user
"""

import numpy as np
import pandas as pd
from Processor.Processor import Processor


class SelectField(Processor):
    
    def __init__(self, field):
        self.field = field
        
    @classmethod
    def from_json(cls, j):
        return cls(**j)
    
    def to_json(self):
        return {'field' : self.field}
    
    def fit(self, df):
        return self
    
    def transform(self, df):
        return df[self.field]
    
    
class AggregatePremium(Processor):
    
    
    def __init__(self, 
                 metric,
                 target,
                 relative
                ):
    
        self.metric = metric
        self.target = target
        self.relative = relative
        self.premium_mapper = dict()

    @classmethod
    def from_json(cls, j):
        new = cls(metric = j['metric'],
                 target = j['target'],
                 relative = j['relative'])  
        
        new.premium_mapper = j['premium_mapper']
        
        return new
        
    
    def to_json(self):
        return {'metric' : self.metric,
                'target' : self.target,
                'relative' : self.relative,
                'premium_mapper' : self.premium_mapper,
                }
    
    '''    
    def transform_row(self, row):
        return self.premium_mapper.get(getattr(row, self.target), None)
    ''' 
    def transform(self, df):
        targets = df[self.target].values
        return [self.premium_mapper.get(ti) for ti in targets]
         
        #return df.apply(self.transform_row, axis = 1)
    
    def fit(self, df):
        

        groups = df.groupby(self.relative)[self.metric].mean()
        t = df.groupby([self.relative, self.target])[self.metric].apply(lambda frame: frame/groups.loc[frame.name[0]])
    
        tmp = pd.concat([df[[self.target, self.relative]], t], axis=1)
        
        res = pd.DataFrame(tmp.groupby(self.target).mean()[self.metric])
        
        self.premium_mapper = dict()
        
        for ri in res.index:
            self.premium_mapper[ri] = res.loc[ri, self.metric]
        
        return self
    
    