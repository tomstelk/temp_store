import os
import datetime
from operator import eq, ne


THIS_DIR = os.path.dirname(os.path.realpath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(THIS_DIR, '..'))
GRANDPARENT_DIR = os.path.abspath(os.path.join(PARENT_DIR, '..'))
NORMALISATION_BASE_DIR = os.path.join(THIS_DIR, 'saved_normalisation_models')

MIN_NORM_PNTS = 10


BASE_CURRENCY='GBP'

UNIT_VOL_SIZES = [0.75, 0.7]
UNIT_VOL_SIZE = 0.75
UNIT_QUANTITY = 1
PRICE = 'hammer_price_base'

