# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 12:07:03 2020

@author: 1613098
"""
import import_utils
from utils.json_printers.NpJson import NpEncoder
from utils.json_printers.SetJson import SetEncoder
from utils.json_utils import JSONPrettyPrint


class PredictionModelEncoder(SetEncoder, NpEncoder):
    pass


PredictionModelJson = JSONPrettyPrint(encoder = PredictionModelEncoder)