# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
from parse_transformation_result import _parse_transformation_result
import import_utils 
from utils.json_utils import get_json
import unittest 


class TestParseTransform(TestS3):
    
    def setUp(self):
        
        
        self.fields = ['url', 'hammer_price_base']
        
        
    def test_parse(self):
        
        test_parse = get_json('./test_parse.json')
        res_parse = _parse_transformation_result(res = self.train_json, fields = self.fields)
        self.assertEqual(test_parse, res_parse)
    
    
    
    
if __name__ == '__main__':
    unittest.main()