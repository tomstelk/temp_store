# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:33:11 2019

@author: user
"""


import sys
import os

parent_dir = os.path.abspath('..')

sys.path.append(parent_dir)

import import_utils
from utils.json_utils import get_json
import unittest

import pandas as pd

class TestS3(unittest.TestCase):
    
    train_json = get_json('./alcohol_train.json')
    test_json= get_json('./alcohol_test.json')
    
    train_json_parsed = get_json('./alcohol_train_parsed.json')
    
    df_train = pd.DataFrame(train_json_parsed)
    df_test = pd.DataFrame(test_json)
    
    