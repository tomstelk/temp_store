# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np
from TargetProcesses.Normalisers import IncrAvgNormaliser
from operator import eq, ne


class TestIncrAvgNormaliser(TestS3):
    
    def setUp(self):
        
        self.n = IncrAvgNormaliser()
        
    def test_fit(self):
        
        x = [1,1,2,2,2,2,3,4,4]
        y = [1,2,3,4,5,6,7,5,8]
        test = {1 : 1.5,
               2 : 4.5,
               3 : 7,
               4 : 7}
        
        self.n.fit(x, y)
        self.assertDictEqual(test, self.n.mapper)
        
        
    def test_from_json(self):
        
        j = {
                'x' : [1,2,3,4],
                'y' : [2,2,3,3.5]
                }
                
        n = IncrAvgNormaliser.from_json(j)
        
        self.assertEqual(list(n.mapper.keys()), [1,2,3,4])
        self.assertEqual(list(n.mapper.values()), [2,2,3,3.5])
            
        
    def test_predict(self):
        
        j = {
                'x' : [1,2,3,4],
                'y' : [2,2,3,3.5]
                }
                
                
        n = IncrAvgNormaliser.from_json(j)
        
        x = [1, 1.5, 3.5, 10]
        test = [2, 2, 3.25, 3.5]
        res = list(n.predict(x))
        
        self.assertEqual(test, res)
            
    
    
if __name__ == '__main__':
    unittest.main()




'''

from TestS3 import TestS3
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np
from PreProcessor.Normalisers import Normaliser
from operator import eq, ne


class TestNormaliser(TestS3):
    
    def setUp(self):
        
        self.n = Normaliser( model_name='test',
                 key_price = 'hammer_price_base',
                 key_vol_ratio = 'vol_ratio',
                 key_quantity = 'quantity',
                 key_id = 'gid',
                 normalisation_groups = {'whiskey': [('ws_type', 'whiskey', eq)],
                                        'wine': [('ws_type', 'wine', eq)
                                                 ]})
        
    def test_df(self):
        
        
        in_df = pd.DataFrame.from_csv('pre_test_normaliser.csv')
        self.n.fit(in_df)
        
        get_kwargs = lambda row: { 'ws_type' : row.ws_type, 
                                  'ws_sub_type' : row.ws_sub_type ,
                                  'vol_ratio' : row.vol_ratio, 
                                  'quantity' : row.quantity}
        
        in_ = list(in_df.apply(get_kwargs, axis = 1))
        
        call_normaliser = lambda d : self.n.transform(**d)
        
        
        res_df = list(map(call_normaliser, in_))
        
        
        
        compare = get_json('post_test_normaliser.json')
        
        
        self.assertEqual(res_df,
                         compare
                         )
    
    
    
if __name__ == '__main__':
    unittest.main()
'''    