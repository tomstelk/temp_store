# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
from PreProcesses.PreProcesses import RemoveBadValues
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np


class TestRemoveZero(TestS3):
    
    def setUp(self):
        
        self.rm_zero_quantity = RemoveBadValues(columns = ['quantity'], 
                                                bad_values = [0])
        
    def test_rm_zero(self):
        
        post_rm_zero = pd.DataFrame(get_json('./alcohol_rm_zero_post.json'))
        pre_rm_zero = pd.DataFrame(get_json('./alcohol_rm_zero_pre.json'))
        
        np.testing.assert_array_equal(post_rm_zero.values, 
                                      self.rm_zero_quantity.transform(pre_rm_zero).values)
    
    
    
    
if __name__ == '__main__':
    unittest.main()