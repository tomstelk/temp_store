# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np
from TargetProcesses.Normalisation import Normalisation, rem_geometric_outliers
from operator import eq, ne
import csv
from copy import deepcopy


mock_norm_val = 1.5

class MockNormaliser():
        
    def fit(self, X, y):
        return self

    def predict(self, X, y = None):
        for xi in X:
            yield mock_norm_val
        
        


class TestNormalisation(TestS3):
    
    
    def _get_big_test_data(self):#
        
        j = get_json('test_alcohol_data.json')            
        return  pd.DataFrame(j)    
    
    def setUp(self):
        
        
        
        norm_cfg = {
                            'group_field' : 'ws_type', 
                            'groups'  : ['wine'],
                            'features' : [
                                         {'field': 'vol_size', 'unit_value':0.75, 'control_fields':['quantity'], 'control_values' : [1]},
                                         {'field': 'quantity', 'unit_value':1, 'control_fields':['vol_size'], 'control_values' : [0.75]}
                                         ],
                            'rel_field' : 'gid',
                            'price_field' : 'hammer_price_base', 
                            'NormaliserKlass' : MockNormaliser, 
                            'norm_kwargs' : dict(),
                            'min_points' : 2,
                            'outlier_z' : 2,
                            'inv_price_field' : 'pred_norm_price'
                            }
        
        self.n = Normalisation(**norm_cfg)
        
        j = deepcopy(norm_cfg)
        j['NormaliserKlassName'] = 'MockNormaliser'
        del j['NormaliserKlass']
        j['NormaliserModule'] = '__main__'
        j['norm_models'] = {'wine': {'quantity': None, 'vol_size': None}}
        
        self.norm_json = j
        
        
    def test_to_json(self):
        j = self.n.to_json()
        
        self.assertDictEqual(j, self.norm_json)
        
    def test_from_json(self):
        
        j = deepcopy(self.norm_json)
        
        j['rel_field'] = 'new_rel_field'
        j['price_field'] = 'new_price_field'

        
        
        n = Normalisation.from_json(j)
        
        self.assertEqual(n.rel_field, 'new_rel_field')
        self.assertEqual(n.price_field, 'new_price_field')
        
    def test_group_data(self):
        in_df = pd.DataFrame.from_csv('./pre_test_normalisation_group.csv')
        test = pd.DataFrame.from_csv('./post_test_normalisation_group.csv')
        
        res = self.n._group_data(df = in_df,
                                 field = 'vol_size', 
                                 unit_value = 0.75,
                                 relative = 'gid', 
                                 min_points = 2)
        
        pd.testing.assert_frame_equal(test, res)
        
        
        
    def test_calc_rel_price(self):
        in_df = pd.DataFrame.from_csv('./post_test_normalisation_group.csv')
        test =  [0.4375,
                 1,
                 2.072745902,
                 0.230532787,
                 1,
                 0.531147541,
                 1,
                 2.123529412,
                 1,
                 0.093546477]
        
        test = pd.Series(test)
        
        res = self.n._calc_rel_price(df = in_df, 
                                     field = 'vol_size', 
                                     unit_value = 0.75, 
                                     price = 'hammer_price_base',
                                     relative = 'gid')
        
        pd.testing.assert_series_equal(res,test)
        
    def test_rem_outliers(self):
        in_x = [1, 1, 1, 1, 2]
        in_y = [4, 4, 0.1, 40, 8]
        
        test_x = [1, 1, 2]
        test_y = [4, 4, 8]
        
        res_x, res_y = rem_geometric_outliers(x = in_x, 
                                              y = in_y,
                                              outlier_z = 1)
        
        
        self.assertEqual(res_x, test_x)
        self.assertEqual(res_y, test_y)
        
    def test_default_multiplier(self):
        
        row = {'vol_size' : 10, 'quantity': 2000}
        res = self.n._default_multiplier(row)
        
        self.assertEqual(res, 2000*10/0.75)
        
        
    def test_transform_row(self):
        
        df = self._get_big_test_data()
        
        #df['quantity'] = df['quantity'].astype('int')
        
        self.n.fit(df)
        
        row = {'ws_type' : 'wine',
               'vol_size' : 10, 
               'hammer_price_base' : 100,
               'quantity': 2000}
        
        m = self.n._multiplier(row)
        p = self.n._transform_row(row)
        
        test_m = mock_norm_val*mock_norm_val
        test_p = 100/test_m
        
        self.assertEqual(m, test_m)
        self.assertEqual(p, test_p)
        
        
        
        
        
    
if __name__ == '__main__':
    unittest.main()
