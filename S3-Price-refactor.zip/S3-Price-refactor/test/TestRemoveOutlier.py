# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
from PreProcesses.PreProcesses import RemoveOutliers
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np


class TestRemoveOutlier(TestS3):
    
    def setUp(self):
        
        self.rem_out = RemoveOutliers(threshold = 2,
                                      target = 'hammer_price_base',
                                      groupby = 'gid',
                                      relative_columns = ["vol_ratio", "quantity"])

        
    def test_rm_out(self):
        
        pre = pd.DataFrame(get_json('./alcohol_rm_outliers_pre.json'))
        post = pd.DataFrame(get_json('./alcohol_rm_outliers_post.json'))
        
        np.testing.assert_array_equal(post.values, 
                                      self.rem_out.transform(pre).values)
    
    
    
    
if __name__ == '__main__':
    unittest.main()