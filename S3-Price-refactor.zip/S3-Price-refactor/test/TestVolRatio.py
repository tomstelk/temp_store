# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
from PreProcesses.PreProcesses import VolumeRatio
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np


class TestVolRatio(TestS3):
    
    def setUp(self):
        
        self.vol_ratio = VolumeRatio(vol_size_column = 'vol_size', 
                                            vol_ratio_column = 'vol_ratio')
        
    def test_rm_zero(self):
        
        post = pd.DataFrame(get_json('./alcohol_volratio_post.json'))
        pre = pd.DataFrame(get_json('./alcohol_volratio_pre.json'))
        
        np.testing.assert_array_equal(post['vol_ratio'].values, 
                                      self.vol_ratio.transform(pre)['vol_ratio'].values)
    
    
    
    
if __name__ == '__main__':
    unittest.main()