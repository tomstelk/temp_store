# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
import import_utils 
from utils.json_utils import get_json
import unittest 
import numpy as np
from classes.Encoders import OrdinalEncoder
import pandas as pd


class TestOrdinalEncoder(TestS3):
    
    
    def test_fit_transform(self):
        x = [['a', 0], ['b', 1], ['a', 2]]
        test = np.array([[0, 0], [1, 1], [0, 2]])
        
        oe = OrdinalEncoder()
        res = np.array(list(oe.fit_transform(x)))
        
        np.testing.assert_equal(test, res)
        
        
    def test_from_json(self):
        j = {'categories': [['a', 'b'], [0, 1, 2]]}
        
        oe = OrdinalEncoder.from_json(j)
        
        x = [['a', 0], ['b', 1], ['b', 1]]
        res = oe.transform(x)
        test = np.array([[0, 0], [1, 1], [1, 1]])
        
        np.testing.assert_equal(test, res)
        
    def test_to_json(self):
        x = [['a', 0], ['b', 1], ['a', 2]]
        test = {'categories': [['a', 'b'], [0, 1, 2]]}
        
        oe = OrdinalEncoder()
        oe.fit(x)
        res = oe.to_json()
        
        self.assertDictEqual(test, res)
        
    
    def test_inverse_transform(self):
        j = {'categories': [['a', 'b'], [0, 1, 2]]}
        
        oe = OrdinalEncoder.from_json(j)
        
        y = [[0, 0], [1, 2]]
        res = oe.inverse_transform(y)
        test = [['a', 0], ['b', 2]]
        
        np.testing.assert_equal(test, res)

    
if __name__ == '__main__':
    unittest.main()

