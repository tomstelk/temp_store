# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
import import_utils 
from utils.json_utils import get_json
import unittest 
import numpy as np
from classes.Encoders import OrdinalOneHotEncoder
import pandas as pd


class TestOrdinalOneHotEncoder(TestS3):
    
    
    def test_fit_transform(self):
        x = [['a', 0], ['b', 1], ['a', 2]]
        test = np.array([[1, 0, 1, 0, 0], 
                         [0, 1, 0, 1, 0], 
                         [1, 0, 0, 0, 1]])
        
        oe = OrdinalOneHotEncoder()
        res = oe.fit_transform(x)

        np.testing.assert_equal(test, res.toarray())
        

    def test_from_json(self):
        j = {'_labeller': 
                {'categories': [['a', 'b'], [0, 1, 2]]},
             'n_values_' : [2, 3],
             'feature_indices_': [0, 2, 5],
             'active_features_': [0, 1, 2, 3, 4]
                }
        
        oe = OrdinalOneHotEncoder.from_json(j)
        
        x = [['a', 0], ['b', 1], ['b', 1]]
        res = oe.transform(x)
        test = np.array([[1, 0, 1, 0, 0], 
                         [0, 1, 0, 1, 0], 
                         [0, 1, 0, 1, 0]])
        
        np.testing.assert_equal(test, res.toarray())

    def test_to_json(self):
        x = [['a', 0], ['b', 1], ['a', 2]]
        test = {'_labeller': 
                {'categories': [['a', 'b'], [0, 1, 2]]},
             'n_values_' : [2, 3],
             'feature_indices_': [0, 2, 5],
             'active_features_': [0, 1, 2, 3, 4]
                }
        
        oe = OrdinalOneHotEncoder()
        oe.fit(x)
        res = oe.to_json()
        
        self.assertDictEqual(test, res)
        
    '''
    def test_inverse_transform(self):
        j = {'_labeller': 
                {'categories': [['a', 'b'], [0, 1, 2]]},
             'n_values_' : [2, 3],
             'feature_indices_': [0, 2, 5],
             'active_features_': [0, 1, 2, 3, 4]
                }
        
        oe = OrdinalOneHotEncoder.from_json(j)
        
        y = np.array([[1, 0, 1, 0, 0], 
                         [0, 1, 0, 1, 0], 
                         [0, 1, 0, 1, 0]])
    
        res = oe.inverse_transform(y)
        test = [['a', 0], ['b', 2]]
        
        np.testing.assert_equal(test, res)
    '''

    
if __name__ == '__main__':
    unittest.main()

