# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
from PreProcesses.PreProcesses import FillNa
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np


class TestFillNa(TestS3):
    
    def setUp(self):
        
        self.fill_na_sub_name = FillNa(columns = ['sub_name'], 
                                       values = ['filler'])
        
    def test_rm_zero(self):
        
        post = pd.DataFrame(get_json('./alcohol_fillna_post.json'))
        pre = pd.DataFrame(get_json('./alcohol_fillna_pre.json'))
        
        np.testing.assert_array_equal(post.values, 
                                      self.fill_na_sub_name.transform(pre).values)
    
    
    
    
if __name__ == '__main__':
    unittest.main()