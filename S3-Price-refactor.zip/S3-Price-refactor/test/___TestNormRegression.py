# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
from PreProcessor.Normalisers import make_transformer, log_transform,Ridge, NormalisationRegression
import import_utils 
from utils.json_utils import get_json
import pandas as pd
import unittest 
import numpy as np



class TestNormRegression(TestS3):
    
    def setUp(self):
        
        base_transform = make_transformer(log_transform, **{'scale': 5})
        ridge_0 = Ridge(fit_intercept=False, alpha = 0)
        ridge_1 = Ridge(fit_intercept=False, alpha = 1)



        self.norm_reg_model_ridge_0 = NormalisationRegression(base_transform, 
                                             ridge_0, 
                                             weighted=True)
        
        self.norm_reg_model_ridge_1 = NormalisationRegression(base_transform, 
                                             ridge_1, 
                                             weighted=True)
        
    def test_ridge_0(self):
        
        x = np.array(list(range(1, 11)))
        y = np.array([37, 87.33333333, 229, 247.5, 236, 130, 454, 14, 523.5, 499.3333333])
        
        target = np.array([64.99,119.94,167.54,209.52,247.08,281.05,312.07,340.60,367.02,391.61]).reshape(10,1)
            
        self.norm_reg_model_ridge_0.fit(x, y)
        test = self.norm_reg_model_ridge_0.predict(x)

        
        np.testing.assert_array_almost_equal(target,
                                      test,
                                      decimal =2
                                      )
    
    
    def test_ridge_1(self):
        
        x = np.array(list(range(1, 11)))
        y = np.array([37, 87.33333333, 229, 247.5, 236, 130, 454, 14, 523.5, 499.3333333])
        
        target = np.array([55.3785727,102.20048877,142.75947732,178.53504066,210.53737258,239.48700319,265.91594528,290.22821523,312.73786135,333.69384054]).reshape(10,1)
            
        self.norm_reg_model_ridge_1.fit(x, y)
        test = self.norm_reg_model_ridge_1.predict(x)

        
        np.testing.assert_array_almost_equal(target,
                                      test,
                                      decimal =2
                                      )
        
    def test_ridge_0_weighted(self):
        
        x = np.array([1,2,3])
        y = np.array([2.333,6,9])
        
        target = np.array([ 3.31, 6.11,8.54]).reshape(3,1)
            
        self.norm_reg_model_ridge_0.fit(x, y)
        test = self.norm_reg_model_ridge_0.predict(x)


        np.testing.assert_array_almost_equal(target,
                                      test,
                                      decimal =2
                                      )
    
    
    
if __name__ == '__main__':
    unittest.main()