# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:32:40 2019

@author: user
"""



from TestS3 import TestS3
import import_utils 
from utils.json_utils import get_json
import unittest 
import numpy as np
from classes.Encoders import DFMixedEncoder
import pandas as pd


class TestDFMixedEncoder(TestS3):
    
    def setUp(self):

        self.test_j = {'encode_features': ['letter'], 
                       'scale_features': ['number'], 
                       'encoder': {
                               '_labeller': {'categories': [['a', 'b', 'c']]}, 
                               'feature_indices_': [0, 3], 
                               'active_features_': [0, 1, 2], 
                               'n_values_': [3]}, 
                               'standardise': True, 
                               'scaler': {'copy': True,
                                          'mean_': [-249927.25],
                                          'n_samples_seen_': 4,
                                          'scale_': [433054.70928358176],
                                          'var_': [187536381232.6875],
                                          'with_mean': True,
                                          'with_std': True}}
                       
        X = [{'letter' : 'a', 'number' : 190, 'other' : 10},
             {'letter' : 'b', 'number' : 100, 'other' : 1},
             {'letter' : 'a', 'number' : 1, 'other' : -9},
             {'letter' : 'c', 'number' : -1000000, 'other' : 'p'}]
        
        self.df = pd.DataFrame(X)
            

    def test_fit_transform(self):
        
        encode_features = ['letter']
        scale_features = ['number']
        
        e = DFMixedEncoder(encode_features = encode_features, 
                           scale_features = scale_features,
                           standardise = False)
        
        res = e.fit_transform(self.df)
        
        print (e.to_json())
        
        test = np.array([[1, 0, 0, 190], 
                         [0, 1, 0, 100], 
                         [1, 0, 0, 1], 
                         [0, 0, 1, -1000000]])
        
        
        np.testing.assert_equal(test, res.toarray())
        
    def test_from_json(self):
        e = DFMixedEncoder.from_json(self.test_j)
        res = e.transform(self.df)
        
        test = np.array([[1, 0, 0, 0.577565], 
                         [0, 1, 0, 0.577357], 
                         [1, 0, 0, 0.577129], 
                         [0, 0, 1, -1.732051]])
            
        np.testing.assert_almost_equal(test, res.toarray(), decimal=4)
        
        
    
    def test_to_json(self):

        encode_features = ['letter']
        scale_features = ['number']
        
        e = DFMixedEncoder(encode_features = encode_features, 
                           scale_features = scale_features,
                           standardise = True)
        
        e.fit(self.df)     
        j = e.to_json()       
        
        self.assertDictEqual(j, self.test_j)
        
        
        
        
    
    def test_inverse_transform(self):
        pass

    
if __name__ == '__main__':
    unittest.main()

