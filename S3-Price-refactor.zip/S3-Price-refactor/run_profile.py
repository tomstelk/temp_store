# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 13:03:19 2020

@author: 1613098
"""


import cProfile
import pstats


p = cProfile.run('import scratch', 'profile_res')


p = pstats.Stats('profile_res')

p.sort_stats('cumtime')

p.print_stats(50)