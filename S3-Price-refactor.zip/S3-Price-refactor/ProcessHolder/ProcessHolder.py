# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 15:37:59 2019

@author: user
"""
from toolz import compose
import logging
from importlib import import_module

logger = logging.getLogger(__name__)




class ProcessHolder():
    
    #__pre_proc_module_name = 'PreProcessor.PreProcesses'
    
    def __init__(self,
                 name,
                 module,
                 klass,
                 kwargs,
                 feature = None):
        
        """
        Subprocess holder holds some process class that implements fit/transform/to_json/from_json
        Assumes operation on a pd DataFrame
        
        name - name of the process
        module - name of module containing process klass
        klass - name of process klass
        kwargs - dict holding keyword arguments to klass init
        feature - (optional) if provided will insert result at feature, if not simply return result
        """
        
        self.name = name
        self.module = module
        self.klass = klass
        self.kwargs = kwargs
        self.feature = feature
        
        logger.info('Initialising processer {}'.format(self.name))
        
        m = import_module(module)
        k = getattr(m, klass)
        self.proc = k(**kwargs)
        
        logger.info('... initialised')
        
        
    def to_json(self):
        return {'proc' : self.proc.to_json(),
                'name' : self.name,
                'module' : self.module,
                'klass' : self.klass,
                'feature' : self.feature,
                'kwargs' : self.kwargs}
                 
        
    @classmethod
    def from_json(cls, j):
        
        new = cls(name = j['name'],
                  module = j['module'],
                  klass = j['klass'],
                  kwargs =  j['kwargs'],
                  feature = j['feature'])
        
        klass = getattr(import_module(j['module']), j['klass'])
        new.proc = klass.from_json(j['proc'])
        
        return new
    
    def fit(self, df):
        
        logger.info('Fitting process {}'.format(self.name))
        self.proc.fit(df)
        logger.info('... fitted')
        return self
    
    def inverse_transform(self, df):
        logger.info('Running inverse of process {}, data shape pre: {} ... '.format(self.name, df.shape))
        out =  self.proc.inverse_transform(df)
        logger.info('... run, data shape post: {}'.format(out.shape))
        return out
    
    
    def transform(self, df):
        logger.info('Running process {}, data shape pre: {} ... '.format(self.name, df.shape))
        
        res = self.proc.transform(df)               
        
        if self.feature:
            df[self.feature] = res
            logger.info('... run, data shape post: {}'.format(df.shape))
            return df
        else:
            logger.info('... run, data shape post: {}'.format(res.shape))
            return res
    
    def fit_transform(self, df):
        return self.fit(df).transform(df)
    
        
        
        
        
        
        
class MultiProcessHolder():
    
    def __init__(self, 
                 names, 
                 modules,
                 klasses, 
                 kwargs,
                 features = None):
        
        """
        Holds multiple ProcessHolders, run in order given
        """
        
        assert len(names) == len(klasses)
        assert len(klasses) == len(modules)
        assert len(klasses) == len(kwargs)
        
        if features:
            assert len(names) == len(features)
        else:
            features = [None]*len(names)
            
            
        self.names = names
        self.modules = modules
        self.klasses = klasses
        self.kwargs = kwargs
        self.features = features
            
        self.procs = [ProcessHolder(name = ni,
                                        module = mi,
                                        klass = kli, 
                                        kwargs = kwi,
                                        feature = fi) for (kli, kwi, ni, mi, fi) in zip(klasses, kwargs, names, modules, features)]
        
    
    def to_json(self):
        return {'procs' : [pi.to_json() for pi in self.procs],
                'names' : self.names,
                'modules' : self.modules,
                'klasses' : self.klasses,
                'kwargs' : self.kwargs,
                'features' : self.features}
                 
        
    @classmethod
    def from_json(cls, j):
        
        new = cls(names = j['names'],
                  modules = j['modules'],
                  klasses = j['klasses'],
                  kwargs =  j['kwargs'],
                  features = j['features'])

        new.procs = [ProcessHolder.from_json(jpi) for jpi in j['procs']]
        return new
    
    def fit(self, df = None):
        
        for pi in self.procs:
            pi.fit(df)
        
        return self
        
    def transform(self, df):
        
        for pi in self.procs:
            df = pi.transform(df)
            
        return df
        
    def fit_transform(self, df):
        
        return self.fit(df).transform(df)
    
 
   
    
    
    
''' 
    

class FeatureSubProcessHolder(SubProcessHolder):
    
    
    def __init__(self, 
                 name,
                 module,
                 klass, 
                 kwargs,
                 feature):
        
        self.feature = feature
        return super().__init__(name = name, 
                                module = module,
                                klass = klass, 
                                kwargs = kwargs)
        
        
    def transform(self, df):
        res = super().transform(df)
        df[self.feature] = res
        return df
    
  

    
    
    
    
    
    
    
    
    
    
    
    
    
class FeatureProcessHolder(ProcessHolder):
    
    def __init__(self, 
                 features,
                 names, 
                 modules,
                 klasses, 
                 kwargs):
        
        assert len(features) == len(names)
        assert len(names) == len(klasses)
        assert len(klasses) == len(modules)
        assert len(klasses) == len(kwargs)
        
        
        self.procs = [FeatureSubProcessHolder(feature = fi,
                                              name = ni,
                                              module = mi,
                                              klass = kli, 
                                              kwargs = kwi) for (fi, kli, kwi, ni, mi) in zip(features, klasses, kwargs, names, modules)]

    
  
    
    
    
    
    

    
    
    
    
class TargetProcessHolder(FeatureSubProcessHolder):
    
    def __init__(self, 
                 name,
                 module,
                 klass, 
                 kwargs,
                 target_field):
        
        
        return super().__init__(name = name, 
                                module = module,
                                klass = klass, 
                                kwargs = kwargs,
                                feature = target_field)

'''       