# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 20:22:41 2019

@author: user
"""

import import_utils
from utils.json_utils import get_json
from utils.json_printers.DateDecimalJson import DateDecimalJson
import argparse


past_fields =['url',
         'buyers_premium_amount_base',
         'buyers_premium_details',
         'currency',
         'date',
         'description',
         'estimate_base',
         'hammer_price_base',
         'lot_number',
         'name',
         'sub_name',
         'uisd',
         'sale_uid',
         'house_uid']

upcoming_fields =['url',
                  'buyers_premium_details',
                  'currency',
                  'date',
                  'description',
                  'estimate_base',
                  'lot_number',
                  'name',
                  'sub_name',
                  'uisd',
                  'sale_uid',
                  'house_uid']
'''
def parse_lot(lot):
    out = dict()
    for k, v in lot['constituents'][0].items():
        out[k]=v
        
    for fi in fields:
        out[fi] = lot[fi]
    return out
'''

class ParseLot():
    
    def __init__(self, 
                 fields):
        self.fields = fields
        
    def __call__(self, lot):
        out = dict()
        for k, v in lot['constituents'][0].items():
            out[k]=v
        
        for fi in self.fields:
            out[fi] = lot[fi]
    
        return out

one_constituent_lots = lambda lot : len(lot['constituents']) == 1


def _parse_transformation_result(res, fields):
    
    parse_func = ParseLot(fields)
    
    return list(map(parse_func, filter(one_constituent_lots, res)))
    
    
    
def parse_transformation_result(res, upcoming = False):
    
    
    one_constituent_lots = filter(
                                lambda lot : len(lot['constituents']) == 1,
                                res)
    

    if upcoming:
        fields  = upcoming_fields
    else:
        fields = past_fields
        
        
    return _parse_transformation_result(res, fields)

    

if __name__ == '__main__':
    
    parser = argparse.ArgumentParser()
    parser.add_argument('-in_res_file', type=str, required=True)
    parser.add_argument('-out_file', type=str, required=True)
    args = parser.parse_args()
                        
    
    in_res = get_json(args.in_res_file)
    
    parsed_res = parse_transformation_result(in_res)
    
    DateDecimalJson(parsed_res, args.out_file)

