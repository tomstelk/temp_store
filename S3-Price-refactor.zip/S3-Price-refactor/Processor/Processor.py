# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 16:07:46 2020

@author: 1613098
"""

from abc import ABC, abstractmethod

class Processor(ABC):
    
    @abstractmethod
    def from_json(cls, j):
        pass
    
    @abstractmethod    
    def to_json(self):
        pass 
    
    @abstractmethod    
    def fit(self, df):
        pass
    
    @abstractmethod        
    def transform(self, df):
        pass
    
    def fit_transform(self, df):
        return self.fit(df).transform(df)










class TargetProcessor(Processor):
    
    @abstractmethod        
    def inverse_transform(self, df):
        pass
