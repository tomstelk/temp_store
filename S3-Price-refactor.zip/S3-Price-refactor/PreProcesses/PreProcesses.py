# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 13:27:14 2019

@author: user
"""
from settings import  UNIT_VOL_SIZES, UNIT_VOL_SIZE
import numpy as np
import pandas as pd
from Processor.Processor import Processor
from functools import partial, reduce
from operator import  mul
import os
from importlib import import_module
from copy import deepcopy
import operator

nanmul = lambda a, b : mul(a, b) if a is not None and b is not None else None


class PreProcessor(Processor):

    @classmethod
    def from_json(cls, j):
        return cls(**j)
    
    def fit(self, df):
        return self
    
    def to_json(self):
        return deepcopy(self.__dict__)
    
    
    
class RemoveBadValues(PreProcessor):
    
    def __init__(self, 
                 columns,
                 bad_values):
        
        assert len(columns) == len(bad_values)
        
        self.columns = columns
        self.bad_values = bad_values
    

    
    def transform(self, df):
        
        mask = [True]*len(df.index)
        
        for fi, vi in zip(self.columns, self.bad_values):
            mask_i = df[fi] != vi
            mask = [mj and mij for (mj, mij) in zip(mask, mask_i)]
        
        return df[mask]
        
       
def _to_date(df, columns):
    df_ = df.copy()
    df_.loc[:, columns] = df_.loc[:, columns].apply(pd.to_datetime)
    return df_
    

class MakeDate(PreProcessor):
    
    def __init__(self, 
                 columns):
        
        self.columns = columns
        
        
    def transform(self, df):
        
        return df.pipe(_to_date, columns= self.columns)
        
        
    
class FillNa(PreProcessor):
    
    def __init__(self, 
                 columns,
                 values):
        
        assert len(columns) == len (values)
        
        self.columns = columns
        self.values = values
           
    
    def transform(self, df):
        
        for ci,vi in zip(self.columns, self.values):
            df[ci] = df[ci].fillna(vi)
            
        return df
    
   
    
class VolumeRatio(PreProcessor):
    
    
    def __init__(self, 
                 vol_size_column, 
                 vol_ratio_column):
        
        self.vol_size_column = vol_size_column
        self.vol_ratio_column = vol_ratio_column
        
    
    def transform(self, df):
        df[self.vol_ratio_column] = df[self.vol_size_column].apply(self._get_volume_ratio)
        return df
   
    
    def _get_volume_ratio(self, x):
        if x:
            if x in UNIT_VOL_SIZES:
                return 1.0
            else:
                return x/UNIT_VOL_SIZE
    



class ComputeRatio(PreProcessor):
    
    def __init__(self, 
                 numerator,
                 denominator,
                 out):
        
        if type(numerator)==str:
            self.numerator = [numerator]
        else:
            self.numerator = numerator
        
        if type(numerator)==str:
            self.denominator = [denominator]
        else:
            self.denominator = denominator
            
        
        self.out = out
        
    def transform(self, df):
        
        n = np.prod(df[self.numerator].values, axis = 1)
        d = np.prod(df[self.denominator].values, axis = 1)
        
        df[self.out] = n/d
        
        return df
        
    
class FilterFieldValue(PreProcessor):
    
    def __init__(self, 
                 field,
                 operator_name,
                 value):
        
        self.field = field
        self.operator = getattr(operator, operator_name)
        self.value = value
        
    def transform(self, df):
        return df[self.operator(df[self.field], self.value)]
        
        
class FilterCount(PreProcessor):
    
    def __init__(self, 
                 field,
                 operator_name,
                 count):
        
        self.field = field
        self.operator = getattr(operator, operator_name)
        self.count = count
        
    def transform(self, df):
        return df.groupby(self.field).filter(lambda x: len(x) > self.count)
    
class RemoveOutliers(PreProcessor):
    
    __rel_v = '_tmp_rel_v'
    __z = '_tmp_z'
    
    def __init__(self, 
                 threshold,
                 target,
                 groupby,
                 relative_columns = None):
        
        
        self.threshold = threshold
        self.target = target  
        self.groupby = groupby
        self.relative_columns = relative_columns
        
    def _zscore(self, row, means):
         g = row[self.groupby]
         v = row[self.__rel_v]
         mean = means[g][0]  #means.loc[g, 'mean']
         std = means[g][1] # means.loc[g, 'std']
         
         z = (v - mean) / (std*1*(std != 0) + 1)
         return np.abs(z)

    def _means(self, df):
        
        g = df.groupby(self.groupby)[self.__rel_v]
        m = g.mean()
        s = g.std().fillna(0)
       
        return {ix : [m[ix], s[ix]] for ix in m.index}

    def _drop_tmp_cols(self, df):
        #Drop temp cols
        df.drop([self.__rel_v], axis = 1, inplace = True)
        df.drop([self.__z], axis = 1, inplace = True)
        
        return df
    
    def _calc_relative_value(self, df):
        if self.relative_columns:
            div = np.product([df[ri] for ri in self.relative_columns], axis = 0)
            relative_value = df[self.target]/div
        else:
            relative_value = df[self.target]
        
        df[self.__rel_v] = relative_value
        
        return df
    
    def transform(self, df):
        
        df = self._calc_relative_value(df)
        means = self._means(df)        
        
        df[self.__z] = df.apply(lambda x : self._zscore(x, means), axis=1)
        
        df = df[df[self.__z] < self.threshold]
        
        df = self._drop_tmp_cols(df)
        
        return df
        
class RemoveOutliersGeometric(RemoveOutliers):
    
    __rel_v = '_tmp_rel_v'
    __z = '_tmp_z'
    
    def _calc_relative_value(self, df):
        if self.relative_columns:
            div = np.product([df[ri] for ri in self.relative_columns], axis = 0)
            relative_value = df[self.target]/div
        else:
            relative_value = df[self.target]
        
        df[self.__rel_v] = np.log(relative_value)
        
        return df
    
    
    
    
    
    
'''

class RemoveOutliers(PreProcessor):
    
    __rel_v = '_tmp_rel_v'
    __z = '_tmp_z'
    
    def __init__(self, 
                 threshold,
                 target,
                 groupby,
                 relative_columns = None,
                 store_rel_col = None,
                 store_z_col = None):
        
        
        self.threshold = threshold
        self.target = target  
        self.groupby = groupby
        self.relative_columns = relative_columns
        self.store_rel_col = store_rel_col
        self.store_z_col  = store_z_col
        
        
    def _zscore(self, row, means):
         g = row[self.groupby]
         v = row[self.__rel_v]
         std = means.loc[g, 'std']
         mean = means.loc[g, 'mean']
         z = (v - mean) / (std*1*(std != 0) + 1)
         return np.abs(z)

    def _means(self, df):
        
        g = df.groupby(self.groupby)[self.__rel_v]
        m = g.mean()
        s = g.std()
        
        out = pd.DataFrame(index = m.index)
        
        out['mean'] = m.values
        out['std'] = s.fillna(0)
        
        return out


    def transform(self, df):
        
        
        if self.relative_columns:
            div = np.product([df[ri] for ri in self.relative_columns], axis = 0)
            relative_value = df[self.target]/div
        else:
            relative_value = df[self.target]
        
        df[self.__rel_v] = relative_value
        
        means = self._means(df)        
        df[self.__z] = df.apply(lambda x : self._zscore(x, means), axis=1)
        
        df = df[df[self.__z] < self.threshold]
        
        if self.store_rel_col:
            df.loc[:, self.store_rel_col] = df[self.__rel_v]
        
        if self.store_z_col:
            df.loc[:, self.store_z_col] = df[self.__z]
            
        df = df.drop([self.__rel_v, self.__z], axis = 1)
        
        return df
'''