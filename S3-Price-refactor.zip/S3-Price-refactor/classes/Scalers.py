# -*- coding: utf-8 -*-
"""
Created on Fri Jan 17 15:34:43 2020

@author: 1613098
"""
from sklearn.preprocessing import StandardScaler
from copy import deepcopy
import numpy as np

class MyStandardScaler(StandardScaler):
    
    
    @classmethod
    def from_json(cls, j):
        new = cls()
        
        for k, v in j.items():
            setattr(new, k, v)
            
        return new
    
    
    def to_json(self):
        
        out = deepcopy(self.__dict__)
        
        for k, v in out.items():
            if type(v) == np.ndarray: #hasattr(v, 'tolist'):
                out[k]  = v.tolist()
        
        return out
        

class IdentityScaler():
    
    def fit(self, X, y = None):
        return self
    
    def transform(self, X, y = None):
        return X
    
    def fit_transform(self, X, y = None):
        return self.fit(X).transform(X)
    
    def to_json(self):
        return dict()
    
    @classmethod
    def from_json(cls, j):
        return cls()
    
    
    
