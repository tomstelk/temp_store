import logging
from collections import defaultdict
from functools import partial

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import FunctionTransformer, PolynomialFeatures
from abc import ABC, abstractmethod


logger = logging.getLogger(__name__)



class RegressionModel(ABC):
    @abstractmethod
    def _fit(self, X, y):
        pass
        
    def fit(self, X, y):
        
        logger.info('Fitting regression ...')
        out = self._fit(X, y)
        logger.info('... fitting complete')
        return out
        
    @abstractmethod
    def _predict(self, X):
        pass
    
    def predict(self, X):
        logger.info('Running regression prediction ...')
        out =  self._predict(X)
        logger.info('... prediction complete')
        return out
    
    @abstractmethod
    def to_json(self):
        pass
        
    @abstractmethod
    def from_json(self, j):
        pass

class LinearRegressionModel(RegressionModel):
    
    def __init__(self, 
                 fit_intercept = True):
        
        self.lr = LinearRegression(fit_intercept=fit_intercept)
        
    def _fit(self, X, y):
        self.lr.fit(X, y)
        return self
    
    def _predict(self, X):
        return self.lr.predict(X)
        
    def to_json(self):
        
        out = {'fit_intercept' : self.lr.fit_intercept} 
        
        if hasattr(self.lr, 'coef_'):
            out['coef_'] = self.lr.coef_
            out['intercept_'] =  self.lr.intercept_
        
        return out
        
    @classmethod
    def from_json(cls, j):
        new = cls(fit_intercept = j['fit_intercept'])
        
        if 'coef_' in j.keys():
            new.lr.coef_ = j['coef_']
            new.lr.intercept_ = j['intercept_']
            
        return new

class LogRegressionModel(LinearRegressionModel):
    log_vec = np.vectorize(np.log)
    exp_vec = np.vectorize(np.exp)
    
    def _fit(self, X, y):
        log_y = self.log_vec(y)
        return super()._fit(X, log_y)
    
    def _predict(self, X):
        return self.exp_vec(super()._predict(X))

        
'''
class LogRegression(LinearRegression):
    log_vec = np.vectorize(np.log)
    exp_vec = np.vectorize(np.exp)
    
    def fit(self, X, y):
        log_y = self.log_vec(y)
        return super().fit(X, log_y)
    
    def predict(self, X):
        return self.exp_vec(super().predict(X))


class KernelLogRegression(KernelRidge):
    log_vec = np.vectorize(np.log1p)

    @staticmethod
    def inv_transform(x):
        return np.exp(x) - 1

    exp_vec = np.vectorize(inv_transform)
    
    def fit(self, X, y):
        log_y = self.log_vec(y)
        return super().fit(X, log_y)
    
    def predict(self, X):
        return self.exp_vec(super().predict(X))


class LogRidgeRegression(Ridge):
    log_vec = np.vectorize(np.log)
    exp_vec = np.vectorize(np.exp)
    
    def fit(self, X, y):
        log_y = self.log_vec(y)
        return super().fit(X, log_y)
    
    def predict(self, X):
        return self.exp_vec(super().predict(X))


class ModelLinearExtrap():
    
    def __init__(self, model):
        self.model = model
        self.max = None
        self.m = None
        self.b = None

    
    def _set_lininterp(self, X):
        max_x = max(xii for xi in X for xii in xi)
        max_y = self.model.predict([[max_x]])[0][0] 
        
        self.max  = max_x
        self.m = 1
        self.b = max_y - self.m * max_x
        

    def fit(self, X, y, **kwargs):
        
        self.model.fit(X, y, **kwargs)
        self._set_lininterp(X)
        
        
    def predict(self, X):
        return list(self._predict(X))
    
    def _predict(self, X):
        
        for xi in X:
            for xii in xi:
                if xii > self.max:
                    yield [self.m*xii + self.b]
                else:
                    yield self.model.predict([[xii]])[0]
     

        
    def _get_top_two(self, numbers):
        
        uniq_numbers = list(set(numbers))
        uniq_numbers.sort()
        
        return uniq_numbers[-2:]
           
    def __old_set_lininterp(self, X):
        top_two = self._get_top_two(xii for xi in X for xii in xi)
        pred_top_two = [self.model.predict([[ti]])[0][0] for ti in top_two]
        
        raw_gradient = (pred_top_two[1] - pred_top_two[0])/(top_two[1] - top_two[0])
        
        self.max  = top_two[1]
        self.m = max(0, min(1, raw_gradient))
        self.b = pred_top_two[1] - self.m * top_two[1]        




def make_transformer(func, **kwargs):
    """ Wraps a function into a FunctionTransformer
    """
    method = partial(func, **kwargs)
    transformer = FunctionTransformer(method, validate=False)
    return transformer


def get_weights(X, y, method='count'):
    """ Get weights for WLS with an ugly groupby
    """
    d = defaultdict(list)
    for i, v in enumerate(X):
        d[v].append(y[i])
    var = defaultdict(float)
    for key, value in d.items():
        v = np.var(value)
        var[key] = v
    #weights = np.array([1/var[v] if var[v] != 0 else 1 for v in X])
    weights = np.array([len(d[v]) for v in X])
    #weights = np.array([1/np.abs(v) if v != 0 else 1 for v in X])
    return weights
'''
