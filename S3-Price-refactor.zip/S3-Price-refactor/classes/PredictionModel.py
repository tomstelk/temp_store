# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 18:21:29 2019

@author: user
"""
from ProcessHolder.ProcessHolder import ProcessHolder, MultiProcessHolder
from classes.Encoders import DFMixedEncoder
import logging 
import import_utils
from utils.stratifier_utils import yield_stratified_indices
from utils.score_utils import get_score, agg_scores
from importlib import import_module
import numpy as np

logger = logging.getLogger(__name__)

class PredictionModel():
    
        
    
    def __init__(self, 
                 cfg
                 ):
        
        self.cfg = cfg
        self.price_field = cfg['price_field']
        self.target_field = cfg['target_field']
        self.predict_target_field = cfg['predict_target_field']
        self.predict_field = cfg['predict_field']
        
        self.init_processes(cfg)
        
        
        
    def init_processes(self, cfg):
        self.preproc_fit = self._get_pre_processor(cfg['preproc_fit'])
        self.preproc_predict = self._get_pre_processor(cfg['preproc_predict'])
        self.target_proc = self._get_target_processor(target_field = cfg['target_field'],
                                                      target_process = cfg['target_process'])
        
        self.feature_proc = self._get_feature_proc(cfg['features'])
        self.encoder = self._get_encoder(cfg ['standardise'],
                                         cfg['features'])
        
        self.categories = list()
        
        model_klass = getattr(import_module(cfg['ModelModule']), cfg['ModelKlass'])
        self.model = model_klass(**cfg['ModelKwargs'])
        
        
    def to_json(self):
        
        return  {
                    'cfg' : self.cfg,
                    'preproc_fit' : self.preproc_fit.to_json(),
                    'preproc_predict' : self.preproc_predict.to_json(),
                    'target_field' : self.target_field,
                    'predict_target_field' : self.predict_target_field,
                    'predict_field'  : self.predict_target_field,
                    'target_proc' : self.target_proc.to_json(),
                    'feature_proc' : self.feature_proc.to_json(),
                    'encoder' : self.encoder.to_json(),
                    'categories' : [list(ci) for ci in self.categories],
                    'model' : self.model.to_json()
                }
        
    @classmethod
    def from_json(cls, j):
        
        new = cls(cfg = j['cfg'])
        
        new.preproc_fit = MultiProcessHolder.from_json(j['preproc_fit'])
        new.preproc_predict = MultiProcessHolder.from_json(j['preproc_predict'])
        new.target_proc = ProcessHolder.from_json(j['target_proc'])
        new.feature_proc = MultiProcessHolder.from_json(j['feature_proc'])
        new.encoder = DFMixedEncoder.from_json(j['encoder'])
        
        new.categories = [set(ci) for ci in j['categories']]
        
        model_klass = getattr(import_module(j['cfg']['ModelModule']), j['cfg']['ModelKlass'])
        new.model = model_klass.from_json(j['model'])
        
        return new
        
        
    def fit(self, df):
        
        df = self.preproc_fit.fit_transform(df)
        df = self.target_proc.fit_transform(df)
        df = self.feature_proc.fit_transform(df)
        
        X = self.encoder.fit_transform(df)
        self.categories = list(map(set, self.encoder.categories()))
        
        y = df[self.target_field].values
        
        self.model.fit(X, y)
        return self
        
    def filter_fitted_categories(self, df):
        
        logger.info('Filtering out unfitted categories ... ')
        
        for i, fi in enumerate(self.encoder.encode_features):
            logger.info('{} pre-shape {} ...'.format(fi, df.shape))
            fcats = self.categories[i]
            df = df.loc[df[fi].isin(fcats)]
            logger.info('... post-shape {}'.format(df.shape))
            
        logger.info('... done')
            
        return df
            
        
    def filter_nan(self, df):
        
        logger.info('Filtering out nan values, pre-shape: {} ... '.format(df.shape))
        
        if self.encoder.scale_features:
            df = df.dropna(subset = self.encoder.scale_features)
        
        logger.info('... filtered, post-shape: {}'.format(df.shape))
        
        return df
        
    def predict(self, df):
        df = self.preproc_predict.fit_transform(df)
        df = self.feature_proc.transform(df)
        df = self.filter_fitted_categories(df)
        df = self.filter_nan(df)
        
        X = self.encoder.transform(df)
        
        df[self.predict_target_field] = self.model.predict(X)
        df[self.predict_field] = self.target_proc.inverse_transform(df)
        return df
        
        
    def _get_encoder(self, standardise, features):
        
        encode_features = list()
        scale_features = list()
        for fi in features:
            if fi['type']=='encode':
                encode_features.append(fi['feature'])
            elif fi['type']=='scale':
                scale_features.append(fi['feature'])
            else:
                raise Exception('Feature type not specified')
    
        return DFMixedEncoder(encode_features = encode_features,
                              scale_features = scale_features,
                              standardise = standardise) 
                
    
    def _get_feature_proc(self, fp):
        
        features = [fpi['feature'] for fpi in fp]
        names = [fpi['feature_process']['name'] for fpi in fp]
        modules = [fpi['feature_process']['module'] for fpi in fp]
        klasses = [fpi['feature_process']['klass'] for fpi in fp]
        kwargs = [fpi['feature_process']['kwargs'] for fpi in fp]
        
        
        return MultiProcessHolder(features = features, 
                                    names = names, 
                                    modules = modules,
                                    klasses = klasses,
                                    kwargs = kwargs)
        
    def _get_target_processor(self, 
                              target_field, 
                              target_process):
        
        return ProcessHolder(name = target_process['name'],
                                   module = target_process['module'],
                                   klass = target_process['klass'], 
                                   kwargs = target_process['kwargs'],
                                   feature = target_field)
        
        
    def _get_pre_processor(self, pp):
        
        names = [pi['name'] for pi in pp]
        modules = [pi['module'] for pi in pp]
        klasses = [pi['klass'] for pi in pp]
        kwargs = [pi['kwargs'] for pi in pp]
        
        return MultiProcessHolder(names = names, 
                                  modules = modules,
                                  klasses = klasses,
                                  kwargs = kwargs)
        


#filter_nans = lambda r : list(filter(lambda ri : all(not np.isnan(rii) for rii in ri), zip(*r)))

def filter_nans(list_of_lists):
    no_nans_zipped = list(filter(lambda ri : all(not np.isnan(rii) for rii in ri), zip(*list_of_lists)))    
    return list(zip(*no_nans_zipped))



class PredictModelStratifiedTesting(PredictionModel):
    
    
    def __init__(self, 
                 strat_features,
                 cfg,
                 test_size = 0.25,
                 n_splits = 5
                 ):
        
        self.strat_features = strat_features
        self.test_size = test_size
        self.n_splits = n_splits
        
        return super().__init__(cfg)
    
    def filter_count_strat_features(self, df):
        return df.groupby(self.strat_features).filter(lambda x : x[self.strat_features].count()[0] > 1)
        
    def parse_res(self, df):
        y = df[self.price_field].values
        y_pred = df[self.predict_field].values
        
        no_nans = filter_nans([y, y_pred])
        #unzip = list(zip(*no_nans))
        
        return no_nans[0], no_nans[1]
    
    def test(self, 
             df,
             results_full_df=False):
        
        logger.info('Filtering strat feature counts, pre-shape: {} ... '.format(df.shape))
        df = self.filter_count_strat_features(df)
        logger.info('... filtered, post-shape {}'.format(df.shape))
        
        
        results = list()
        jsons = list()
        raw_scores = list()
        
        
        logger.info('Generating stratifier indices ... ')
        strat_indices = list(yield_stratified_indices(df = df,
                                     strat_features = self.strat_features,
                                     test_size = self.test_size,
                                     n_splits = self.n_splits)
                                    )
        logger.info('... generated')
        
        for i, si in enumerate(strat_indices):
            
            logger.info('Running test {}/{} ... '.format(i+1, self.n_splits))
            
            self.init_processes(self.cfg)
            self.fit(df.iloc[si[0]])
            df_res = self.predict(df.iloc[si[1]])
            
            jsons.append(self.to_json())
            
            y, y_pred = self.parse_res(df_res)
            
            if results_full_df:
                results.append(df_res)
            else:
                results.append((y, y_pred))
                
            raw_scores.append(get_score(y, y_pred))
            
            logger.info('... ran')
            
        agg_score = agg_scores(raw_scores)
            
            
        return agg_score, raw_scores, results, jsons
            
            
            
            
    
        