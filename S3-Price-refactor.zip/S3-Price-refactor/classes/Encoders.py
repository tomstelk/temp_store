# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 14:08:28 2019

@author: user
"""

from sklearn.preprocessing import OneHotEncoder
import numpy as np
from classes.Scalers import IdentityScaler, MyStandardScaler
from copy import deepcopy
from scipy.sparse import csr_matrix, hstack






class OrdinalEncoder():
    
    def __init__(self):
        
        self.categories  = list()
        self._index = list()
        self.n_features = 0
    
    def _add(self, i, xii):
        
        if i >= self.n_features:
            self.categories.append(list())
            self._index.append(dict())
            self.n_features+=1
            
        if xii not in self._index[i].keys():
            self.categories[i].append(xii)
            n = len(self.categories[i])
            self._index[i][xii] = n - 1
        
        
    def fit(self, X, y=None):
        
        for xi in X:
            for i, xii in enumerate(xi):
                self._add(i, xii)
                
        return self
    
    def _transform(self, xi):
        return [idxi[xii] for idxi, xii in zip(self._index, xi)]
    
    def transform(self, X, y=None):
        return np.array(list(map(self._transform, X)))
    
    def fit_transform(self, X, y=None):
        return self.fit(X).transform(X)
    
    def _inverse_transform(self, ixi):
        return [ci[ixii] for ci, ixii in zip(self.categories, ixi)]
        
    def inverse_transform(self, IX):
        return list(map(self._inverse_transform, IX))
    
    def to_json(self):
        return {'categories': self.categories}
    
    @classmethod
    def from_json(cls, j):
        new = cls()
        new.categories = j['categories']
        new.n_features = len(j['categories'])
        new._index = [{ciii:i for i, ciii in enumerate(ci)} for ci in j['categories']]

        return new
        
    
    
class OrdinalOneHotEncoder(OneHotEncoder):
    
    def __init__(self):
        
        self._labeller = OrdinalEncoder()
        return super().__init__()
        
    def categories(self):
        return self._labeller.categories
    
    def fit(self, X, y = None):
        self.fit_transform(X, y)
        return self    

    @classmethod
    def from_json(cls, j):
        
        new = cls()
        
        new._labeller = OrdinalEncoder.from_json(j['_labeller'])
        
        if j.get('n_values_'):
            new.n_values_ = np.array(j['n_values_'])
        
        if j.get('feature_indices_'):
            new.feature_indices_ = np.array(j['feature_indices_'])
            
        if j.get('active_features_'):
            new.active_features_ = np.array(j['active_features_'])
        
        return new

    def to_json(self):
        out = deepcopy(self.__dict__)
        
                      
        out = {'_labeller' : self._labeller.to_json()}
        
        if hasattr(self, 'feature_indices_'):
            out['feature_indices_'] = self.feature_indices_.tolist()
        
        if hasattr(self, 'active_features_'):
            out['active_features_'] = self.active_features_.tolist()
        
        if hasattr(self, 'n_values_'):
            out['n_values_'] = self.n_values_.tolist()
        
        return out
    
    def transform(self, X):
        x_labelled = self._labeller.transform(X)
        return super().transform(x_labelled)
    
    def fit_transform(self, X, y = None):
        x_labelled = self._labeller.fit_transform(X)
        
        return super().fit_transform(x_labelled)        

    def inverse_transform(self, X):
        ords = super().inverse_transform(X)
        return self._labeller.inverse_transform(ords)








class DFMixedEncoder():
    
    
    def __init__(self,
                 encode_features,
                 scale_features,
                 standardise,
                 ):
        
        
        self.encode_features = encode_features
        self.scale_features = scale_features
        self.encoder = OrdinalOneHotEncoder()
        self.standardise = standardise
        S = self._get_scaler(standardise)
        self.scaler = S()
        
    def categories(self):
        return self.encoder._labeller.categories
    
    def _get_scaler(self, standardise):
        if standardise:
            return MyStandardScaler
        else:
            return IdentityScaler
        
    def fit(self, df, y = None):
        
        if self.encode_features:
            df_encode_features = df[self.encode_features].values
            self.encoder.fit(df_encode_features)
        
        if self.scale_features:
            df_scale_features = df[self.scale_features].values
            self.scaler.fit(df_scale_features)
            
        return self
    
    def to_json(self):
        
        return {'encode_features' : self.encode_features,
               'scale_features' : self.scale_features,
               'encoder' : self.encoder.to_json(),
               'standardise' : self.standardise,
               'scaler' : self.scaler.to_json()}
        
    @classmethod
    def from_json(cls, j):
        
        new = cls(encode_features = j['encode_features'],
                  scale_features = j['scale_features'],
                  standardise = j['standardise'])
        
        new.encoder = OrdinalOneHotEncoder.from_json(j['encoder'])
       
        S = new._get_scaler(j['standardise'])
        
        new.scaler = S.from_json(j['scaler'])
        
        return new
        
        
    def transform(self, df):
        
        out =  []
        if self.encode_features:
            df_encode_features = df[self.encode_features].values
            encoded_data = self.encoder.transform(df_encode_features)
            out.append(encoded_data)
        
        if self.scale_features:
            df_scale_features = df[self.scale_features].values
            scaled_data = self.scaler.transform(df_scale_features)
        
            out.append(csr_matrix(scaled_data))
        
        
        return hstack(out)
    
    def fit_transform(self, df, y=None):
        return self.fit(df).transform(df)

    def get_index_scale(self):
        len_encode = len(self.encoder.get_feature_names())
        len_scale = len(self.scaler.get_feature_names())
        return [len_encode + i for i in range(len_scale)]
        
    def get_index_encode(self, feature_value):
        return self.encoder.get_index(feature_value)


'''

class Labeller():
    
    def __init__(self):
        
        self._index = dict()
        self._labels = list()

    def to_json(self):
        return {'_labels': self._labels}
    
    @classmethod
    def from_json(cls, j):
        new = cls()
        new._labels = j['_labels']
        new._index = {li:i for i, li in enumerate(j['_labels'])}

        return new
    
    def fit_transform(self, X):
        return self.fit(X).transform(X)
    
    def fit(self, X):
        
        for xi in X:
            self._add(xi)
            
        return self
        
    def _add(self, xi):
        if xi not in self._index.keys():
            self._labels.append(xi)
            n = len(self._labels)
            self._index[xi] = n - 1

    def transform(self, x):
        return self._index[x]

    def inverse_transform(self, i):
        return self._labels[int(i)]



class LabelledOneHotEncoder(OneHotEncoder):
    
    
    def __init__(self):
        
        self._labeller = Labeller()
        #self._vec_labeller = np.vectorize(self._labeller.transform, otypes = [int])
        #self._vec_inverse_labeller = np.vectorize(self._labeller.inverse_transform, otypes =  [int])
        self._feature_map = dict()
        super().__init__()
        
    def fit(self, X, y = None):
        self.fit_transform(X, y)
        return self
    
    @classmethod
    def from_json(cls, j):
        
        new = cls()
        
        new._labeller = Labeller.from_json(j['_labeller'])
        new._feature_map = j['_feature_map']
        
        if j.get('n_values_'):
            new.n_values_ = np.array(j['n_values_'])
        
        if j.get('feature_indices_'):
            new.feature_indices_ = np.array(j['feature_indices_'])
            
        if j.get('active_features_'):
            new.active_features_ = np.array(j['active_features_'])
        
        return new
        
    
    def to_json(self):
        out = deepcopy(self.__dict__)
        
                      
        out = {'_labeller' : self._labeller.to_json(),
               '_feature_map' : self._feature_map}
        
        if hasattr(self, 'feature_indices_'):
            out['feature_indices_'] = self.feature_indices_.tolist()
        
        if hasattr(self, 'active_features_'):
            out['active_features_'] = self.active_features_.tolist()
        
        if hasattr(self, 'n_values_'):
            out['n_values_'] = self.n_values_.tolist()
        
        return out
    
    def vec_label(self, X):
        _vec_labeller = np.vectorize(self._labeller.transform, otypes = [int])
        return _vec_labeller(X)
    
    def vec_inv_label(self, X):
        _vec_inverse_labeller = np.vectorize(self._labeller.inverse_transform, otypes =  [int])
        return _vec_inverse_labeller(X)
        
        
    def transform(self, X):
        x_labelled = self.vec_label(X)
        return super().transform(x_labelled)
    
    def fit_transform(self, X, y = None):
        self._labeller.fit(xii for xi in X for xii in xi)
        x_labelled = self.vec_label(X)
        
        out = super().fit_transform(x_labelled)
        
        if hasattr(self, 'get_feature_names'):
            self._feature_map = self._get_feature_map()
        return out

    def inverse_transform(self, X):
        return self.vec_inv_label(super().inverse_transform(X))
    
    def get_index(self, label):
        return self._feature_map[label]
    
    def _get_feature_map(self):
        a = self.get_feature_names()
        return {self._parse_feature_name(si) : i for i, si in enumerate(a)}

    def _parse_feature_name(self, s):
        return self._labeller.inverse_transform(int(float(s.split('_')[1])))
'''