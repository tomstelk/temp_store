# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 11:11:11 2020

@author: 1613098
"""


from itertools import product
import numpy as np
from scipy import stats
from importlib import import_module
import logging 
from Processor.Processor import TargetProcessor
logger = logging.getLogger(__name__)
from copy import deepcopy


def rem_geometric_outliers(x, 
                           y,
                           outlier_z):
    #Uses geometric z-score on ratio between x, y
        
    ratios = np.array([yi/xi for xi, yi in zip(x,y)])
    lr = np.ma.log(ratios)
        
    m = np.mean(lr)    
    s = np.std(lr)
    z = np.abs(lr-m)/s
    
    good_lr = np.where((z < outlier_z) == True)[0]
        
    x_good = [x[i] for i in good_lr]
    y_good = [y[i] for i in good_lr]
        
    return x_good, y_good



class Normalisation(TargetProcessor):
    
    #__rel_price = 'rel_price'
    
    __feature_key_set = set(['field', 'unit_value', 'control_fields', 'control_values'])
    
    def __init__(self, 
                 group_field,
                 groups,
                 features,
                 rel_field,
                 price_field, 
                 inv_price_field,
                 norm_kwargs,
                 NormaliserKlass = None,
                 NormaliserKlassName = None,
                 NormaliserKlassModule = None,                 
                 min_points = 2,
                 outlier_z  = 2):
        
        """
        group_field - field to be filtered on for group
        groups - group field value that defines group
        
        features - features that require normalisation
                {field - feature field
                 unit_value - unit value that normalisation is relative to,
                 control_fields - fields that are held constant,
                 control_values - control value for the control_field}
        
        relative_field - groupby field that normalisation is relative to
        price_field - field holding price
        NormaliserKlass - Python class having fit/predict/from_json/to_json methods
        norm_kwargs - Python dict storing kwargs for NormaliserKlass
        min_points - minimum # of points per grouping
        outlier_z - # stdeviations beyond which considered outlier
        
        """
        
        self._check_features_valid(features)
        
        
        self.group_field = group_field
        self.groups = groups
        self.features = features
        self.rel_field = rel_field
        self.price_field = price_field
        self.inv_price_field = inv_price_field
        
        if NormaliserKlass:
            self.NormaliserKlass = NormaliserKlass
        else:
            self.NormaliserKlass = getattr(import_module(NormaliserKlassModule), NormaliserKlassName)

        self.norm_kwargs = norm_kwargs
        self.min_points = min_points
        self.outlier_z = outlier_z
        
        #2-level dictionary stores norm_models by group & feature
        self.norm_models = dict()
        
        for gi in self.groups:
            self.norm_models[gi] =dict()
            for fi in self.features:
                self.norm_models[gi][fi['field']] = None
        
    
    
    
    def _check_features_valid(self, features):
        
        assert all(set(fi.keys()) == self.__feature_key_set for fi in features)
        
    def to_json(self):
        
        out = {'group_field': self.group_field,
                'groups' : self.groups,
                'features' : self.features,
                'rel_field' : self.rel_field,
                'price_field' : self.price_field,
                'inv_price_field' : self.inv_price_field,
                'NormaliserKlassName' : self.NormaliserKlass.__name__,
                'NormaliserModule' : self.NormaliserKlass.__module__,
                'norm_kwargs' : self.norm_kwargs,
                'min_points' : self.min_points,
                'outlier_z' : self.outlier_z}
        
        _to_json = lambda x : x.to_json() if hasattr(x, 'to_json') else x
        
        out['norm_models'] = {ki : {viki : _to_json(vivi) for viki, vivi in vi.items()} for ki, vi in self.norm_models.items()}
        
        return out


    @classmethod
    def from_json(cls, j):
        
        init_kwargs = dict()
        
        init_kwargs['group_field'] = j['group_field']
        init_kwargs['groups'] = j['groups']
        init_kwargs['features'] = j['features']
        init_kwargs['rel_field'] = j['rel_field']
        init_kwargs['price_field'] = j['price_field']
        init_kwargs['inv_price_field'] = j['inv_price_field']
        NormaliserKlass = getattr(import_module(j['NormaliserModule']), 
                                                   j['NormaliserKlassName'])
        init_kwargs['NormaliserKlass'] = NormaliserKlass
               
        init_kwargs['norm_kwargs'] = j['norm_kwargs']
        init_kwargs['min_points'] = j['min_points']
        init_kwargs['outlier_z'] = j['outlier_z']
        
        
        new = cls(**init_kwargs)
        
        _from_json = lambda j : NormaliserKlass.from_json(j)
        
        new.norm_models = {ki : {viki : _from_json(vivi) for viki, vivi in vi.items()} for ki, vi in j['norm_models'].items()}
        
        return new
        
    
    def _filter_data(self, 
                    df, 
                    field, 
                    value):
        df = df[df[field] == value]                
        return df
    
    def _group_data(self, 
                   df,
                   field, 
                   unit_value,
                   relative, 
                   min_points):
        
        
        df = df.groupby([relative, field]).mean()
        df.reset_index(inplace = True)
        
        groups_at_unit = set(df[df[field]==unit_value][relative])
        groups_enough_points = set(df.groupby(relative).filter(lambda x: len(x) >= min_points)[relative])
        
        groups_filter = groups_enough_points.intersection(groups_at_unit)
        
        df = df[df[relative].isin(groups_filter)]
        
        return df
    
    
    def _calc_rel_price(self, 
                       df, 
                       field, 
                       unit_value, 
                       price,
                       relative):
        
        
        
        unit_price = df[df[field]==unit_value][[relative, price]]
        unit_price_mapper = unit_price.set_index(relative).to_dict(orient = 'index')
        unit_price_mapper = {k:v[price] for k,v in unit_price_mapper.items()}

        return df.apply(lambda row : row[price]/unit_price_mapper[row[relative]], axis = 1)
        #df[self.__rel_price] = df.apply(lambda row : row[price]/unit_price_mapper[row[relative]], axis = 1)
        
        #return df
        
    def _fit(self, df, group, feature):
        
        logger.info('Pre-filter data size for {}: {} ... '.format(group,  df.shape))
        df = self._filter_data(df, self.group_field, group)
        logger.info('... post-filter data size: {}'.format(df.shape))
        
        
        for cfi, cvi in zip(feature['control_fields'], feature['control_values']):
            logger.info('Pre-filter data size for {}={} : {} ... '.format(cfi, cvi, df.shape))
            df = self._filter_data(df, cfi, cvi)
            logger.info('... post-filter data size: {}'.format(df.shape))
            
        
        logger.info('Grouping data by {} ...'.format(self.rel_field))
        df = self._group_data(df, 
                             feature['field'], 
                             feature['unit_value'],
                             self.rel_field,
                             self.min_points)
        logger.info('... grouped')
        
        logger.info('Computing relative prices for feature {} ...'.format(feature['field']))
        rel_price = self._calc_rel_price(df, 
                                 feature['field'], 
                                 feature['unit_value'],
                                 self.price_field,
                                 self.rel_field)
        logger.info('... computed')
        
        x = df[feature['field']].values
        y = rel_price.values
        
        logger.info('Removing outliers, number of data points: {} ...'.format(len(x)))
        x, y = rem_geometric_outliers(x, y, self.outlier_z)
        logger.info('... removed, number of data points: {}'.format(len(x)))
        
        n = self.NormaliserKlass(**self.norm_kwargs)
        
        logger.info('Fitting {} x {} ...'.format(group, feature['field']))
        n.fit(x, y)
        logger.info('... fitted')
        
        return n
        
    def fit(self, df):
        
        for gi, fi in product(self.groups, self.features):
        
            self.norm_models[gi][fi['field']] = self._fit(df, gi, fi)
            
        return self
            
    
    def _inverse_transform_row(self, row):
        
        multiplier = self._multiplier(row)            
        out = row[self.inv_price_field]*multiplier
        
        return out
            
    def _check_fitted(self):
        norm_models = [vii for vi in self.norm_models.values() for vii in vi.values()]
        assert all(hasattr(nmodeli, 'predict') for nmodeli in norm_models), 'Normalisation not fitted'

    def _multiplier(self, 
                    group,
                    feature,
                    feature_val,
                    feature_unit_val):
        
        if group in self.norm_models.keys():
            nm = self.norm_models[group][feature]
            
            return list(nm.predict([feature_val]))[0] #list(nm.predict([feature_val]))[0]
        else:
            return feature_val/feature_unit_val
        
    
    def multiplier(self, df):
        
        group = df[self.group_field].values
        multiplier = np.ones(group.shape)
        
        for fi in self.features:
            gf = zip(group,
                     df[fi['field']].values)
            
            _get_multiplier_vec = lambda gfi : self._multiplier(group = gfi[0],
                                                                feature = fi['field'],
                                                                feature_val = gfi[1],
                                                                feature_unit_val = fi['unit_value'])
            
            m = np.array(list(map(_get_multiplier_vec, gf)))
            multiplier = np.multiply(multiplier, m)
            
        return multiplier
            
            
            
    def transform(self, df):
        self._check_fitted()      
        
        price = df[self.price_field].values
        multiplier = self.multiplier(df)
        
        return  np.divide(price, multiplier)


    def inverse_transform(self, df):
        self._check_fitted()      
        
        price = df[self.inv_price_field].values
        multiplier = self.multiplier(df)
        
        return  np.multiply(price, multiplier)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
'''    
    
    
    
    
    

class NormalisationSlow(TargetProcessor):
    
    #__rel_price = 'rel_price'
    
    __feature_key_set = set(['field', 'unit_value', 'control_fields', 'control_values'])
    
    def __init__(self, 
                 group_field,
                 groups,
                 features,
                 rel_field,
                 price_field, 
                 inv_price_field,
                 norm_kwargs,
                 NormaliserKlass = None,
                 NormaliserKlassName = None,
                 NormaliserKlassModule = None,                 
                 min_points = 2,
                 outlier_z  = 2):
        
        """
        group_field - field to be filtered on for group
        groups - group field value that defines group
        
        features - features that require normalisation
                {field - feature field
                 unit_value - unit value that normalisation is relative to,
                 control_fields - fields that are held constant,
                 control_values - control value for the control_field}
        
        relative_field - groupby field that normalisation is relative to
        price_field - field holding price
        NormaliserKlass - Python class having fit/predict/from_json/to_json methods
        norm_kwargs - Python dict storing kwargs for NormaliserKlass
        min_points - minimum # of points per grouping
        outlier_z - # stdeviations beyond which considered outlier
        
        """
        
        self._check_features_valid(features)
        
        
        self.group_field = group_field
        self.groups = groups
        self.features = features
        self.rel_field = rel_field
        self.price_field = price_field
        self.inv_price_field = inv_price_field
        
        if NormaliserKlass:
            self.NormaliserKlass = NormaliserKlass
        else:
            self.NormaliserKlass = getattr(import_module(NormaliserKlassModule), NormaliserKlassName)

        self.norm_kwargs = norm_kwargs
        self.min_points = min_points
        self.outlier_z = outlier_z
        
        #2-level dictionary stores norm_models by group & feature
        self.norm_models = dict()
        
        for gi in self.groups:
            self.norm_models[gi] =dict()
            for fi in self.features:
                self.norm_models[gi][fi['field']] = None
        
    
    
    
    def _check_features_valid(self, features):
        
        assert all(set(fi.keys()) == self.__feature_key_set for fi in features)
        
    def to_json(self):
        
        out = {'group_field': self.group_field,
                'groups' : self.groups,
                'features' : self.features,
                'rel_field' : self.rel_field,
                'price_field' : self.price_field,
                'inv_price_field' : self.inv_price_field,
                'NormaliserKlassName' : self.NormaliserKlass.__name__,
                'NormaliserModule' : self.NormaliserKlass.__module__,
                'norm_kwargs' : self.norm_kwargs,
                'min_points' : self.min_points,
                'outlier_z' : self.outlier_z}
        
        _to_json = lambda x : x.to_json() if hasattr(x, 'to_json') else x
        
        out['norm_models'] = {ki : {viki : _to_json(vivi) for viki, vivi in vi.items()} for ki, vi in self.norm_models.items()}
        
        return out


    @classmethod
    def from_json(cls, j):
        
        init_kwargs = dict()
        
        init_kwargs['group_field'] = j['group_field']
        init_kwargs['groups'] = j['groups']
        init_kwargs['features'] = j['features']
        init_kwargs['rel_field'] = j['rel_field']
        init_kwargs['price_field'] = j['price_field']
        init_kwargs['inv_price_field'] = j['inv_price_field']
        NormaliserKlass = getattr(import_module(j['NormaliserModule']), 
                                                   j['NormaliserKlassName'])
        init_kwargs['NormaliserKlass'] = NormaliserKlass
               
        init_kwargs['norm_kwargs'] = j['norm_kwargs']
        init_kwargs['min_points'] = j['min_points']
        init_kwargs['outlier_z'] = j['outlier_z']
        
        
        new = cls(**init_kwargs)
        
        _from_json = lambda j : NormaliserKlass.from_json(j)
        
        new.norm_models = {ki : {viki : _from_json(vivi) for viki, vivi in vi.items()} for ki, vi in j['norm_models'].items()}
        
        return new
        
    
    def _filter_data(self, 
                    df, 
                    field, 
                    value):
        df = df[df[field] == value]                
        return df
    
    def _group_data(self, 
                   df,
                   field, 
                   unit_value,
                   relative, 
                   min_points):
        
        
        df = df.groupby([relative, field]).mean()
        df.reset_index(inplace = True)
        
        groups_at_unit = set(df[df[field]==unit_value][relative])
        groups_enough_points = set(df.groupby(relative).filter(lambda x: len(x) >= min_points)[relative])
        
        groups_filter = groups_enough_points.intersection(groups_at_unit)
        
        df = df[df[relative].isin(groups_filter)]
        
        return df
    
    
    def _calc_rel_price(self, 
                       df, 
                       field, 
                       unit_value, 
                       price,
                       relative):
        
        
        
        unit_price = df[df[field]==unit_value][[relative, price]]
        unit_price_mapper = unit_price.set_index(relative).to_dict(orient = 'index')
        unit_price_mapper = {k:v[price] for k,v in unit_price_mapper.items()}

        return df.apply(lambda row : row[price]/unit_price_mapper[row[relative]], axis = 1)
        #df[self.__rel_price] = df.apply(lambda row : row[price]/unit_price_mapper[row[relative]], axis = 1)
        
        #return df
        
    def _fit(self, df, group, feature):
        
        logger.info('Pre-filter data size for {}: {} ... '.format(group,  df.shape))
        df = self._filter_data(df, self.group_field, group)
        logger.info('... post-filter data size: {}'.format(df.shape))
        
        
        for cfi, cvi in zip(feature['control_fields'], feature['control_values']):
            logger.info('Pre-filter data size for {}={} : {} ... '.format(cfi, cvi, df.shape))
            df = self._filter_data(df, cfi, cvi)
            logger.info('... post-filter data size: {}'.format(df.shape))
            
        
        logger.info('Grouping data by {} ...'.format(self.rel_field))
        df = self._group_data(df, 
                             feature['field'], 
                             feature['unit_value'],
                             self.rel_field,
                             self.min_points)
        logger.info('... grouped')
        
        logger.info('Computing relative prices for feature {} ...'.format(feature['field']))
        rel_price = self._calc_rel_price(df, 
                                 feature['field'], 
                                 feature['unit_value'],
                                 self.price_field,
                                 self.rel_field)
        logger.info('... computed')
        
        x = df[feature['field']].values
        y = rel_price.values
        
        logger.info('Removing outliers, number of data points: {} ...'.format(len(x)))
        x, y = rem_geometric_outliers(x, y, self.outlier_z)
        logger.info('... removed, number of data points: {}'.format(len(x)))
        
        n = self.NormaliserKlass(**self.norm_kwargs)
        
        logger.info('Fitting {} x {} ...'.format(group, feature['field']))
        n.fit(x, y)
        logger.info('... fitted')
        
        return n
        
    def fit(self, df):
        
        for gi, fi in product(self.groups, self.features):
        
            self.norm_models[gi][fi['field']] = self._fit(df, gi, fi)
            
        return self
            
            
    def _default_multiplier(self, row):
        multiplier = 1
        for fi in self.features:
            x = row[fi['field']]
            unit = fi['unit_value']
            multiplier *= (x/unit)
            
        return multiplier
            
    def _multiplier(self, row):
        
        multiplier = 1
        g = row[self.group_field]
        
        if g in self.norm_models.keys():
            feature_norm_models = self.norm_models[g]
        else:
            return self._default_multiplier(row) #row[self.price_field]
        
        for fi, ni in feature_norm_models.items():
            
            x = row[fi]
            pred = list(ni.predict([x]))[0]
            multiplier *= pred
        
        return multiplier
        
    def _transform_row(self, row):
        
        multiplier = self._multiplier(row)            
        out = row[self.price_field]/multiplier
        
        return out
    
    def _inverse_transform_row(self, row):
        
        multiplier = self._multiplier(row)            
        out = row[self.inv_price_field]*multiplier
        
        return out
            
    def _check_fitted(self):
        norm_models = [vii for vi in self.norm_models.values() for vii in vi.values()]
        assert all(hasattr(nmodeli, 'predict') for nmodeli in norm_models), 'Normalisation not fitted'
    
    def inverse_transform(self, df):
        self._check_fitted()        
        return  df.apply(self._inverse_transform_row, axis = 1)
    
    def transform(self, df):
        self._check_fitted()        
        return  df.apply(self._transform_row, axis = 1)

'''