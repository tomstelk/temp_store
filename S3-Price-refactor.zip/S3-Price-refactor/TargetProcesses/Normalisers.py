from collections import defaultdict
import numpy as np
from sklearn.linear_model import LinearRegression
import logging
from abc import ABC, abstractmethod
from collections import OrderedDict

logger = logging.getLogger(__name__)


class Normaliser(ABC):
    
    @abstractmethod
    def _fit(self, X, y):
        pass
        
    def fit(self, X, y):
        
        logger.info('Fitting normaliser ...')
        out = self._fit(X, y)
        logger.info('... fitting complete')
        return out
        
    @abstractmethod
    def _predict(self, X, y=None):
        pass
    
    def predict(self, X, y=None):
        return self._predict(X, y)    
    
    @abstractmethod
    def to_json(self):
        pass
        
    @abstractmethod
    def from_json(self, j):
        pass
        
    
class LinearNormaliser(Normaliser):
    
    def __init__(self,
                 fit_intercept = False):
        
        self.fit_intercept = fit_intercept
        self.lr = LinearRegression(fit_intercept=fit_intercept)
        
    def _fit(self, X, y):
        
        X = np.array(X)
        if len(X.shape)  == 1:
            X = np.expand_dims(X, 1)        
        
        return self.lr.fit(X, y)
        
    
    def to_json(self):
        return {'coef_' : self.lr.coef_.tolist(),
                'intercept_' : self.lr.intercept_,
                'fit_intercept' : self.fit_intercept}
        
    @classmethod
    def from_json(cls, j):
        
        new = cls(fit_intercept = j['fit_intercept'])
        new.lr.coef_ = np.array(j['coef_'])
        new.lr.intercept_ = j['intercept_']
        
        return new
        
    def _predict(self, X, y=None):
        yield from self.lr.predict(X)
    
    
class AvgNormaliser(Normaliser):
    
    def __init__(self):
        
        self.mapper = OrderedDict()
        
    def _make_avg_mapper(self, X, y):
        
        out = OrderedDict()
        _arrange_vals = defaultdict(list)
        
        for xi, yi in zip(X, y):
            _arrange_vals[xi].append(yi)
        
        _sorted_vals = sorted(_arrange_vals.items(), key = lambda v:v[0])
        
        for xi, yi in _sorted_vals:
            out[xi] = np.average(yi)
        
        return out
        
    def to_json(self):
        return {'x' : list(self.mapper.keys()),
                'y' : list(self.mapper.values())}
    
    
    @classmethod
    def from_json(cls, j):
        
        new = cls()
        
        mapper = OrderedDict()
        
        for xi, yi in zip(j['x'], j['y']):
            mapper[xi] = yi
        
        new.mapper = mapper
        
        return new
        
    ''''
    def _get_xy(self, mapper):
        xy = sorted(mapper.items(), key  = lambda xyi:xyi[0])
        x = [xyi[0] for xyi in xy]
        y = [xyi[1] for xyi in xy]
        
        return x, y
    '''
    
    def _fit(self, X, y):
        
        self.mapper = self._make_avg_mapper(X, y)
        
        '''
        x, y = self._get_xy(self.mapper)
        
        self.x = x
        self.y = y
        '''
        

        
    def _interp(self, xi):
        return np.interp(xi, 
                         list(self.mapper.keys()), 
                         list(self.mapper.values()))
        
        
    def _predict(self, X, y = None):
        
        assert self.mapper, 'Normaliser not fitted'
        
        for xi in X:
            if xi in self.mapper.keys():
                yield self.mapper[xi]
            else:
                yield self._interp(xi)
    
    
class IncrAvgNormaliser(AvgNormaliser):
    
    def _make_avg_mapper(self, X, y):
        
        out = OrderedDict()
        avg_mapper = super()._make_avg_mapper(X, y)
        
        #x, y = self._get_xy(avg_mapper)
        
        x = list(avg_mapper.keys())
        y = list(avg_mapper.values())
        
        y_inc = y[:1]
        
        for i, yi in enumerate(y[1:]):
            if yi > y_inc[i]:
                y_inc.append(yi)
            else:
                y_inc.append(y_inc[i])
        
        for xi, yi in zip(x, y_inc):
            out[xi] = yi
        
        return out

'''
import logging
import os
import pickle
from importlib import import_module
from operator import eq, mul, ne
from collections import defaultdict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


from classes.RegressionModels import make_transformer,  get_weights
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.pipeline import make_pipeline
from settings import  UNIT_QUANTITY, UNIT_VOL_SIZES, MIN_NORM_PNTS

logging.basicConfig()
logger = logging.getLogger(__name__)


_EXPECTED_KEYS = [
    'target_column',
    'save_dir',
    'regression',
    'conditions'
]


class FilterUsefulVec:
    """ Filter DF for key_id with at least 2 elems in key_x and unb in those two elems
    """
    def __init__(self, key_x='quantity', key_y='hammer_price_base', key_id='gid'):
        self.key_x = key_x
        self.key_y = key_y
        self.key_id = key_id

    def __call__(self, df, unb):

        vecs = (
            df.groupby([self.key_id, self.key_x])
            .mean()[self.key_y]
            .groupby(self.key_id)
            .count()
        )

        mask = (vecs > 1)
        useful_vec = vecs[mask]
        logger.debug(f'Found {useful_vec.index.shape[0]} w/ at least 2 elems')

        mask = (
            df[df[self.key_id].isin(useful_vec.index)]
            .groupby([self.key_id])[self.key_x]
            .apply(list)
            .reset_index()
        )

        bools = [unb in x for x in mask[self.key_x]]
        useful_vec = useful_vec[bools]
        logger.debug(f'Found {useful_vec.index.shape[0]} containing {unb} in {self.key_x}')

        filtered = df[df[self.key_id].isin(useful_vec.index)]
        return filtered


class FilterQuartile:
    """ Remove outliers from the distance inter quartile
    """

    def __init__(self, key_x, key_y, threshold=1.5):
        self.key_x = key_x
        self.key_y = key_y
        self.threshold = threshold

    def __call__(self, data):
        tmp = (
            data
            .groupby(self.key_x)
            .describe()
            [[(self.key_y, '25%'), (self.key_y, 'mean'), (self.key_y, '75%')]]
        )
        tmp['range'] = tmp[(self.key_y, '75%')] - tmp[(self.key_y, '25%')]

        data['over'] = (
            self.threshold*tmp['range'].loc[data[self.key_x].values].values +
            tmp[(self.key_y, 'mean')].loc[data[self.key_x].values].values
        )

        tmp = data[data[self.key_y] <= data['over']]
        return tmp


def gen_ratios(df, key_x, key_y, key_id):
    ratios = []
    uniques = df[key_id].unique()
    logger.debug(f'Found {len(uniques)} unique keys')
    if len(uniques) == 0:
        raise ValueError('No unique keys found')
    # Probably dont need the loop here
    for i, gid in enumerate(uniques):
        if i % 100 == 1:
            logger.info(f'Processed {i}/{len(uniques)} unique keys')
        s = df[df[key_id] == gid].groupby(key_x).mean()[key_y]
        s = s/s.loc[1.0]
        ratios.append(s)
        result = pd.concat(ratios).reset_index()
    return result



class DiscountFactor:
    """ Computes the discount factor for key_y against key_x

    - Outliers are filtered based on their distanc from the mean: elem - mean < threshold*d_quartile

    Returns:
        The vector (key_x, ratio) from the linear model
        The complete ratio population (just for debug for now)
    """

    def __init__(self, key_x, key_y, key_id, reg_model, threshold=1.5, debug=False):
        self.key_x = key_x
        self.key_y = key_y
        self.key_id = key_id
        self.threshold = threshold
        self.reg_model = reg_model
        self.filter_vec = FilterUsefulVec(key_x=self.key_x, key_y=self.key_y, key_id=self.key_id)
        self.filter_q = FilterQuartile(key_x=self.key_x, key_y=self.key_y, threshold=self.threshold)
        self.debug = debug

    def __call__(self, df, unit=1):
        vecs = self.filter_vec(df, unit)
        ratios = gen_ratios(vecs, self.key_x, self.key_y, self.key_id)
        filtered = self.filter_q(ratios)
        filtered = self.filter_n(filtered, N= MIN_NORM_PNTS)

        assert len(filtered) > 0


        X = filtered[self.key_x].values
        y = filtered[self.key_y].values

        mod = self.reg_model.fit(X-1, y-1)
        if self.debug:
            self.debug_plot(X-1, y-1, mod, self.key_x)

        self.model = mod
        return mod
    
    @staticmethod
    def debug_plot(X, y, mod, key):
        """ Some debug plots
        """
        xs = np.linspace(X.min(), X.max())
        preds = mod.predict(xs).reshape(-1)
        fig, axes = plt.subplots(1, 2)
        axes[0].scatter(X, y, alpha=.7)
        axes[0].plot(xs, preds, '-k')
        axes[0].plot(xs, xs, '--k', alpha=.8)
        axes[0].yaxis.grid()
        axes[0].set_title('Ratios')

        mask = np.nonzero(y)
        preds_ = mod.predict(X[mask]).reshape(-1)
        residuals = y[mask].reshape(-1) - preds_
        axes[1].hist(residuals, bins=30)
        axes[1].set_title('Residuals distribution')

        fig.suptitle(f'Normalisation {key}')

        return fig


    def filter_n(self, df, N=10):
        """ Filter on key_x for at least N points
        """
        mask = (df.groupby(self.key_x).count() >= N)
        mask = mask[mask].dropna()
        useful_x = mask.index
        return  df[df[self.key_x].isin(useful_x)]

    def transform_df(self, df, unit=1):
        vecs = self.filter_vec(df, unit)
        ratios = gen_ratios(vecs, self.key_x, self.key_y, self.key_id)
        filtered = self.filter_q(ratios)
        x_ratios = filtered[self.key_x].unique()

        predicted_ratios = self.model.predict(x_ratios.reshape(-1,1))
        predicted_ratios = predicted_ratios.reshape(-1,)

        df_data = np.array([x_ratios, predicted_ratios.reshape(-1,)]).T
        result = pd.DataFrame(df_data, columns=[self.key_x, self.key_y])
        result = result.sort_values(by=self.key_x)
        return result


def plot_discount_factor(discount_vec, ratios, key_x, key_y):
    fig, ax = plt.subplots()
    X = discount_vec[key_x]
    Y = discount_vec[key_y]
    x_plot = np.linspace(X.min(), X.max())

    ax.scatter(ratios[key_x], ratios[key_y], alpha=.2)
    ax.scatter(X, Y, marker='^', color='k', label='Discount curve')
    ax.plot(x_plot, x_plot, label="Slope 1")
    #ax.fill_between(X, Y, X, alpha=.3)
    ax.legend()

    return ax, fig



class NormalisationRegression(object):
    """ Wrapper to extend normalisation regressor

    Aims at 1D Ridge regression with basis functions defined by 
    transformer.
    """

    def __init__(self, 
                 transformer, 
                 estimator, 
                 weighted=False):
        self.transformer = transformer
        self.estimator = estimator
        self.pipe = make_pipeline(transformer, estimator)
        self.weighted = weighted

    @staticmethod
    def check_size(X):
        X_ = X
        if X.ndim == 1:
            X_ = X.reshape(-1, 1)
        return X_

    def fit(self, X, y=None):
        X_, y_ = self.check_size(X), self.check_size(y)
        estimator_params = {}
        if self.weighted:
            weights = get_weights(X, y)
            step_name = self.estimator.__class__.__name__.lower()
            estimator_params = {f'{step_name}__sample_weight': weights}
        self.pipe.fit(X_, y_, **estimator_params)
        return self

    def predict(self, X):
        X_ = self.check_size(X)
        return self.pipe.predict(X_)








def log_transform(X, y=None, scale=5):
    return np.log1p(X/scale)




class Normaliser():

    #key_price = settings.PRICE
    #key_vol_ratio = settings.VOL_RATIO_KEY
    #key_num = settings.NUM_KEY
    #key_id = settings.GID_KEY
    #model_file_prefix = settings.NORMALISATION_MODEL_PREFIX
    
'''
    
'''
    conditions = {
        'whiskey': [('ws_type', 'whiskey', eq)],
        'wine': [
            ('ws_type', 'wine', eq),
            ('ws_sub_type', 'champagne', ne)
        ],
        'champagne': [
            ('ws_type', 'wine', eq),
            ('ws_sub_type', 'champagne', eq)
            ],
        'brandy': [('ws_type', 'brandy', eq)],
        'red': [
            ('ws_type', 'wine', eq),
            ('ws_sub_type', 'red', eq)
            ],
        'white': [
            ('ws_type', 'wine', eq),
            ('ws_sub_type', 'white', eq)
            ]
    }
    
    
    conditions = {
        'wine': [
            ('ws_type', 'wine', eq)
        ],
        'red': [
            ('ws_type', 'wine', eq),
            ('ws_sub_type', 'red', eq)
        ],
    }
'''
    
    
'''
    
    base_transform = make_transformer(log_transform, **{'scale': 5})
    base_estimator = Ridge(fit_intercept=False)
    base_reg_model = NormalisationRegression(base_transform, 
                                             base_estimator, 
                                             weighted=True)

    def __init__(self, 
                 model_name,
                 key_price,
                 key_vol_ratio,
                 key_quantity,
                 key_id,
                 normalisation_groups,
                 save_dir=None, 
                 reg_model=None, 
                 debug=False):


        self.model_file_prefix ='{}_'.format(model_name)
        self.normalisation_groups = normalisation_groups
        self.key_price = key_price
        self.key_vol_ratio = key_vol_ratio
        self.key_quantity = key_quantity
        self.key_id = key_id
        self.save_dir = save_dir
        self.model = dict()
        self.reg_model = reg_model or self.__class__.base_reg_model
        self.debug = debug

    def _predict(self, model_name, in_val):
        
        if model_name in self.model.keys():
            inpt = np.array([[in_val - 1]])
            return self.model[model_name].predict(inpt)[0][0] + 1

    def transform(self, 
                  ws_type, 
                  ws_sub_type,
                  vol_ratio, 
                  quantity):
        
        assert self.model is not None, "No model has been found, use either load or fit"

        # Find the right model name
        vol_model_name, quantity_model_name = self._get_model_names(ws_type, 
                                                                    ws_sub_type)
        
        vol_df = self._predict(vol_model_name, vol_ratio) 
        bottles_df = self._predict(quantity_model_name, quantity) 

        return {self.key_vol_ratio: vol_df, 
                self.key_quantity: bottles_df}


    def _get_model_names(self, ws_type, ws_sub_type):
        if ws_sub_type in self.normalisation_groups.keys():
            base_name = ws_sub_type
        elif ws_type in self.normalisation_groups.keys():
            base_name = ws_type
        
        
        vol_model_name = self._make_model_filename(base_name, self.key_vol_ratio)
        quantity_model_name = self._make_model_filename( base_name, self.key_quantity)

        return vol_model_name, quantity_model_name
        

    def load(self):
        logger.info('Loading models at: {}'.format(self.save_dir))
        model_file_names = [f for f in os.listdir(self.save_dir) if f.startswith(self.model_file_prefix)]
        
        self.model = dict()
        
        for name in model_file_names:
            fname = os.path.join(self.save_dir, name)
            with open(fname, 'rb') as f:
                model = pickle.load(f)
                
            self.model[name] = model
        return self

    def _save_model(self, model, fname):
        """ For a condition [(key1, value1), (key2, value2)], the 
        model will have the name:
            key1_value_1_key2_value2_VOL_SUFFIX.pkl
            key1_value_1_key2_value2_BOTTLES_SUFFIX.pkl
        """
        
        if not self.save_dir:
            logger.info('Not saving since no save_dir')
            return None
            
        
        fname = os.path.join(self.save_dir, fname)
        logger.debug('Saving model to: {}'.format(fname))
        if not os.path.exists(os.path.dirname(fname)):
            os.makedirs(os.path.dirname(fname))
            
        with open(fname, 'wb') as f:
            pickle.dump(model, f)
            
        if self.debug:
            self._debug(fname)
            
    def _debug(self, fname):
        fig_path = os.path.join(os.path.dirname(fname), 'figs')
        if  not os.path.exists(fig_path):
            logger.debug(f"Debug flag but couldn't find ./{fig_path}, creating it")
            os.makedirs(fig_path)
        
        logger.debug(f'Saving debug curves in {fig_path}')
        figures = plt.get_fignums()
        logger.debug(f'Found {len(figures)} figures to save')
        for i in figures:
            plt.figure(i)
            plt.savefig(os.path.join(fig_path, f'figure_{i}.png'))
        

    
    def _make_model_filename(self, *args):
        return self.model_file_prefix + '_'.join(args) + '.pkl'
    
    def fit(self, df):

        model = dict()
        
        for name, cond in self.normalisation_groups.items():
            base_name = name

            logger.info('Normalising type: {}'.format(name))
            mask = eval_condition(df, cond)
            
            tmp = df[mask]
            
            
            tmp_unit_vol = tmp[tmp[self.key_vol_ratio] == 1]
            tmp_unit_quantity = tmp[tmp[self.key_quantity] == 1]
            
            if len(tmp_unit_vol)==0 or len(tmp_unit_quantity)==0:
                continue
            
            vol_discount = DiscountFactor(
                    key_x=self.key_vol_ratio,
                    key_y=self.key_price,
                    key_id=self.key_id,
                    reg_model=self.reg_model,
                    debug=self.debug)(tmp_unit_quantity)
            
            vol_model_file_name = self._make_model_filename(base_name, self.key_vol_ratio)
            self._save_model(vol_discount, vol_model_file_name)
            
            model[vol_model_file_name] = vol_discount

            # quantity
            #tmp = df[mask]
            tmp_unit_vol = tmp[tmp[self.key_vol_ratio] == 1]
            num_discount = DiscountFactor(
                    key_x=self.key_quantity,
                    key_y=self.key_price,
                    key_id=self.key_id,
                    reg_model=self.reg_model,
                    debug=self.debug)(tmp_unit_vol)
            
            quantity_model_file_name = self._make_model_filename(base_name, self.key_quantity)
            self._save_model(num_discount, quantity_model_file_name)

            model[quantity_model_file_name] = num_discount
            

        self.model = model
        return self

def eval_condition(df, arr):
    """ Evaluate condition represented by arr of (key, value, operator)

    We only use AND for now
    """
    key, value, op = arr[0]
    mask = op(df[key], value)
    for cond in arr[1:]:
        key, value, op = cond
        mask = op(df[key], value) & mask
    return mask




'''