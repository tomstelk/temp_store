'''
import import_utils
from utils.json_utils import get_json
import os
import pandas as pd

from utils.yaml_utils import get_yaml_full_load
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
from collections import defaultdict
from utils.log_utils import get_print_logger

logger = get_print_logger()


parent_dir = os.path.abspath('..')
tdata_file = os.path.join(parent_dir, 'bingbang_wine_data_v0-1_20190913.json')
tdata = get_json(tdata_file)    




df = pd.DataFrame(tdata)
parent_dir = os.path.abspath('..')






'''


from classes.PredictionModel import PredictionModel, PredictModelStratifiedTesting

this_dir = os.path.abspath('.')
cfg_file = os.path.join(this_dir, 'experiment.yml')
cfg = get_yaml_full_load(cfg_file)    



df = pd.DataFrame(tdata)

pmst = PredictModelStratifiedTesting(cfg =  cfg,
                                   strat_features = ['gid'],
                                   n_splits = 4)



agg_score, raw_scores, results, jsons = pmst.test(df, results_full_df= True)

#results[-1].to_csv('../res.csv', sep = '|')
