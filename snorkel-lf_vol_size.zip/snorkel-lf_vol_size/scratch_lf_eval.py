# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""

import import_utils
from utils.json_utils import get_json, print_json_pretty
from classes.Candidate import Sentence
import os
from classes.PreProcessBuilder import PreProcessBuilder
from lf.LFBaseClasses import LFPreLabelled
from classes.LFEvalSuite import LFEvalSuite
from copy import deepcopy
from collections import Counter
from utils.yaml_utils import get_yaml_full_load
from settings import GOLD_TEST_DATA_DIR
from lf.quantity import lf_quantity_near_vol,lf_quantity_next_x, lf_quantity_prev_x, lf_quantity_end, lf_quantity_prev_year


label = 'quantity'


def get_bad_words(r):
    c = Counter([ri[0] for ri in r['mislabelled']])
    cc = sorted([(k,v) for k,v in c.items()], key = lambda c:-c[1])
    return cc


spacy_sentence = lambda ti : Sentence(text=ti['text'], labels = ti['labels'], labels_format = 'spacy')

lwj = get_json(os.path.join(GOLD_TEST_DATA_DIR, 'spacy_wine_name.json'))


sentences = list(map(spacy_sentence, lwj))

cfg_prepoc = get_yaml_full_load('./preproc_alt.yml')
p = PreProcessBuilder(cfg_prepoc)

lf_eval = LFEvalSuite(test_sentences = sentences,
                      pre_processor  = p)



lf = lf_quantity_prev_year


res = lf_eval(lf, label)
print(res['accuracy'])


'''
pls = ['spectrum', 'brentwood']

out_res = list()

for pli in pls:
    
    lf = LFPreLabelled(pli)
    res = lf_eval(lf, 'alcohol')
    print('-----------')
    print(pli)
    print(res['accuracy'])
    bw = get_bad_words(res)
    for bwi in bw[:20]:
        print(bwi)
    out_res.append(res)


def between_alcohol(token):
    if 'alcohol' in getattr(token.left, 'pre_labels', {}):
        if 'alcohol' in getattr(token.right, 'pre_labels', {}):
            if not token.isnumeric():
                if 'alcohol' not in token.pre_labels:
                    return 1

    return -1


res = lf_eval(target = 'alcohol',
              lf = between_alcohol)


print(res['accuracy'])
'''
