import os
import json
import pandas as pd
import logging
import pprint as pp
import pudb
import import_utils
import json

from labeler import Labeler
from LFAnalysis import LFTester
from classes import Candidate, Sentence

from itertools import groupby

from utils.json_utils import get_json, print_json_pretty
from build_preprocessor import pre_processor, pps, make_ws_preprocessor

from pathlib import Path
from load_grid import load_files_grid, load_lf_grid
from print_results import print_extracted
from toolz import compose
from snorkel.labeling import labeling_function
import warnings

warnings.simplefilter("ignore")

logger = logging.getLogger(__name__)


def base_lf(candidate):
    if candidate.label == 'alcohol':
        return 1
    return -1


if __name__ == '__main__':

    files_grid = load_files_grid('files_grid.json')
    lf_grid = load_lf_grid('lf_grid.json')
    base_save_path = Path('metrics')

    for path in files_grid:
        if "name" in str(path):
            print('Processing: {}'.format(path))
            save_dir_name = os.path.basename(path).split('.')[0]
            save_dir = base_save_path/save_dir_name

            # IO
            with open(path) as f:
                gold_samples = json.load(f)

            unseen_data = [{'text': t['text'], 'labels': []} for t in gold_samples]
            some_alcohol = [t['text'] for t in unseen_data]

            # Preprocessing
            ws_base_path = 'ws_data/wine' if "wine" in str(path) else 'ws_data/whiskey'
            all_preprocessors = make_ws_preprocessor(ws_base_path)
            pps.extend(all_preprocessors)
            pre_processor = compose(*pps)

            n = range(len(some_alcohol))
            make_ppt = lambda ti : Sentence(ti[0], ti[1])
            init_ppt = list(map(make_ppt,  zip(some_alcohol, n)))

            res = list(map(pre_processor, init_ppt))
            candidates = [u for s in res for u in s.split()]
            candidates = [u for s in res for u in s.split() if u.pre_labels != {'STOPWORD'}]

            if not os.path.exists(save_dir):
                os.mkdir(save_dir)

            # Setup
            all_metrics = {}
            for label, lfs  in lf_grid.items():

                if label == "alcohol":
                    for pp in all_preprocessors:
                        lfs.append(labeling_function(name=pp.name)(base_lf))

                if len(lfs) > 0:
                    print('Label: {}'.format(label))
                    #candidates = candidates[:len(res[0].split())]
                    #gold_samples = gold_samples[:1]
                    labeler = Labeler(label, binarize=False)
                    candidates = labeler.annotate(candidates[:], lfs)
                    sentences = labeler.annotate_sentences(res, candidates)

                tester = LFTester(label)
                metrics = tester.score(gold_samples, sentences, as_df=False)
                for k, v in metrics[label].items():
                    metrics[label][k] = float(v)
                all_metrics[label] = metrics

            typ = 'wine' if 'wine' in str(path) else 'whiskey'
            result = []
            for sent in sentences:
                dct = sent.to_json()
                dct.pop('text_id')
                result.append(dct)

            print_json_pretty(result, 'annotated_name_{}.json'.format(typ))
            print_json_pretty(all_metrics, 'metrics_{}.json'.format(typ))
