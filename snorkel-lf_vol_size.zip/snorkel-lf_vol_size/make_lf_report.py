import pandas as pd
import os
import json
import pudb

from pathlib import Path


SCORES = [
    'precision', 
    'accuracy', 
    'f1', 
    'support', 
    'coverage'
]


def make_report(path, output_path='metrics_ls.xlsx'):
    """ Gather results from path and generate a nice looking report
    """
    path = Path(path)

    subfolders = [path/d for d in os.listdir(path) if os.path.isdir(str(path/d))]
    
    results = {}
    for folder in subfolders:
        files = [folder/f for f in os.listdir(folder) if f.endswith('.json')]
        for fil in files:
            print(fil)
            #if 'year' in str(fil):
            #    pudb.set_trace()
            with open(fil) as f:
                data = json.load(f)
            df = pd.DataFrame(data)
            if len(df.values):
                df = df.loc[SCORES, :].T
                label = os.path.basename(fil).split('.')[0]
                fil_name = str(os.path.basename(folder))
                index = pd.MultiIndex.from_tuples([(label, f) for f in df.index])
                columns = pd.MultiIndex.from_tuples([(fil_name, f) for f in df.columns])
                df.index = index
                df.columns = columns
                if not fil_name in results.keys():
                    results[fil_name] = [df]
                else:
                    results[fil_name].append(df)
    return results


def write_report(results, output_path):
    """ Given report as dfs, write it to excel file
    """

    with pd.ExcelWriter(output_path) as writer:
        for f, values in results.items():
            df = pd.concat(values)
            df = df.applymap(lambda x: round(x, 3))
            df.to_excel(writer, sheet_name=f)


if __name__ == '__main__':
    import sys 
    if len(sys.argv) == 3:
        base_path = sys.argv[1]
        save_name = sys.argv[2]
    else:
        base_path = 'metrics'
        save_name = 'metrics_lf.xlsx'

    results = make_report(base_path)
    write_report(results, save_name)
