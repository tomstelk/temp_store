import pandas as pd
import json
import ngrams
import os
import nltk
import pudb

from pathlib import Path
from nltk.corpus import stopwords, words as english_words

STEMMER = nltk.PorterStemmer()

def stem(word):
    """ Stemming
    """
    return STEMMER.stem(word)

def remove_stopwords(texts, bad_words, len_thresh=3):
    texts_ = [
        ' '.join(u for u in text.split() if u not in bad_words and len(u) > len_thresh) 
        for text in texts
    ]
    if ' ' in texts:
        texts.remove(' ')
    return texts_


def clean_voc(texts, bad_words, len_thresh=3, top=-1):
    """ Remove stopwords and create vocabulary list
    """
    texts_ = remove_stopwords(texts, bad_words)
    voc = ngrams.vocabulary(texts_, top=top)
    return voc


def clean_ngrams(texts, bad_words, n=2, len_thresh=3, top=-1):
    """ Generate clean ngrams from value, removing from bad_words
    """
    texts_ = remove_stopwords(texts, bad_words, len_thresh=len_thresh)
    bigrams = [
        ' '.join(ngram) for text in texts_
        for ngram in ngrams.ngrams(text, n=n)
    ]
    voc = ngrams.vocabulary(bigrams, top=top)
    return voc


def generate_ws_feature_file(texts, output_path):
    """ Write features to file
    """
    with open(output_path, 'w') as f:
        f.writelines([u+os.linesep for u in texts])


WORDS = set(english_words.words())
STOPWORDS = set(stopwords.words('english'))
ALL_BAD_WORDS = WORDS.union(STOPWORDS)
STEMED_BAD_WORDS = set(stem(u) for u in ALL_BAD_WORDS)

if __name__ == '__main__':
    with open('ws_extracted.json') as f:
        df = pd.DataFrame(json.load(f))

    base_save_dir = Path('ws_data/wine')
    if not os.path.exists(base_save_dir):
        os.makedirs(base_save_dir)
    typ = 'wine'

    all_producer = [u for u in df[df.type.isin([typ])]['producer'].dropna().values]
    producer_tokens = clean_voc(all_producer, ALL_BAD_WORDS)
    generate_ws_feature_file(producer_tokens, base_save_dir/'producer_tokens.txt')

    all_regions = [u for u in df[df.type.isin([typ])]['region'].dropna().values]
    region_tokens = clean_voc(all_producer, ALL_BAD_WORDS)
    generate_ws_feature_file(region_tokens, base_save_dir/'region_tokens.txt')

    editions = df[df.type.isin([typ])]['edition'].dropna().values.tolist()
    editions_ngrams = clean_ngrams(editions, ALL_BAD_WORDS)
    generate_ws_feature_file(editions_ngrams, base_save_dir/'editions_ngrams.txt')
    editions_tokens = clean_voc(editions, ALL_BAD_WORDS)
    generate_ws_feature_file(editions_ngrams, base_save_dir/'editions_tokens.txt')
    trigrams = clean_ngrams(editions, ALL_BAD_WORDS, n=3)
    generate_ws_feature_file(trigrams, base_save_dir/'editions_3grams.txt')
    fourgrams = clean_ngrams(editions, ALL_BAD_WORDS, n=4)
    generate_ws_feature_file(fourgrams, base_save_dir/'editions_4grams.txt')

    types = df[df.type.isin([typ])]['producer'].dropna().values.tolist()
    types_tokens = clean_voc(types, ALL_BAD_WORDS)
    generate_ws_feature_file(types_tokens, base_save_dir/'types_tokens.txt')

    all_alctitle = set(df[df.type.isin([typ])]['edition'].dropna().values.tolist())
    generate_ws_feature_file(all_alctitle, base_save_dir/'all_editions.txt')

    low_freq = clean_voc(all_alctitle, ALL_BAD_WORDS)[::-1][:100]
    generate_ws_feature_file(low_freq, base_save_dir/'low_freq.txt')
