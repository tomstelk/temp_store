from functools import reduce
from itertools import groupby
from collections import OrderedDict


def ngrams(text, n=2):
    tokens = text.split()
    return list(zip(*[tokens[i:] for i in range(n)]))


def vocabulary(tokens, top=-1):
    mapped = map(lambda x: (x, 1), tokens)
    count = OrderedDict()
    for k, g in groupby(sorted(mapped, key=lambda x: x[0]), lambda x: x[0]):
        u = list(g)
        tmp = reduce(lambda x, y: (x[0], x[1]+y[1]), u, ('', 0))
        count[k] = tmp[1]
    count = sorted(count.items(), key=lambda x: x[1], reverse=True)
    return [u[0] for u in count]
