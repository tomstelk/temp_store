# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 15:30:58 2019

@author: user
"""


import sys
import os


this_dir=  os.path.dirname(os.path.realpath(__file__))

with open(os.path.join(this_dir, 'UTILS_DIR')) as f:
    UTILS_DATA_DIR=f.readline().strip()

sys.path.append(os.path.abspath(UTILS_DATA_DIR))