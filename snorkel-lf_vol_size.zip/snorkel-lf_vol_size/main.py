import os
import pudb
import yaml
import logging
import pandas as pd
import json

from classes import LearningFunctionBuilder, PreProcessBuilder, Labeler, Grid, LFTester

logger = logging.getLogger(__name__)


with open('preproc.yml', 'r') as f:
    conf_prec = yaml.safe_load(f)

with open('lfs.yml', 'r') as f:
    conf_lf = yaml.safe_load(f)

with open('files_grid.yml', 'r') as f:
    conf_files = yaml.safe_load(f)

lfs = LearningFunctionBuilder(conf_lf)

grid = Grid(conf_files)
eval_corpus = grid.eval_set[1]
train_corpus = grid.train_set[2]

prec = PreProcessBuilder(conf_prec)
train_corpus = prec.preprocess(train_corpus)

label_sequence = [
    'abv', 
    'quantity',
    'year_bottled',
    'year_harvested', 
    'year_distilled',
    'year', 
    'age', 
    'vol_size', 
    'box',
    'alcohol'
]
all_scores = {}
lfs_scores = {}

for label in label_sequence:
    print('Processing label: {}'.format(label))
    labeler = Labeler(label, lfs, binarize=False)
    train_corpus = labeler.annotate(train_corpus)
    
    tester = LFTester(label)
    #score = tester.score(eval_corpus, train_corpus)
    #lf_score = tester.evaluate(lfs.lfs, eval_corpus, train_corpus)

    #lfs_scores.update(lf_score)
    #all_scores.update(score)

#scores = pd.DataFrame(lfs_scores).T
#scores.to_csv('lf_scores_{}.csv'.format(train_corpus.type))
#all_scores = pd.DataFrame(all_scores).T
#all_scores.to_csv('scores_{}.csv'.format(train_corpus.type))

with open('result_{}.json'.format(train_corpus.type), 'w') as f:
    json.dump(train_corpus.to_json(), f)
