# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 16:04:41 2019

@author: user
"""


from TestLF import TestLF
import import_utils
import unittest
from lf.LFBaseClasses import LFTokenValue

class TestLFTokenValue(TestLF):

    def test_token_value_lf(self):
        
        test_lf = LFTokenValue(values= ['hello', 'a'])
        
        s = 'hello I am a good boy, hello again'
        
        
        test_result = list(map(test_lf, s.split()))
        compare_result = [1, -1, -1, 1, -1, -1, 1, -1]
        
        
        self.assertEqual (test_result, 
                          compare_result)



if __name__ == '__main__':
    unittest.main()