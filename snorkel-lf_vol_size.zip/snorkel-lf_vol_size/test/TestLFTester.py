# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 16:03:38 2019

@author: user
"""
from TestLF import TestLF
import import_utils
from utils.json_utils import get_json
import unittest
from static.static_utils import get_ullage
from collections import namedtuple
from classes.LFEvalSuite import LFEvalSuite


class TestLFTester(TestLF):

    
    def setUp(self):
        
        in_test_data = [ {
        "labels": [
            [
                40,
                41,
                "quantity"
            ],
            [
                0,
                4,
                "year"
            ],
            [
                5,
                39,
                "alcohol"
            ]
        ],
        "text": "1994 fonseca vintage port graham taylor 3 bottles"
    },
    {
        "labels": [
            [
                0,
                4,
                "year"
            ],
            [
                5,
                41,
                "alcohol"
            ],
            [
                42,
                44,
                "quantity"
            ],
            [
                56,
                62,
                "vol_size"
            ],
            [
                63,
                66,
                "box"
            ]
        ],
        "text": "2005 silval vintage porto quinta do noval 12 bottles of 0.75 l owc"
    }
    ]
        
    
        self.lf_evaluate = LFEvalSuite(test_data = in_test_data)
    
    
    def test_year_test_lf(self):
        
        def year_lf(token):
            if len(token)==4 and token.isnumeric():
                return 1
            else:
                return -1
            
        expected_result = {
                            'accuracy':
                                {
                                    'p' : 1,
                                    'r' : 1,
                                    'f' : 1,
                                    's': 2
                                },
                            'mislabelled' : [],
                            'missed' : []
                            }
                                
        result = self.lf_evaluate(lf = year_lf,
                                  target = 'year')
        
        self.assertDictEqual(expected_result, 
                             result)



if __name__ == '__main__':
    unittest.main()