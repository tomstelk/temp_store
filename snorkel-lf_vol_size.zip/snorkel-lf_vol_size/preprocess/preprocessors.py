# -*- coding: utf-8 -*-
import re
import logging

from classes.Candidate import Sentence
from abc import ABC, abstractmethod
from importlib import import_module

logger = logging.getLogger(__name__)


class PreProcessor(ABC):

    def __init__(self, pre_label):
        
        if type(pre_label)==str:
            self.pre_label = [pre_label]
        else:
            self.pre_label = pre_label
        
    @abstractmethod
    def to_json(self):
        pass
    
    @abstractmethod
    def from_json(self):
        pass
    
    def __call__(self, sentence):
        
        spans = list(self._process(sentence))
        if spans:
            sentence.add_pre_label(pre_label=self.pre_label, 
                                    spans=spans)
        return sentence
        
    @abstractmethod
    def _process(self, X):
        """ Returns iterator of spans to be pre_labelled
        """
        pass


def handle_ws(in_reg_pattern):
    return '^{0}$|^{0}(\s)|(\s){0}(\s)|(\s){0}$'.format(in_reg_pattern)


class KeywordMatchPreProcessor(PreProcessor):

    def __init__(self, 
                 pre_label,
                 match_texts):
        
        self.match_texts = sorted(match_texts, key = lambda x:-len(x))
        super().__init__(pre_label)
        
    def to_json(self):
        return {'pre_label' : self.pre_label,
                'match_texts' : self.match_texts}
        
    @classmethod
    def from_json(cls, j):
        return cls(**j)
    
    def _check_ws(self, match):
        s0, s1 = match.span()
        
        if match[0][0].isspace():
            s0+=1
        
        if match[0][-1].isspace():
            s1-=1
        
        return (s0, s1)
        
    def _find_matches(self, subtext, text):
        reg  =  re.compile(handle_ws(subtext))
        yield from map(self._check_ws, re.finditer(reg, text))
        
    def __check_no_overlap(self, s1, s2):
        if s2[0] > s1[1] or s1[0] > s2[1]:
            return True
        else:
            return False
        
    def _check_no_overlap(self, all_spans, new_span):
        return all(self.__check_no_overlap(ai, new_span) for ai in all_spans)
    
    def _check_spans(self, all_spans, new_spans):
        
        good_spans = list()
        for ni in new_spans:
            if self._check_no_overlap(all_spans, ni):
                good_spans.append(ni)
                all_spans.append(ni)
                    
        return all_spans, good_spans
        
    def _process(self, text):
        
        all_spans = []
        out_spans = []
        for mi in self.match_texts:
            if mi in text:
                new_spans = list(self._find_matches(mi, text))
                all_spans, good_spans = self._check_spans(all_spans, new_spans)                
                out_spans += good_spans
        return out_spans        



class KeywordMatchCallableInitPreProcessor(KeywordMatchPreProcessor):
    
    def __init__(self, 
                 pre_label,
                 get_text_callable,
                 get_text_module):
        
        c = getattr(import_module(get_text_module), get_text_callable)
        match_texts = c()
        
        return super().__init__(match_texts=match_texts,
                                pre_label=pre_label)


class RegexMatchPreProcessor(KeywordMatchPreProcessor):

    def __init__(self, regex, pre_label):
        self.regex = regex
        PreProcessor.__init__(self, pre_label = pre_label)
    
    def to_json(self):
        return {'pre_label' : self.pre_label,
                'regex' : self.regex}
        
    @classmethod
    def from_json(cls, j):
        return cls(**j)
            
    def _process(self, text):
        
        all_spans = []

        new_spans = list(self._find_matches(self.regex, text))
        all_spans, good_spans = self._check_spans(all_spans, new_spans)                
        return good_spans


class RegexMatchCallableInitPreProcessor(RegexMatchPreProcessor):
    
    def __init__(self, 
                 pre_label,
                 regex_variable,
                 regex_module):
        
        regex = getattr(import_module(regex_module), regex_variable)       
        
        return super().__init__(regex=regex,
                                pre_label=pre_label)

'''
    def _check_ws(self, match):
        s0, s1 = match.span()
        
        if match[0][0].isspace():
            s0+=1
        
        if match[0][-1].isspace():
            s1-=1
        
        return (s0, s1)
        
    def _find_matches(self, subtext, text):
        reg  =  re.compile(handle_ws(subtext))
        yield from map(self._check_ws, re.finditer(reg, text))
        
    def __check_no_overlap(self, s1, s2):
        if s2[0] > s1[1] or s1[0] > s2[1]:
            return True
        else:
            return False
        
    def _check_no_overlap(self, all_spans, new_span):
        return all(self.__check_no_overlap(ai, new_span) for ai in all_spans)
    
    def _check_spans(self, all_spans, new_spans):
        
        good_spans = list()
        for ni in new_spans:
            if self._check_no_overlap(all_spans, ni):
                good_spans.append(ni)
                all_spans.append(ni)
                    
        return all_spans, good_spans
'''