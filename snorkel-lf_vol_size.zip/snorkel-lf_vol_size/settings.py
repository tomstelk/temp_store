# -*- coding: utf-8 -*-
import os

THIS_DIR =  os.path.dirname(os.path.realpath(__file__))
DATA_DIR = os.path.join(THIS_DIR, 'data')
PARENT_DIR = os.path.abspath(os.path.join(THIS_DIR, '..'))
GRANDPARENT_DIR = os.path.abspath(os.path.join(PARENT_DIR, '..'))

STATIC_DIR = os.path.join(THIS_DIR, 'static')

PREPROCESSORS_MODULE = 'preprocess.preprocessors'
STATIC_UTILS_MODULE = 'static.static_utils'

ALCTION_FILE = os.path.join(DATA_DIR, 'alctions_20191127.json')
LABELLED_TEST_DATA_DIR = os.path.join(DATA_DIR, 'ner_testing_data')
WS_JSON = os.path.join(DATA_DIR, 'wine_searcher.json')
GOLD_TEST_DATA_DIR = os.path.join(PARENT_DIR, 'labelled_test_data')