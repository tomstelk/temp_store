# -*- coding: utf-8 -*-
import logging

from importlib import import_module
from jinja2 import Environment, PackageLoader, select_autoescape

env = Environment(
    loader=PackageLoader('classes', 'static'),
    autoescape=select_autoescape(['html'])
)

logger = logging.getLogger(__name__)


class LFWrapper:
    """ Keeping track of names for snorkel
    """

    def __init__(self, lf, name):
        self.lf = lf
        self.name = name

    def __call__(self, *args, **kwargs):
        return self.lf(*args, **kwargs)


class LearningFunctionBuilder():
    
    def __init__(self, cfg):
        self.cfg = cfg
        self.lfs = {ti: self._build_lfs(cfg['labels'], ti) for ti in cfg['types']}
        
    def _check_type_valid(self, cfg, _type):
        if 'types' in cfg and _type not in cfg['types']:
            return False
        else:
            return True

    def description(self):
        """ Generate reports with all docstrings from LFs
        """
        template = env.get_template('lfs.html')
        sections = [{'href': k, 'description': k.title()} for k in self.lfs.keys()]
        headers = [
            {
                'name': k,
                'description': k.title(),
                'labels': [
                    {
                        'name': kk,
                        'lfs': [
                            {
                                'name': lf.name,
                                'description': lf.lf.__doc__
                            }
                            for lf in vv
                        ]
                    }
                    for kk, vv in v.items()
                ]
            }
            for k, v in self.lfs.items()
        ]
        rendered = template.render(sections=sections, headers=headers)
        return rendered
        
    def _build_lfs(self, cfg, _type):
        out = dict()
        for li, cfgi in cfg.items():
            
            if not self._check_type_valid(cfgi, _type):
                continue
            
            if 'module' in cfgi:
                m = import_module(cfgi['module'])
            else:
                m = None
                
            out[li] = [self._build_lf(fi, m) 
                    for fi in cfgi['functions'] if self._check_type_valid(fi, _type)]
        return out
    
    def _build_lf(self, fcfg, m):
        
        if 'module' in fcfg:
            m = import_module(fcfg['module'])
            
        func = getattr(m, fcfg['name'])
        lf = LFWrapper(func, fcfg['name'])
        return lf

    def to_json(self):
        return self.cfg
    
    @classmethod
    def from_json(cls, j):
        return cls(j)
