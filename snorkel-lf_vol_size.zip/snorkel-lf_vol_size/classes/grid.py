import os
import logging
import pudb
import json

from enum import Enum
from collections import namedtuple
from . import Candidate, Sentence

logger = logging.getLogger(__name__)


class Mode(Enum):
    TRAIN = 1
    EVAl = 2


class Corpus(object):
    """ Holds sentences
    """

    def __init__(self, sentences, typ):
        self.sentences = sentences
        self.candidates = [c for s in sentences for c in s.candidates]
        self.score = {}
        self.stats_ = {}
        self.mode_ = Mode.TRAIN
        self.type = typ
        self._n = 0

    @property
    def stats(self):
        return self.stats_

    @stats.setter
    def stats(self, stats):
        self.stats_ = stats

    def to_json(self):
        return [b.to_json() for b in self.sentences]

    #def __iter__(self):
    #    return self

    #def __next__(self):
    #    if self._n < len(self.sentences):
    #        self._n += 1
    #        return self.sentences[self._n]
    #    else:
    #        raise StopIteration


class Grid(object):
    """ Creating iterator to hide preprocessing/formatting away
    """

    def __init__(self, cfg):
        self.cfg = cfg
        self.types = cfg.get('types', ['wine', 'whiskey'])
        self.mode = 'train'
        self.paths = self._load_cfg(cfg)
        self.sets = {k: [self._make_set(dct['path'], typ=dct['type'], mode=k) for dct in v] for k, v in self.paths.items()}

    def _load_cfg(self, cfg):
        """ Populate state from cfg
        """
        base_dir = cfg['data_dir']
        test_paths = [{'type': d['type'], 'path': os.path.join(base_dir, d['module'], d['fname'])} for d in cfg['test']]
        train_paths = [{'type': d['type'], 'path': os.path.join(base_dir, d['module'], d['fname'])} for d in cfg['train']]
        paths = {'test': test_paths, 'train': train_paths}
        return paths
    
    @staticmethod
    def _read(fname):
        """ Reads a file and generate tokens
        """
        with open(fname, 'r') as f:
            data = json.load(f)
        
        texts = [t['text'] for t in data]
        labels = [t['labels'] for t in data]
        pre_labels = [] if 'pre_labels' not in data[0].keys() else [t['pre_labels'] for t in data]
        return texts, labels, pre_labels

    def _make_sentences(self, texts, labels=None, pre_labels=None, labels_format='dict', mode='train'):
        n = len(texts)
        
        if not labels or mode == 'train':
            labels = [None]*n

        if not pre_labels or mode == 'train':
            pre_labels = [None]*n

        sentences = (
            Sentence(text, ix, labels=label, pre_labels=pre, labels_format=labels_format)
            for text, ix, label, pre in zip(texts, range(n), labels, pre_labels)
        )
        return sentences

    def _make_set(self, fname, typ, filt=None, mode='train'):
        texts, labels, pre_labels = self._read(fname)
        label_format = 'dict' if isinstance(labels[0], dict) else 'spacy'

        sentences = self._make_sentences(texts, 
            labels=labels, 
            pre_labels=pre_labels, 
            labels_format=label_format,
            mode=mode
        )

        set_ = Corpus(list(sentences), typ)
        return set_

    @property
    def eval_set(self):
        return self.sets['test']

    @property
    def train_set(self):
        return self.sets['train']
