# -*- coding: utf-8 -*-
import re
import import_utils

from utils.text_utils import zipngram
from itertools import chain


class Candidate(str):
    
    def __new__(self, 
                token,
                span,
                text_id,
                pos,
                token_id=None,
                left=None, 
                right=None,
                pre_labels=None,
                label=None,
                weight=None):
        return super().__new__(self, token)
    
    def __init__(self, 
                 token,
                 span,
                 text_id,
                 pos,
                 token_id=None,
                 left=None,
                 right=None,
                 pre_labels=None,
                 label=None,
                 weight=None):
        
        #Can have multiple pre-labels
        if not pre_labels:
            self.pre_labels = set()
        else:
            if type(pre_labels)==str:
                self.pre_labels = {pre_labels}
            elif hasattr(pre_labels, '__iter__'):
                self.pre_labels = set(pre_labels)
            else:
                self.pre_labels = {pre_labels}
                
        self.label = label
        self.span = span
        self.pos = pos
        self._text_id = text_id
        self._token_id = token_id
        self._left = left
        self._right = right
        self.weight = weight
        
    def _yield_tokens(self, 
                      _dir, 
                      n = None, 
                      inc_self = False):
        
        if inc_self:
            yield self
        
        _next = getattr(self, _dir)
        check_count = lambda i : i<=n if n is not None else True
        
        i = 1
        
        while _next and check_count(i):
            yield _next
            _next = getattr(_next, _dir)
            i+=1

    def _yield_left(self, n = None):
        yield from self._yield_tokens(_dir = '_left',
                                      n = n)
    
    def _yield_right(self, n = None):
        yield from self._yield_tokens(_dir = '_right',
                                      n = n)

    def ngrams(self, n, m):
        
        if m<0:
            _dir = '_left'
            _parse_tokens = lambda t : list(reversed(list(t)))
        else:
            _dir = '_right'
            _parse_tokens = lambda t : list(t)
            
        num_tokens = n + abs(m) - 2
        
        tokens = _parse_tokens(self._yield_tokens(_dir = _dir, 
                                                  n = num_tokens,
                                                  inc_self=True))
        return list(zipngram(tokens, n))
    
    @property
    def sentence(self):
        left = reversed(list(self._yield_left()))
        right = self._yield_right()
        
        out = chain(left, [self], right)
        
        return list(out)
    
    @property
    def text_id(self):
        return self._text_id
    
    @property
    def token_id(self):
        return self._token_id
    
    @property
    def left(self):
        return self._left
    
    @property
    def right(self):
        return self._right
        
    def set_left(self, left):
        self._left = left
    
    def set_right(self, right):
        self._right = right
        
    def to_json(self):
        return {'token': str(self),
                'span' : list(self.span),
                'text_id' : self._text_id,
                'label': self.label,
                'pre_labels': list(self.pre_labels),
                'left' : str(self._left) if self._left else None,
                'right' : str(self._right) if self._right else None,
                }
   
    
def add_good_spans_to_index(index_dict, label, span):
        
    good_i = [i for i in index_dict.keys() if span[0] <= i < span[1]]
        
    for i in good_i:
        if type(index_dict[i])==set:
            index_dict[i].add(label)
        else:
            index_dict[i] = label
        
    return index_dict
    
    
def add_label_and_index(label_dict,
                        index_dict, 
                        label,
                        spans):
    
    set_label_spans = set(map(tuple, spans))
    label_dict[label] = label_dict.get(label, set()).union(set_label_spans)
    
    for span in spans:
        add_good_spans_to_index(index_dict=index_dict, 
                                label=label, 
                                span=span)
            
    return label_dict, index_dict
    

def label_dict_into_index(label_dict,
                          index_dict):
    for label, spans in label_dict.items():
        for si in spans:
            add_good_spans_to_index(index_dict=index_dict,
                                    label = label,
                                    span = si)
                
    return index_dict

    
class Sentence(str):
    """ Holds text, id, pre_labels and labels
    pre_labels and labels are indexed by position of first character of token
    Split generates labelled tokens
    """

    def __new__(self, 
                text,
                text_id=None,
                labels=None,
                labels_format='dict',
                pre_labels=None,
                weights=None):
        
        return super().__new__(self, text)
        
    def __init__(self, 
                 text,
                 text_id=None,
                 labels=None,
                 labels_format='dict',
                 pre_labels=None,
                 pre_labels_format='dict',
                 weights=[]):
        
        self._text_id = text_id
        self._tokens  = list(self._tokenize(text))
        self._pre_label_index = {ti.span()[0]: set() for ti in self._tokens}
        self._label_index = {ti.span()[0]: None for ti in self._tokens}
        self._labels = {}
        self._pre_labels = {}
        self.weights = weights
        
        if pre_labels:
            self._pre_labels = self._parse_labels(pre_labels, pre_labels_format) #{l : set(map(tuple, s)) for l, s in pre_labels.items()}
            label_dict_into_index(label_dict = self._pre_labels,
                                  index_dict = self._pre_label_index)
            
            '''
            for pre_label, spans in self._pre_labels.items():
                for si in spans:
                    add_good_spans_to_index(index_dict=self._pre_label_index,
                                            label = pre_label,
                                            span = si)
            '''
            
        if labels:
            self._labels = self._parse_labels(labels, labels_format)
            label_dict_into_index(label_dict = self._labels,
                                  index_dict = self._label_index)
            '''
            for label, spans in self._labels.items():
                for si in spans:
                    add_good_spans_to_index(index_dict=self._label_index,
                                            label = label,
                                            span = si)
            '''

    @property
    def candidates(self):
        return self.split()
        
    def _parse_labels(self, labels, labels_format):
        if labels_format == 'dict':
            return {l : set(map(tuple, s)) for l, s in labels.items()}
        
        elif labels_format == 'spacy':
            out = dict()
            for li in labels:
                l = li[2]
                s = (li[0], li[1])
                out[l] = out.get(l, set()).union({s})
                
            return out
            
        else:
            raise Exception ('Dont recognise labels format')
    
    @property
    def text_id(self):
        return self._text_id
    
    def _tokenize(self, text):
        return re.finditer('[^\s]+', text)

    @classmethod
    def from_json(cls, ppt):
        return cls(**ppt)

    def to_json(self):
        return {
                'text' : self,
                'text_id' : self._text_id,
                'pre_labels': {ki: list(map(list,vi)) for ki, vi in self._pre_labels.items()},
                'labels': {ki: list(map(list,vi)) for ki, vi in self._labels.items()},
                'weights': self.weights
               }
    
    def add_pre_label(self, pre_label, spans):
        if type(pre_label) == str:
            pre_label = [pre_label]
            
        for pl in pre_label:
            add_label_and_index(label_dict = self._pre_labels,
                                index_dict = self._pre_label_index,
                                label = pl,
                                spans = spans)

    def add_label(self, label, spans):
        
        add_label_and_index(label_dict = self._labels,
                                   index_dict = self._label_index,
                                   label = label,
                                   spans = spans)
    
    def _set_left_right(self, ppts):
        n = len(ppts)
        
        for i in range(1, n):
            ppts[i].set_left(ppts[i-1])
            ppts[i-1].set_right(ppts[i])
 
    def split(self):    
        
        ppts = list()
        for i, ti in enumerate(self._tokens):
            ppt =  Candidate(
                token = ti[0],
                pre_labels = self._pre_label_index[ti.span()[0]], 
                label = self._label_index[ti.span()[0]],
                span = ti.span(),
                token_id = i,
                pos = i,
                text_id = self._text_id
            )
            ppts.append(ppt)
            
        self._set_left_right(ppts)
        return ppts
