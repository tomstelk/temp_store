import os
import pudb
import pandas as pd
import logging
import import_utils

from snorkel.labeling import LFApplier
from snorkel.analysis import get_label_buckets
from .analysis import make_label_matrix, compute_score, from_spacy

logger = logging.getLogger(__name__)


class LFTester:
    """ Wrapper to evaluate lfs on gold datasets 

    Assume candidates are already preprocessed if needed by LF
    Assume gold is in spacy format
    """

    def __init__(self, target_label, save_df=False):
        self.target_label = target_label
        self.save_df = False

    def evaluate(self, lfs, eval_iterator, train_iterator, as_df=False):
        """ Take some lfs and compute metrics per LF on candidate set
        """
        results = {}
        gold = make_label_matrix(eval_iterator.sentences, filter_labels=[self.target_label])
        lfs_ = lfs[train_iterator.type].get(self.target_label, [])

        for lf in lfs_:
            logger.debug('Evaluating {}'.format(lf.name))
            labeler = LFApplier([lf])
            l_train = labeler.apply(train_iterator.candidates, progress_bar=False).reshape(-1)

            if l_train.max() < 0:
                logger.info("LF didn't produce predictions")
                results[lf.name] = {}

            else: 
                metrics = compute_score(gold, preds=l_train)
                results[lf.name] = metrics

        if as_df:
            return pd.DataFrame(results).T

        return results

    def score(self, eval_iterator, train_iterator):
        """ Just score candidates against gold_samples
        """
        results = {}
        gold = make_label_matrix(eval_iterator.sentences, filter_labels=[self.target_label])
        preds = make_label_matrix(train_iterator.sentences, filter_labels=[self.target_label])

        metrics = compute_score(gold, preds=preds)
        results[self.target_label] = metrics

        return results
