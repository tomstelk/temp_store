import logging
import os
import json
import numpy as np
import pandas as pd
import sklearn.metrics as skmetrics
import pudb

from functools import partial
from itertools import groupby
from sklearn import preprocessing
from collections import OrderedDict

from classes.Candidate import Candidate, Sentence
from snorkel.analysis import Scorer, get_label_buckets, metric_score
from snorkel.analysis.metrics import Metric

logger = logging.getLogger(__name__)


def to_spacy(samples):
    """ Format annotated sentences to spacy format
    """
    res = [
        {
            'text': s['text'],
            'ents': sorted([
                {"label": k, "start": start, "end": end} 
                    for k, v in s['labels'].items() for start, end in v
                    ], key=lambda x: x['start'])
        } for s in samples
    ]
    return res


def from_spacy(samples):
    """ Map spacy format to sentence json and create candidates
    """ 
    sentences = []
    for i, sample in enumerate(samples):
        new_labels = {}
        for k, g in groupby(sorted(sample['labels'], key=lambda x: x[2]), lambda x: x[2]):
            new_labels[k] = [[s, e] for s, e, _ in list(g)]
        sentence = Sentence.from_json({
            'text': sample['text'],
            'text_id': i,
            'labels': new_labels
            })
        sentences.append(sentence)
    return sentences


def get_candidate_labels(sentences, filter_labels=None):
    """ Generate m[i, j] = label_j of candidate_i
    """
    candidates = []
    labels = []
    unique_labels = OrderedDict()
    c = 1
    for s in sentences:
        cands = s.split()
        for cand in cands:
            candidates.append(cand)
            label = cand.label
            if label and (filter_labels is None or label in filter_labels):
                if label not in unique_labels:
                    unique_labels[label] = c
                    labels.append(c)
                    c += 1
                else: 
                    labels.append(unique_labels[label])
            else:
                labels.append(0)
    return candidates, labels, unique_labels


def make_label_matrix(sentences, binarize=False, filter_labels=None, make_df=False):
    """ Make the label matrix from annotated sentences

    If df, return a df with added metadata
    """
    cands, labels, mapping = get_candidate_labels(sentences, filter_labels=filter_labels)

    if binarize:
        binarizer = preprocessing.LabelBinarizer()
        bined = binarizer.fit_transform(labels)
    else:
        bined = np.array(labels)
        
    if make_df:
        if len(bined.shape) > 1:
            columns = ['None'] + list(mapping.keys())
        else:
            columns = ['Labels']
        new_df = pd.DataFrame(bined, columns=columns)
        new_df = new_df.assign(candidate=cands)
        return new_df

    return bined


def averaged_f1_rp(golds, preds, probs, average='micro'):
    return skmetrics.precision_recall_fscore_support(golds, preds, average=average)


def get_coverage(gold, preds, probs):
    true = sum(gold == 1)
    inter = sum([c for i, c in enumerate(preds) if c == 1 and gold[i] == 1])
    if true:
        coverage = inter/true
        return coverage
    return 0


def compute_score(gold, preds=None, probs=None, average='micro'):
    """ Evaluate one lf on gold set
    """
    METRICS = ['precision', 'accuracy', 'f1']

    scorer = Scorer(METRICS, abstain_label=-1, custom_metric_funcs=None)
    metrics_dict = scorer.score(gold, preds=preds, probs=probs)
    support = sum(gold == 1)
    support_preds = sum(preds == 1)
    coverage = get_coverage(gold, preds, probs)

    fnr = fnr_score(gold, preds)
    for_rate = for_score(gold, preds)
    selectivity = selectivity_score(gold, preds)

    preds_ = preds.copy()
    preds_[preds_ == -1] = 0
    #pudb.set_trace()
    fnr_abstain = fnr_score(gold, preds_)
    for_rate_abstain = for_score(gold, preds_)
    selectivity_abstain = selectivity_score(gold, preds_)

    metrics_dict.update({'support': support})
    metrics_dict.update({'support_preds': support_preds})
    metrics_dict.update({'coverage': coverage})
    metrics_dict.update({'FNR': fnr})
    metrics_dict.update({'FOR': for_rate})
    metrics_dict.update({'selectivity': selectivity})
    metrics_dict.update({'FNR_abstain': fnr_abstain})
    metrics_dict.update({'FOR_abstain': for_rate_abstain})
    metrics_dict.update({'selectivity_abstain': selectivity_abstain})

    return metrics_dict


def fnr_score(gold, preds):
    """ Compute FNR based on snorkel prediction
    """
    buckets = get_tp_fp(gold, preds)
    fn_ix = buckets.get('fn')
    fn = len(fn_ix)
    pos = sum(gold == 1)
    if pos == 0:
        return 0
    return fn/pos


def for_score(gold, preds):
    """ Compute FNR based on snorkel prediction
    """
    buckets = get_tp_fp(gold, preds)
    fn_ix = buckets.get('fn')
    fn = len(fn_ix)
    pred_neg  = sum(preds  == 0)
    if pred_neg == 0:
        return 0
    return fn/pred_neg


def selectivity_score(gold, preds):
    """ Selectivity
    """
    buckets = get_tp_fp(gold, preds)
    fn_ix = buckets.get('tn')
    fn = len(fn_ix)
    pred_neg  = sum(gold == 0)
    if pred_neg == 0:
        return 0
    return fn/pred_neg


def get_tp_fp(gold, preds):
    """ From buckets, get true pos, true neg ...
    """
    assert gold.max() <= 1, 'Implemented for binary labels'
    buckets = get_label_buckets(gold, preds)

    result = {
        'tp': buckets.get((1, 1), []),
        'fp': buckets.get((0, 1), []),
        'fn': buckets.get((1, 0), []),
        'tn': buckets.get((0, 0), [])
    }

    return result


if __name__ == '__main__':
    # Some one of testing

    with open('../data/spacy_whiskey_description.json') as f:
        gold_samples = json.load(f)

    with open('../spacy_whiskey_preprocessed.json') as f:
        pred_samples = json.load(f)

    gold_sentences = from_spacy(gold_samples)
    pred_sentences = [Sentence.from_json(p) for p in pred_samples]
    
    target_label = 'ullage'

    gold = make_label_matrix(gold_sentences, binarize=False, 
            filter_labels=[target_label], make_df=False)

    preds = make_label_matrix(pred_sentences, binarize=False, 
            filter_labels=[target_label], make_df=False)

    metrics = compute_score(gold, preds=preds)
    print(metrics)

    # Get indices of TP, FP ...
    classes = get_tp_fp(gold, preds)
