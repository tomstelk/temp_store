import logging
import numpy as np

from snorkel.labeling import LabelModel, LFApplier, MajorityLabelVoter, LabelingFunction, labeling_function

from classes import Candidate
from itertools import groupby

import pudb

logger = logging.getLogger(__name__)


class Labeler(object):

    def __init__(self, label, lfs, use_label_model=True, cardinality=2, 
            binarize=True, threshold=.55, progress_bar=True):
        self.label = label
        self.lfs = lfs
        self.progress_bar = progress_bar
        self.threshold = threshold
        self.cardinality = cardinality
        self.use_label_model = use_label_model
        self.binarize = binarize
    
    def _annotate_candidates(self, corpus, lfs, **kwargs):
        """ Given lfs and candidates add and reconciliate labels

        Add label to candidate
        """

        candidates = corpus.candidates
        applier = LFApplier(lfs)
        L_train = applier.apply(candidates, progress_bar=self.progress_bar)

        if len(lfs) >= 3:
            label_model = LabelModel(cardinality=self.cardinality, verbose=True)
        else:
            label_model = MajorityLabelVoter(cardinality=self.cardinality, verbose=True)

        self.label_model = label_model
        label_model.fit(L_train=L_train, **kwargs)
        y_probs = label_model.predict_proba(L_train)

        if self.binarize:
            labels = 1*(y_probs > self.threshold)
        else:
            labels = np.array(y_probs, copy=True)
            labels[(y_probs < self.threshold)[:, 1], 1] = 0

        labels = labels[:, 1]
        for i in range(len(candidates)):
            # Tag annotated candidates
            candidates[i].label_ = labels[i]
            if labels[i] == 1:
                candidates[i].label = self.label
            if not self.binarize and labels[i] > self.threshold:
                candidates[i].weight = labels[i]
                candidates[i].label = self.label
            elif not self.binarize and labels[i] <= self.threshold:
                candidates[i].weight = 0

        return candidates

    def _wrap_lfs(self, lfs):
        """ Decorate lfs as LabelingFunction
        """
        new_lfs = []
        for lf in lfs:
            if isinstance(lf, LabelingFunction):
                new_lfs.append(lf)
            else:
                new = labeling_function(name=lf.name)(lf)
                new_lfs.append(new)

        return new_lfs

    def annotate(self, corpus, **kwargs):
        """ From annotated candidates updates sentences for final results
        """
        sentences = corpus.sentences
        typ = corpus.type
        print(self.label)
        lfs = self.lfs.lfs[typ].get(self.label, [])
        lfs = self._wrap_lfs(lfs)
        
        if not lfs:
            return corpus

        candidates = self._annotate_candidates(corpus, lfs, **kwargs)

        for sentence_id, groups in groupby(candidates, lambda x: x.text_id):
            cands = list(groups)
            filtered = filter(lambda x: x.label_ == 1 or x.label_ > self.threshold, cands)
            labeled = [(c.span[0], c.span[1], self.label, c) for c in filtered]
            if labeled:
                sent = sentences[sentence_id]
                sent.weights = self._make_weights(sent, labeled, cands)
                labeled = self.reconciliate(labeled)
                spans = [(start, end) for start, end, _ in labeled]
                sent.add_label(self.label, spans)

        return corpus

    def _make_weights(self, sent, labeled, cands):
        if sent.weights:
            weights = sent.weights
        else:
            weights = [0]*len(cands)

        for i, cc in enumerate(cands):
            for j, (_, _, _, c) in enumerate(labeled):
                if cc is c:
                    weights[i] = c.weight

        return weights

    @staticmethod
    def reconciliate(labels):
        """ Reconciliate adjacent annotations
        """
        if len(labels) == 1:
            return [(l, r, label) for l, r, label, _ in labels]

        new_labels = []
        n = len(labels)
        left, right, label, _ = labels[0]
        for i in range(1, n):
            l, r, _, _ = labels[i]
            if l == right + 1:
                right = r
            else:
                new_labels.append((left, right, label))
                left = l
                right = r
        new_labels.append((left, right, label))
        return new_labels
