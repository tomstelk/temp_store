# -*- coding: utf-8 -*-
#from functions.spacy_to_lf_parser import spacy_to_lf_parser
from classes.Candidate import Sentence
from toolz import compose
import random
from sklearn.metrics import precision_recall_fscore_support


get_span = lambda m : m.span


class SpacyLabelFinder():

    def __init__(self, labels):
        self.labels = labels
    
    def _sub_span(self, s1, s2):
        return s1[0]>=s2[0] and s1[1]<=s2[1]
    
    def __call__(self, span):
        for li in self.labels:
            if self._sub_span(span, (li[0], li[1])):
                return li[2]


class LFEvalSuite():
    
    def __init__(self,
                 test_sentences,
                 pre_processor = None):
        

        self.test_data = self._parse_test_sentences(test_sentences, pre_processor)
        
    def load(self, 
             test_sentences,
             pre_processor = None):
        
        self.test_data = self._parse_test_sentences(test_sentences, pre_processor)
        
    def _parse_test_sentences(self, 
                              test_sentences, 
                              pre_processor = None):
        out = list()
        
        for sentence in test_sentences:
            
            if pre_processor:
                sentence = pre_processor(sentence)
                
            candidates = sentence.split()
            
            oi  = {'candidates' : candidates,
                   'sentence' : sentence,
                   'labels' : [ci.label for ci in candidates]}
            
            out.append(oi)
        return out
            
        '''
        for ti in test_data:
            
            #Compose function for finding labels 
            label_finder = SpacyLabelFinder(ti['labels'])
            get_labels = compose(label_finder, get_span)
            
            
            #Put text into sentence object
            sentence = Sentence(ti['text'])
            
            #Pre proc if need be
            if pre_processor:
                sentence = pre_processor(sentence)
            
            candidates = sentence.split()
            
            labels = list(map(get_labels, candidates))
            
            oi = {'candidates' : candidates,
                      'sentence' : sentence,
                      'labels' : labels}
                
            out.append(oi)
        
        
        return out
        '''
            
    def _token_test(self, lf, token, label, target, _hit):
    
        if label == target:
            positive = 1
        else:
            positive = 0
            
        
        if lf(token) == _hit:
            hit = 1
        else:
            hit = 0
            
        return (hit, positive)
            
    def prf(self, res):
        
        p, r, f, s =  precision_recall_fscore_support([ri[1] for ri in res],
                                               [ri[0] for ri in res],
                                               average = 'binary')
        
        return p, r, f
        
    def neg_prf(self, res):
        
        pos_and_pred_neg = 0
        pred_neg = 0
        neg = 0
        pos = 0
        neg_and_pred_neg = 0
        
        for ri in res:
            if ri[0] == 1:
                pred_neg += 1
                if ri[1] == 0:
                    neg_and_pred_neg += 1
                else:
                    pos_and_pred_neg += 1
                    
            if ri[1] == 0:
                neg+=1
            else:
                pos+=1
        
        if pred_neg > 0:
            bad_pred_negs = pos_and_pred_neg/pred_neg
        else:
            bad_pred_negs = 0
        
        if pos > 0:
            bad_positives = pos_and_pred_neg/pos
        else:
            bad_positives = 0
        
        if neg  > 0:
            neg_r = neg_and_pred_neg/neg
        else:
            neg_r = 1
            
        return bad_positives, bad_pred_negs, neg_r
    
    def _compute_accuracy(self, res, negative):
        
        if negative:
            neg_s  = sum([ri[1]==0 for ri in res])
            pred_neg_s  = sum([ri[0]==1 for ri in res])
            bad_positives, bad_pred_negs, neg_r = self.neg_prf(res)
            
            accuracy  = {
                'bad_positives' : bad_positives,
                'bad_pred_negs' : bad_pred_negs,
                'neg_r' : neg_r,
                'neg_s': neg_s,
                'pred_neg_s' : pred_neg_s
            }

        else:
            s  = sum([ri[1] for ri in res])
            p, r, f = self.prf(res)
            accuracy  = {
                'p' : p,
                'r' : r,
                'f' : f,
                's': s
            }
            
        return accuracy
    
    def _hit(self, negative):
        if negative:
            return 0
        else:
            return 1
    
    def __call__(self, 
                 lf, 
                 target,
                 negative = False):
        
        res = list()
        missed = list()
        mislabelled = list()
        hits = list()
        
        _hit = self._hit(negative)
        
        
        for ti in self.test_data:
            for j, tj in enumerate(ti['candidates']):
                
                resi = self._token_test(lf, tj, ti['labels'][j], target, _hit)
                res.append(resi)
                
                if resi[0] == 1 and resi[1] != _hit:
                    mislabelled.append((tj, ti['sentence']))
                elif resi[0] == 0 and resi[1] == _hit: 
                    missed.append((tj, ti['sentence']))
                elif resi[0] == 1 and resi[1] == _hit: 
                    hits.append((tj, ti['sentence']))
                    
        
        accuracy = self._compute_accuracy(res, negative)
        
        return {'accuracy' : accuracy,
                'mislabelled':mislabelled,
                'hits' : hits,
                'missed':missed}
