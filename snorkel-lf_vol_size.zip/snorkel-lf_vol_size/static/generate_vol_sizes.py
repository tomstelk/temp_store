# -*- coding: utf-8 -*-
import csv
#import import_s2_classes
import os

from settings import STATIC_DIR
vol_size_csv = os.path.join(STATIC_DIR, 'raw_csv_data', 'alcohol_vol_size_terms.csv')

from static.VolSize import VolSize

def create_vol_size(row):
    ml_units = []
    strings = []
    
    for ri in  row:
        try:
            intri = int(ri)
            ml_units.append(intri)
        except:
            try:
                floatri = float(ri)
                ml_units.append(floatri)
            except:
                strings.append(ri)
            
    return VolSize(strings= strings, ml_units=ml_units)


def generate_vol_size_objs():
    with open(vol_size_csv) as f:
        read_vol_csv = csv.reader(f)
        for row in read_vol_csv:
            yield create_vol_size(row)
            

def generate_all_vol_size_reprs():
    for v in generate_vol_size_objs():
        yield from v.get_all_reprs()            


def generate_vol_size_string_reprs():
    for v in generate_vol_size_objs():
        yield from v.get_string_reprs()            
