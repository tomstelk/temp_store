import os
import logging
import settings

logger = logging.getLogger(__name__)

base_path = settings.THIS_DIR
get_dir = lambda x: os.path.join(base_path, *x)


def read_file(abspath):
    """ Reads line separated keyword dict
    """
    with open(abspath, 'r') as f:
        keywords = f.read().splitlines()

    return keywords


# Wine
path = get_dir(['ws_data', 'wine', 'all_editions.txt'])
get_wine_all_editions = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'editions_3grams.txt'])
get_wine_editions_3grams = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'editions_4grams.txt'])
get_wine_editions_4grams = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'editions_ngrams.txt'])
get_wine_editions_ngrams = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'editions_tokens.txt'])
get_wine_editions_tokens = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'low_freq.txt'])
get_wine_low_freq = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'producer_tokens.txt'])
get_wine_producer_tokens = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'region_tokens.txt'])
get_wine_region_tokens = lambda: read_file(path)

path = get_dir(['ws_data', 'wine', 'types_tokens.txt'])
get_wine_type_tokens = lambda: read_file(path)

# Whiskey
path = get_dir(['ws_data', 'whiskey', 'all_editions.txt'])
get_whiskey_all_editions = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'editions_3grams.txt'])
get_whiskey_editions_3grams = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'editions_4grams.txt'])
get_whiskey_editions_4grams = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'editions_ngrams.txt'])
get_whiskey_editions_ngrams = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'editions_tokens.txt'])
get_whiskey_editions_tokens = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'low_freq.txt'])
get_whiskey_low_freq = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'producer_tokens.txt'])
get_whiskey_producer_tokens = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'region_tokens.txt'])
get_whiskey_region_tokens = lambda: read_file(path)

path = get_dir(['ws_data', 'whiskey', 'types_tokens.txt'])
get_whiskey_type_tokens = lambda: read_file(path)
