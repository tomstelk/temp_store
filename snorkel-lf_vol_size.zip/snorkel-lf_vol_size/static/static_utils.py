# -*- coding: utf-8 -*-
import import_utils
from settings import STATIC_DIR
import os
from utils.json_utils import get_json



def get_synonyms(key=None):
    j = get_json(os.path.join(STATIC_DIR, 'synonyms.json'))
    
    if key:
        return j[key]
    else:
        return j
