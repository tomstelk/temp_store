# -*- coding: utf-8 -*-
"""
Created on Fri Aug  9 16:33:34 2019

@author: user
"""


litre_spellings= ['litre', 'liter', 'litres', 'liters', 'lts', 'lt', 'ltr']

def generate_metric_strings(in_val, short_prefix, long_prefix):
    
    if int(in_val)!=in_val:
        in_vals = [str(in_val), str(in_val) + '0']
    else:
        in_vals =[str(in_val), str(in_val) + '.0']
    
    for in_val in in_vals:
    
        if short_prefix:
            yield '{} {}l'.format(in_val, short_prefix)
            yield '{} {} l'.format(in_val, short_prefix)
        else:
            yield '{} l'.format(in_val)
    
    
        for li in litre_spellings:
            if long_prefix:
                yield '{} {}{}'.format(in_val, long_prefix, li)
                yield '{} {} {}'.format(in_val, long_prefix, li)
            
            else:
                yield '{} {}'.format(in_val, li)
    
    
def clean_div(num, den):
    out = num/den
    
    if int(out)==out:
        return int(out)
    else:
        return out
    
    
ml_to_oz = 0.033814



def generate_imperial_strings(in_val):
    in_vals = [str(round(in_val, 1)),
               str(round(in_val, 1)) + '0']
    
    for i in in_vals:
        yield i
        yield '{} oz'.format(i)
        
    
def generate_unit_strings(in_ml):
    
    yield from generate_metric_strings(in_ml, 'm', 'milli')
    yield from generate_metric_strings(clean_div(in_ml,10), 'c', 'centi')
    yield from generate_metric_strings(clean_div(in_ml,1000), None, None)
    yield from generate_imperial_strings(in_ml * ml_to_oz)


class VolSize():
    
    
    def __init__(self, 
                 strings,
                 ml_units):
        
        self._strings = list(strings)
        self._ml_units = list(ml_units)
        self.unit = min(self._ml_units)/1000
        
    def get_all_reprs(self):
        
        yield from self.get_string_reprs()
        yield from self.get_num_reprs()
        

    def get_string_reprs(self):
        for si in self._strings:
            yield si
            yield si + 's'  #plural
        
    def get_num_reprs(self):
        for mli in self._ml_units:
            for usi in generate_unit_strings(mli):
                yield usi
