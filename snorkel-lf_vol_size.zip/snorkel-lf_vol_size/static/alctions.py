# -*- coding: utf-8 -*-
import import_utils
import os

from utils.json_utils import get_json, print_json_pretty
from utils.text_utils import zipngram
from itertools import chain, takewhile
from collections import Counter
from toolz import compose
from settings import ALCTION_FILE

get_alctions = lambda : get_json(ALCTION_FILE)

class FilterSubstrField():
    def __init__(self, substr, field):
        self.substr = substr
        self.field = field
        
    def __call__(self, j):
        f = j.get(self.field)
        if type(f)==str and self.substr in f:
            return True
        
        return False
            
def chain_split(iterable):
    return chain.from_iterable(map(lambda s:s.split(), iterable))


def zipngram_join(text_arr, n):
    return map(lambda ngi: ' '.join(ngi), zipngram(text_arr, n))

def chain_ngram_join(iterable, n):
    return chain.from_iterable(map(lambda s:zipngram_join(s.split(), n), iterable))


def before_numbers(in_str):
    befo_nums = takewhile(lambda si : not si.isnumeric(), in_str.split())
    return ' '.join(befo_nums)

bad_words = set(['in', 'with', 'box', 'whisky', 'barrel'])

def before_bad_words(in_str):
    befo_nums = takewhile(lambda si : si not in bad_words, in_str.split())
    return ' '.join(befo_nums)


def before_punc(in_str):
    befo_punc = takewhile(lambda si : '.' not in si, in_str.split())
    return ' '.join(befo_punc)

get_before_punc  = lambda texts : map(before_punc, texts)
get_name = lambda ji :ji['name']
get_name_no_num = lambda lots: map(before_numbers, map(get_name, lots))
get_before_bad_words  = lambda texts : map(before_bad_words, texts)
get_no_assortment = lambda texts: filter(lambda ti : 'assortment' not in ti, texts)
get_unique_words = lambda texts : list(set(chain_split(texts)))
get_unique_2grams = lambda texts : list(set(chain_ngram_join(texts, 2)))

filter_spectrum = FilterSubstrField(substr='spectrumwine', field='url')
get_spectrum_lots = lambda alc_lots : filter(filter_spectrum, alc_lots)
get_spectrum_texts = compose(*[get_before_bad_words, get_no_assortment, get_name_no_num, get_spectrum_lots, get_alctions])
get_spectrum_words = compose(*[get_unique_words, get_spectrum_texts])
get_spectrum_2grams = compose(*[get_unique_2grams, get_spectrum_texts])

filter_brentwood = FilterSubstrField(substr='brentwood', field='url')
get_brentwood_lots = lambda alc_lots : filter(filter_brentwood, alc_lots)
get_brentwood_texts = compose(*[get_before_punc, get_name_no_num, get_brentwood_lots, get_alctions])
get_brentwood_words = compose(*[get_unique_words, get_brentwood_texts])
get_brentwood_2grams = compose(*[get_unique_2grams, get_brentwood_texts])
