# -*- coding: utf-8 -*-
"""
Created on Fri Nov 22 16:44:56 2019

@author: 1613098
"""

from classes.LFEvalSuite import LFEvalSuite
import os

from lf.year import lf_year_alcohol, lf_year_vintage, lf_year_chateau, lf_year_near_numeric, lf_year_beginning

from utils.json_utils import get_json
from classes.Candidate import Sentence


test_data_dir = os.path.abspath('../labelled_test_data')
test_data = get_json(os.path.join(test_data_dir, 
                      'spacy_wine_name.json'))


make_setence = lambda ti : Sentence(text= ti['text'], text_id = 1)
test_sentences = list(map(make_setence, test_data))


lf_eval = LFEvalSuite(test_data = test_data)



res = lf_eval(lf = lf_year_beginning, target = 'year')


print(res['accuracy'])