# -*- coding: utf-8 -*-
import os
import pandas as pd

from importlib import import_module
from settings import PREPROCESSORS_MODULE, STATIC_UTILS_MODULE
from toolz import compose
from preprocess.preprocessors import RegexMatchPreProcessor, KeywordMatchPreProcessor
from nltk.corpus import stopwords, words as english_words


def make_keyword_pp(klass,
                    pre_label,
                    get_text_callable):
    
    k = getattr(import_module(PREPROCESSORS_MODULE), klass)
    c = getattr(import_module(STATIC_UTILS_MODULE), get_text_callable)
    
    return k(match_texts = c(), 
             pre_label = pre_label)


def make_ws_preprocessor(base_dir):
    """ Make keyword pre_processor for every file in base_dir
    """
    files = [os.path.join(base_dir, f) for f in os.listdir(base_dir)]
    preprocessors = []
    for fil in files:
        with open(fil, 'r') as f:
            texts = [u.strip() for u in f.readlines()]
        preprocessor = KeywordMatchPreProcessor('alcohol', texts)
        preprocessor.name = fil
        preprocessors.append(preprocessor)
    return preprocessors


preprocessor_cfg = [
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'ullage',
    'get_text_callable' : 'get_ullage',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'label',
    'get_text_callable' : 'get_label',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'cork',
    'get_text_callable' : 'get_cork',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'capsule',
    'get_text_callable' : 'get_capsule',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'colour',
    'get_text_callable' : 'get_colour',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'provenance',
    'get_text_callable' : 'get_provenance',
    'type' : 'keyword'
    },
    {
    'klass' : 'KeywordMatchPreProcessor',
    'pre_label' : 'box',
    'get_text_callable' : 'get_box',
    'type' : 'keyword'
    }
]

pps = list()
for ppi in preprocessor_cfg:
    if ppi['type']:
        pp = make_keyword_pp(klass = ppi['klass'],
                             pre_label = ppi['pre_label'],
                             get_text_callable = ppi['get_text_callable'],)
    pps.append(pp)

pps.append(RegexMatchPreProcessor(r'18[0-9]{2}|19[0-9]{2}|20[0-9]{2}', 'year'))
pps.append(RegexMatchPreProcessor(r'[0-9]{1,2}\sx', 'subqty'))

STOPWORDS = set(stopwords.words('english'))
english_pp = KeywordMatchPreProcessor('STOPWORD', list(STOPWORDS))
english_dict = KeywordMatchPreProcessor('ENG_DICT', list(english_words.words()))
common_words = pd.read_csv('data/most_common.csv')['Word'].tolist()
english_common = KeywordMatchPreProcessor(
    'ENG_COMMON', 
    common_words
)

#pps.append(english_common)
#pps.append(english_dict)
pps.append(english_pp)
pre_processor = compose(*pps) 
