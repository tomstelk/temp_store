# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFForInverse, LFNearPreLabelled, LFAnd, LFApplyNext, LFApplyPrev
from .wrapper import ABSTAIN, FOR as FOR_VOTE, AGAINST
from lf.vol_size import lf_vol_size_vocab_pre_labelled
from lf.year import lf_year

MAX_QUANTITY = 50

next_vol_size = LFNearPreLabelled(left_range = 0,
                                  right_range = 1,
                                  pre_labels = ['vol_size_vocab'],
                                  _for = True)


inv_vol_size = LFForInverse(lf = lf_vol_size_vocab_pre_labelled)

def token_numeric_small(token):
    
    if token.isnumeric() and int(token) < MAX_QUANTITY:
        return FOR_VOTE
    else:
        return ABSTAIN


lf_quantity_near_vol = LFAnd(lfs = [token_numeric_small, next_vol_size, inv_vol_size],
                             doc = "Return FOR if token is small numeric, and next token is vol size, and token is not vol size")


def next_x(token):
    if hasattr(token, 'right') and token.right == 'x':
        return FOR_VOTE
    else:
        return ABSTAIN

def prev_x(token):
    if hasattr(token, 'left') and token.left == 'x':
        return FOR_VOTE
    else:
        return ABSTAIN


lf_quantity_next_x = LFAnd(lfs = [token_numeric_small, next_x, inv_vol_size],
                           doc = "Return FOR if token is small numeric, and next token is 'x', and token is not vol size")
lf_quantity_prev_x = LFAnd(lfs = [token_numeric_small, prev_x, inv_vol_size],
                           doc = "Return FOR if token is small numeric, and prev token is 'x', and token is not vol size")

def end(token):
    if hasattr(token, 'right') and token.right == None:
        return FOR_VOTE
    else:
        return ABSTAIN

    

lf_quantity_end = LFAnd(lfs = [token_numeric_small, end],
                           doc = "Return FOR if token is small numeric, and is last token")


next_year = LFApplyNext(lf = lf_year)
lf_quantity_next_year = LFAnd(lfs = [token_numeric_small, next_year],
                           doc = "Return FOR if token is small numeric, and next token is a year")



prev_year = LFApplyPrev(lf = lf_year)
lf_quantity_prev_year = LFAnd(lfs = [token_numeric_small, prev_year],
                           doc = "Return FOR if token is small numeric, and previous token is a year")