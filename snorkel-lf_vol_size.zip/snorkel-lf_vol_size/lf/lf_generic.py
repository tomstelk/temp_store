# -*- coding: utf-8 -*-
import datetime 

from .wrapper import ABSTAIN, FOR as FOR_VOTE, AGAINST

min_year = 1900
max_year = datetime.datetime.now().year

def lf_numeric(token): 
    if token.isnumeric():
        return FOR_VOTE
    else:
        return ABSTAIN
    
    
def lf_year_generic(token):
    if len(token) == 4 and token.isnumeric() and min_year <= int(token) <= max_year :
        return FOR_VOTE
    else:
        return ABSTAIN

    
def lf_not_year_generic(token):
    if lf_year_generic(token) == ABSTAIN:
        return AGAINST
    else:
        return ABSTAIN
