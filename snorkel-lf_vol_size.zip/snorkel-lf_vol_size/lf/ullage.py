

from lf.LFBaseClasses import LFNearValues, LFBetween, LFPreLabelled,  LFNextToken,  LFTokenValue

lf_ullage_pre_labelled = LFPreLabelled('ullage')


level_synonyms = ['filling', 'fillings', 'ullage', 'levels', 'level', 'fills', 'fill']
parts_of_bottle = ['neck', 'shoulder']


#ullage_prev1_level = LFPreviousToken(num_tokens = 1, values = level_synonyms) 
#ullage_prev2_level = LFPreviousToken(num_tokens = 2, values = level_synonyms) 
lf_ullage_prev_level = LFNearValues(left_range = 2,
                           right_range = 0,
                           values = level_synonyms,
                           _for = True,
                           doc = "Within 2 tokens after level-like words")


lf_ullage_next_parts_of_bottle = LFNextToken(num_tokens = 1, values = parts_of_bottle, doc = "Next token a bottle part") 

lf_ullage_parts_of_bottle = LFTokenValue(values = parts_of_bottle, doc = "Token is a bottle part")

lf_ullage_between = LFBetween(left_values=level_synonyms, right_values=parts_of_bottle, doc = "Token between level-like words and pars of bottle")
