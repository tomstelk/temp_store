import logging
import re

from pathlib import Path
from functools import wraps
from nltk.corpus import stopwords

from ...wrapper import labeled, FOR, AGAINST, ABSTAIN


logger = logging.getLogger(__name__)

STOPWORDS = stopwords.words('english')

kw = ['years old', 'old year', 'y o', 'year old', 'yo']
small_kw = ['years', 'old', 'year', 'y', 'o']


def not_dec_not_kw(candidate):
    """
    If not decimal nor a kw, vote against
    """
    if not candidate.isdecimal() and candidate not in small_kw:
        return AGAINST
    return ABSTAIN


def dec_and_regex(candidate):
    """
    Match 0-99 followed by keyword
    """
    if candidate.isdecimal() and re.search(r'[0-9]{1,2}', candidate):
        context = ' '.join(candidate._yield_right(2))
        if any(u in context for u in kw):
            return FOR
    return ABSTAIN


def match_years(candidate):
    """
    Match year old (and synonyms) in 14 years
    """
    is_dec = re.search(r'[0-9]{1,2}', ' '.join(candidate._yield_left(2)))
    is_year = candidate in ['years', 'year', 'y']
    is_next_old = candidate.right in ['old', 'o']
    if is_dec and is_year and is_next_old:
        return FOR
    return ABSTAIN


def match_old(candidate):
    """
    Match old
    """
    if candidate == 'old' and candidate.left and 'year' in candidate.left:
        return FOR
    return ABSTAIN


def match_age_followed_by_number(candidate):
    """
    Match number following the stem age
    """
    aged = 'age' in ' '.join(candidate._yield_left(2))
    is_dec = candidate.isdecimal()
    if aged and is_dec:
        return FOR
    return ABSTAIN
