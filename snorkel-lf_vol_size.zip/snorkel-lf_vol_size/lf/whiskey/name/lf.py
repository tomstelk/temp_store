import os
import pandas as pd
import operator

from pathlib import Path
from nltk.corpus import stopwords
from collections import Counter, OrderedDict
from functools import reduce
from itertools import groupby
from langdetect import detect
from functools import wraps

import re

from snorkel.labeling import labeling_function

ABSTAIN = -1
FOR = 1
AGAINST = 0

def detect_wrapper(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        try:
            res = f(*args, **kwargs)
        except:
            return ABSTAIN
        return res
    return wrapped


def ngrams(text, n=2):
    tokens = text.split()
    return list(zip(*[tokens[i:] for i in range(n)]))

def vocabulary(tokens, top=-1):
    mapped = map(lambda x: (x, 1), tokens)
    count = OrderedDict()
    for k, g in groupby(sorted(mapped, key=lambda x: x[0]), lambda x: x[0]):
        u = list(g)
        tmp = reduce(lambda x, y: (x[0], x[1]+y[1]), u, ('', 0))
        count[k] = tmp[1]
    count = sorted(count.items(), key=lambda x: x[1], reverse=True)
    return [u[0] for u in count]


base_dir = Path('data')
name = 'alcohol_names.text'
distilleries = 'list_distilleries.txt'

with open(base_dir/name) as f:
    data = [u.strip() for u in f.readlines()]

with open(base_dir/distilleries) as f:
    dist = [u.strip() for u in f.readlines()]

data = [d for d in data if d not in stopwords.words('english')]
all_words = [u for d in data for u in d.split() if u not in stopwords.words('english')]
all_n_grams = [u for d in data for u in ngrams(d)]
top_n_grams = [' '.join(c) for c in vocabulary(all_n_grams)[:10000]]
top_names = [v for v in vocabulary(all_words)[:5000] if len(v) > 2]


@labeling_function(resources={"top_names": top_names})
def in_top_name(candidate, top_names):
    if candidate.token in top_names:
        return FOR
    return ABSTAIN


@labeling_function()
def is_decimal(candidate):
    if candidate.isdecimal():
        return AGAINST
    return ABSTAIN


@labeling_function()
def is_not_alpha(candidate):
    if not candidate.isalpha():
        return AGAINST
    return ABSTAIN


@labeling_function()
def is_not_tagged(candidate):
    if candidate.pre_labels or candidate.label:
        return AGAINST
    return FOR


@labeling_function()
def before_year(candidate):
    next_cand = candidate.right
    if next_cand and next_cand.isdecimal() and next_cand.startswith('19'):
        return FOR
    return ABSTAIN


@labeling_function(resources={'dist':distilleries})
@detect_wrapper
def is_scotish(candidate):
    scotish = ['cy', 'gd']
    left_sentence = ' '.join([candidate.tokens_left(), candidate.token])
    right_sentence = ' '.join([candidate.tokens_right(), candidate.token])
    lang_left = detect(left_sentence) in scotish
    lang_right = detect(right_sentence) in scotish
    if lang_left or lang_right:
        return FOR
    return ABSTAIN


@labeling_function(resources={'dist':distilleries})
@detect_wrapper
def is_japanese(candidate):
    scotish = ['ja']
    left_sentence = ' '.join([candidate.tokens_left(), candidate.token])
    right_sentence = ' '.join([candidate.tokens_right(), candidate.token])
    lang_left = detect(left_sentence) in scotish
    lang_right = detect(right_sentence) in scotish
    if lang_left or lang_right:
        return FOR
    return ABSTAIN

@labeling_function(resources={'dist':distilleries})
@detect_wrapper
def is_french(candidate):
    scotish = ['fr']
    left_sentence = ' '.join([candidate.tokens_left(), candidate.token])
    right_sentence = ' '.join([candidate.tokens_right(), candidate.token])
    lang_left = detect(left_sentence) in scotish
    lang_right = detect(right_sentence) in scotish
    if lang_left or lang_right:
        return FOR
    return ABSTAIN


@labeling_function()
def is_first_with_year(candidate):
    first = not candidate.tokens_left()
    next = candidate.cand_right()
    is_alcohol = False
    if first and next:
        cand = next[0]
        is_alcohol = cand.token.isdecimal() and len(cand.token) == 4
        if is_alcohol:
            return FOR
    return ABSTAIN

@labeling_function(resources={'dist':dist})
def is_distillerie(candidate, dist):
    sentence = ' '.join(candidate.get_left())
    if any(d in sentence for d in dist):
        return FOR
    return ABSTAIN
