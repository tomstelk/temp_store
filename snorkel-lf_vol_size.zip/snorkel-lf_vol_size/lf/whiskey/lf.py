import logging
import re

from ..wrapper import FOR, ABSTAIN, AGAINST
from snorkel.labeling import labeling_function

logger = logging.getLogger(__name__)

LTRS_SYN = ['l', 'litres', 'litre', 'L', 'cl', 'ml', 'oz']


@labeling_function()
def vol_size_1(candidate):
    is_decimal = candidate.isdecimal()
    if any(u in candidate._yield_right(2) for u in LTRS_SYN) and is_decimal:
        return FOR
    return ABSTAIN


@labeling_function()
def vol_size_3(candidate):
    abv_first = re.search(r'[0-9]{2}\s?%', ' '.join(candidate._yield_left(2)))
    abv_right = re.search(r'[0-9]{2}\s?%', ' '.join(candidate._yield_right(3)))
    if (abv_first or abv_right) and candidate.isdecimal() and any([u in candidate._yield_right(2) for u in ['cl', 'ml']]):
        return FOR
    return ABSTAIN


@labeling_function()
def vol_size_5(candidate):
    if candidate in ['70', '700', '750', '35', '500'] and candidate.right not in LTRS_SYN:
        return AGAINST
    return ABSTAIN


@labeling_function()
def vol_size_6(candidate):
    if candidate in LTRS_SYN:
        return FOR
    return ABSTAIN


@labeling_function()
def vol_size_10(candidate):
    if re.search(r'[0-9]\.[0-9]{2}', candidate) and candidate.right in LTRS_SYN:
        return FOR
    return ABSTAIN
