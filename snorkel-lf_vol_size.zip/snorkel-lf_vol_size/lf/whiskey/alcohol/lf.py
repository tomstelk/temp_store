import logging
import re
import pudb

from pathlib import Path
from functools import wraps
from nltk.corpus import stopwords

from snorkel.labeling import labeling_function

from lf.wrapper import labeled, FOR, AGAINST, ABSTAIN

logger = logging.getLogger(__name__)

STOPWORDS = stopwords.words('english')

base_dir = Path('data')
distilleries = Path('list_distilleries.txt')
ws_names = Path('names_whiskey_ws.txt')


def get_next_label(candidate, direction='right'):
    nex = getattr(candidate, direction)
    while nex:
        if nex.label:
            return nex.label
        nex = getattr(nex, direction)


with open(base_dir/distilleries) as f:
    dist = [u.strip() for u in f.readlines()]

with open(ws_names) as f:
    ws_names = [u.strip() for u in f.readlines()]

with open('ws_whiskey_bigrams.txt') as f:
    bigrams = [u.strip() for u in f.readlines()]


def rule_1(candidate):
    """ If START is unknown then date, UNKNOWN is AlcTitle
    """
    if candidate not in STOPWORDS:
        if not candidate.left and candidate.right:
            if re.search(r'(19|20)[0-9]{2}', candidate.right):
                return FOR
    return ABSTAIN


def rule_2(candidate):
    """ If unknown before qty (number) then keyword « bottle » (or bottles or btl or btle or bouteille or… see list of equivalents), then unknown is AlcTitle
    """
    if candidate.right and candidate.right.isdecimal():
        if candidate.right.right in ['bottle', 'btl', 'btle']:
            return FOR
    return ABSTAIN


def rule_3(candidate):
    """
    if START then unknown then quantity, unknown is AlcTitle
    """
    if candidate.left and not candidate.left.left and not candidate.label:
        if candidate.right and re.search(r'[0-9]{2}', candidate.right):
            return FOR
    return ABSTAIN


def rule_4(candidate):
    """
    if « limited release », then AlcTitle
    """
    kw = ['limited', 'release']
    if (candidate.left in ('limited', 'special') and candidate in ['release', 'edition']) or (candidate in ('limited', 'special') and candidate.right in ['release', 'edition']):
        return FOR
    return ABSTAIN


def rule_6(candidate):
    """ if year then unknown then END, unknown is AlcTitle
    """
    is_year = candidate.left and candidate.left.label == 'year'
    is_end = candidate.right and not candidate.right.right

    if is_year and is_end:
        return FOR
    return ABSTAIN


def rule_7(candidate):
    """ if « bottles of » (or keywords equivalent of bottles) then unknown, unknown is AlcTitle
    """
    kw = ' '.join(candidate._yield_left(2)) == 'bottles of'
    if kw:
        FOR
    return ABSTAIN


def rule_9(candidate):
    """ Distillerie list
    """
    left, right = '', ''
    if candidate.left:
        left = ' '.join([candidate.left, candidate])
    if candidate.right:
        right = ' '.join([candidate.right, candidate])

    if candidate in dist or left in dist or right in dist:
        return FOR
    return ABSTAIN


def rule_10(candidate):
    """ if start and age then alcohol name
    """
    if not candidate.left and candidate.right:
        if candidate.right.label == 'year' or candidate.right.label == 'age':
            return FOR
    return ABSTAIN


def rule_11(candidate):
    """ WS Whiskey Name
    """
    if candidate in ws_names:
        return FOR
    return ABSTAIN


def rule_12(candidate):
    """ WS Whiskey bigrams
    """
    if candidate.left:
        sent = ' '.join([candidate.left, candidate])
        if sent in bigrams:
            return FOR
    return ABSTAIN


def rule_13(candidate):
    """ WS Whiskey bigrams
    """
    if candidate.right:
        sent = ' '.join([candidate, candidate.right])
        if sent in bigrams:
            return FOR
    return ABSTAIN


def rule_14(candidate):
    """ If unknown after “produced by”, “bottled by”, “bottled”, “botteler”, then unknown is alctitle
    """
    kw = ['produced by', 'bottled by', 'bottled', 'botteler']
    left = ' '.join([l for l in candidate._yield_left(2) if l])
    if any(u in left for u in kw):
        return FOR
    return ABSTAIN


def rule_15(candidate):
    """ If unknown before “release” , then unknown is AlcTitle
    """
    if candidate.right and candidate.right == 'release':
        return FOR
    return ABSTAIN


def rule_16(candidate):
    """  If START then unknown then age, then unknown is AlcTitle
    """
    if not candidate.left and candidate.right and candidate.right.label == 'age':
        return FOR
    return ABSTAIN


def rule_17(candidate):
    """ If START then unknown then year, then unknown is AlcTitle
    """
    if not candidate.left and candidate.right and candidate.right.label == 'year':
        return FOR
    return ABSTAIN


def rule_18(candidate):
    """ If unknown before or after distillery, then unknown is ALcTitle 
    """
    if (candidate.right and candidate.right == 'distilery'): 
        return FOR
    elif (candidate.left and candidate.left == 'distillery'):
        return FOR
    return ABSTAIN


def is_decimal(candidate):
    if candidate.isdecimal():
        return AGAINST
    return ABSTAIN


def is_not_alpha(candidate):
    if not candidate.isalpha():
        return AGAINST
    return ABSTAIN


def is_not_tagged(candidate):
    if candidate.label or (candidate.pre_labels and 'alcohol' not in candidate.pre_labels):
        return AGAINST
    return FOR


def not_taged_before_year(candidate):
    next_label = get_next_label(candidate, 'right')
    if (candidate.label == "alcohol" or not candidate.label) and (not candidate.pre_labels or 'alcohol' in candidate.pre_labels):
        if next_label in ('year', 'age', 'vol_size', 'year_bottled', 'sub_quantity'):
            return FOR
    return ABSTAIN


def already_tagged(candidate):
    if candidate.label or candidate.pre_labels:
        if (candidate.label != "alcohol" or "alcohol" not in candidate.pre_labels):
            return AGAINST
    return ABSTAIN


def prelabeled(candidate):
    if 'alcohol' in candidate.pre_labels:
        return FOR
    return ABSTAIN


def empty_and_small(candidate):
    if not candidate.label and not candidate.pre_labels:
        if len(candidate.sentence) <= 6:
            #pudb.set_trace()
            return FOR
    return ABSTAIN


def only_alc(candidate):
    if set([c.label for c in candidate.sentence]) == set([None]):
        if candidate.sentence and len(candidate.sentence) <= 6:
            return FOR
    return ABSTAIN


def bottled_kw(candidate):
    if candidate.startswith('bottl'):
        return AGAINST
    return ABSTAIN


def between_year_qty(candidate):
    prev_label = [c.label for c in candidate._yield_left() if c.label is not None]
    if prev_label:
        prev_label = prev_label[::-1][-1]
    
    nex_label = [c.label for c in candidate._yield_right() if c.label is not None]
    if nex_label:
        nex_label = nex_label[0]

    if nex_label in ['quantity', 'year']:
        if prev_label in ['year', 'quantity']:
            #pudb.set_trace()
            return FOR
    return ABSTAIN


def is_number(candidate):
    if candidate.isdecimal():
        return AGAINST
    return ABSTAIN


def special_editions(candidate):
    kw = ['vintage', 'port']
    if candidate in kw:
        return FOR
    return ABSTAIN
