import logging
import re

from ...wrapper import labeled, FOR, AGAINST, ABSTAIN

logger = logging.getLogger(__name__)


def percentage_missing(candidate):
    """ 
    if percentage sign is missing, vote against
    """
    if '%' not in candidate:
        return AGAINST
    return ABSTAIN


def regex_patterns(candidate):
    """ 
    Regex pattern: 89% 90% 50%
    """
    match = re.search(r'[0-9]{2}\%', candidate)
    if match:
        return FOR
    return ABSTAIN


def percentage_and_vol(candidate):
    """
    Match percentage sign followed by mention of abv/vol
    """
    if '%' in candidate and any([u in candidate._yield_right(2) for u in ['abv', 'vol']]):
        if candidate != '100%':
            return FOR
    return ABSTAIN


def regex_pattern_decimal(candidate):
    """
    Regex pattern: 89.5% 52.1 %
    """
    match = re.search(r'[0-9]{2}\.[0-9]{1}.?\%', candidate)
    if match:
        return FOR
    return ABSTAIN


def regex_and_percentage(candidate):
    """
    Regex pattern: 52.1 40.9 followed by % sign
    """
    match = re.search(r'[0-9]{2}\.[0-9]{1}', candidate)
    if match and '%' in candidate._yield_right(2):
        return FOR
    return ABSTAIN


def number_and_degree(candidate):
    """
    Number followed by degree (and synonims)
    """
    left = candidate.left and candidate.left.isdecimal()
    right = candidate.right and candidate.right in ['degree', 'deg']
    if left and right:
        return FOR
    return AGAINST
