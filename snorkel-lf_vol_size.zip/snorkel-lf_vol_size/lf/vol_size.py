# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled

lf_vol_size_vocab_pre_labelled = LFPreLabelled(
                                                pre_label = 'vol_size_vocab', 
                                                doc = "Returns FOR vote if token is from vol_size vocabulary else ABSTAIN"
                                                )



