# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled

lf_label_pre_labelled = LFPreLabelled('label', doc = 'Pre-labelled as label from specialist provenance vocabulary')
