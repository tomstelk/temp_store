# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled

lf_capsule_pre_labelled = LFPreLabelled('capsule', doc = 'Pre-labelled as provenance from specialist capsule vocabulary')
