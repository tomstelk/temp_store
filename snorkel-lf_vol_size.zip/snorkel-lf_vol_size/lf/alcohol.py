# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled
from lf.lf_generic import ABSTAIN, FOR_VOTE, AGAINST

lf_alcohol_producer = LFPreLabelled('ws_producer', doc = "Pre-labelled as winesearcher producer")
lf_alcohol_region = LFPreLabelled('ws_region', doc = "Pre-labelled as winesearcher region")
lf_alcohol_sub_region = LFPreLabelled('ws_sub_region', doc = "Pre-labelled as winesearcher sub_region")
lf_alcohol_sub_sub_region =  LFPreLabelled('ws_sub_sub_region', doc = "Pre-labelled as winesearcher sub_sub_region")
lf_alcohol_sub_sub_sub_region = LFPreLabelled('ws_sub_sub_sub_region', doc = "Pre-labelled as winesearcher sub_sub_sub_region")
lf_alcohol_brentwood = LFPreLabelled('brentwood', doc = "Pre-labelled using brentwood auctions vocab")
lf_alcohol_spectrum = LFPreLabelled('spectrum', doc = "Pre-labelled using spectrum auctions vocab")


def lf_alcohol_numeric_negative(token):
    if token.isnumeric():
        return AGAINST
    else:
        return ABSTAIN
    