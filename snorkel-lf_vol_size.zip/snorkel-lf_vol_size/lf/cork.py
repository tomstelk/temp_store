# -*- coding: utf-8 -*-
from lf.LFBaseClasses import LFPreLabelled

lf_cork_pre_labelled = LFPreLabelled('cork', doc = 'Pre-labelled as provenance from specialist cork vocabulary')
