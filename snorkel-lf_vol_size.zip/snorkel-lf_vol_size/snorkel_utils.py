import logging
import importlib
import inspect
import re

from itertools import groupby
from snorkel.labeling import LabelingFunction, labeling_function

logger = logging.getLogger(__name__)


def align_tokens(text):
    for fi in re.finditer('[^\s]+', text):
        yield fi.span()


def import_lf(path):
    """ Given a python file path import all the labelling functions
    """
    module = importlib.import_module(path)
    funcs = inspect.getmembers(module, lambda x: isinstance(x, LabelingFunction))
    return [f for _, f in funcs]


def to_spacy(sentences):
    """ Reformat sentences to spacy format
    """
    for sent in sentences:
        js = sent.to_json()
        yield (js['text'], 
                {'entities': [(start, end, label) for label, spans  in js['labels'].items() for start, end in spans]})


def resources_decorate(func, **kwargs):
    """ Decorate func to a labeling_function with mapped kwargs resources
    """
    return  labeling_function(resources=kwargs)(func)


if __name__ == '__main__':
    text = "this is a sentence"
    spans = align_tokens(text)

    path = 'lf.whiskey.lf'
    funcs = import_lf(path)
